-- Sample data for local development/testing.

INSERT INTO categories (name, slug, sort_order) VALUES
  ('Sand', 'sand', 1),
  ('Gitti / Aggregate', 'gitti-aggregate', 2),
  ('Stone', 'stone', 3),
  ('Gravel', 'gravel', 4),
  ('Soil / Mitti', 'soil-mitti', 5),
  ('Fly Ash / Ash', 'fly-ash', 6),
  ('Bricks', 'bricks', 7),
  ('Cement', 'cement', 8),
  ('Construction Blocks', 'construction-blocks', 9),
  ('Other', 'other', 10);

INSERT INTO materials (category_id, name, default_unit, description)
SELECT id, 'River Sand (Fine)', 'ton', 'Fine river sand for plastering and masonry'
FROM categories WHERE slug = 'sand';

INSERT INTO materials (category_id, name, default_unit, description)
SELECT id, '20mm Aggregate', 'ton', 'Crushed stone aggregate for RCC work'
FROM categories WHERE slug = 'gitti-aggregate';

INSERT INTO materials (category_id, name, default_unit, description)
SELECT id, 'Red Clay Bricks', 'brick', 'Standard 9x4x3 inch clay bricks'
FROM categories WHERE slug = 'bricks';

INSERT INTO materials (category_id, name, default_unit, description)
SELECT id, 'OPC 53 Grade Cement', 'bag', '50kg bag, Ordinary Portland Cement Grade 53'
FROM categories WHERE slug = 'cement';

-- Sample users, supplier, and materials would follow the same pattern —
-- add once you have a real auth/signup flow producing user rows.
