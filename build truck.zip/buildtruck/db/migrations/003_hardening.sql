-- Migration 003: GST/tax fields on invoices, a generic file_uploads
-- metadata table for the storage abstraction, and the GST rate setting.
-- Additive only — run after 002_advanced_features.sql.

-- ======================= INVOICE GST/TAX =======================
ALTER TABLE invoices ADD COLUMN taxable_amount NUMERIC(12,2);
ALTER TABLE invoices ADD COLUMN gst_rate NUMERIC(5,2);
ALTER TABLE invoices ADD COLUMN cgst_amount NUMERIC(12,2) NOT NULL DEFAULT 0;
ALTER TABLE invoices ADD COLUMN sgst_amount NUMERIC(12,2) NOT NULL DEFAULT 0;
ALTER TABLE invoices ADD COLUMN igst_amount NUMERIC(12,2) NOT NULL DEFAULT 0;
ALTER TABLE invoices ADD COLUMN customer_gstin VARCHAR(20);
ALTER TABLE invoices ADD COLUMN is_interstate BOOLEAN NOT NULL DEFAULT false;
-- tax_amount (already existed, was hardcoded 0) now = cgst+sgst+igst,
-- computed and stored by invoiceService.ts rather than being a raw input.

INSERT INTO admin_settings (key, value) VALUES
  ('gst_rate_percent', '18')
ON CONFLICT (key) DO NOTHING;

-- ======================= FILE UPLOADS (storage abstraction metadata) =====
-- The actual bytes live in whichever storage provider is configured
-- (S3-compatible, GCS-compatible, or local-disk in dev — see
-- backend/src/services/storageService.ts). This table only tracks WHO
-- uploaded WHAT, for permission checks and for entities (POD, disputes,
-- verification, invoices) to reference by id instead of a bare URL.
CREATE TYPE file_owner_type AS ENUM (
  'SUPPLIER_DOCUMENT', 'TRUCK_DOCUMENT', 'POD_PHOTO', 'DELIVERY_SIGNATURE',
  'DISPUTE_EVIDENCE', 'INVOICE_ATTACHMENT'
);

CREATE TABLE file_uploads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_type file_owner_type NOT NULL,
  owner_id UUID,                         -- order id / dispute id / supplier id, depending on owner_type; null until linked
  uploaded_by UUID NOT NULL REFERENCES users(id),
  storage_key TEXT NOT NULL,             -- path/key within the storage bucket
  file_url TEXT NOT NULL,                -- public or signed URL, depending on provider/access level
  content_type VARCHAR(100),
  size_bytes BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_file_uploads_owner ON file_uploads(owner_type, owner_id);
CREATE INDEX idx_file_uploads_uploader ON file_uploads(uploaded_by);
