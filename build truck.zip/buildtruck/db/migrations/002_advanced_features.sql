-- Migration 002: RFQ, multi-load orders, POD, business/projects, disputes,
-- verification, inventory, invoices, and advanced delivery pricing.
-- Purely additive — no existing table is altered destructively except the
-- narrow ALTER TABLE ... ADD COLUMN statements marked below, which are safe
-- (new nullable/defaulted columns) and do not change any existing behavior
-- until the new application code reads/writes them.
-- Run after db/schema.sql. Idempotent-ish: uses IF NOT EXISTS where Postgres allows it.

-- ======================= RFQ / QUOTATION SYSTEM =======================
CREATE TYPE rfq_status AS ENUM ('DRAFT','OPEN','QUOTED','SHORTLISTED','AWARDED','EXPIRED','CANCELLED','COMPLETED');
CREATE TYPE quote_status AS ENUM ('SUBMITTED','SHORTLISTED','AWARDED','REJECTED','WITHDRAWN');

CREATE TABLE rfqs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  customer_id UUID NOT NULL REFERENCES users(id),
  project_id UUID,                       -- FK added after projects table exists (below)
  project_name VARCHAR(255),
  material_name VARCHAR(255) NOT NULL,
  specification TEXT,                    -- grade/size/spec free text (see category_spec_fields below for structured specs)
  quantity NUMERIC(14,2) NOT NULL,
  unit unit_type NOT NULL,
  required_delivery_date DATE,
  delivery_location TEXT NOT NULL,
  delivery_lat NUMERIC(9,6),
  delivery_lng NUMERIC(9,6),
  additional_requirements TEXT,
  target_price NUMERIC(12,2),
  attachments JSONB DEFAULT '[]',
  expiry_at TIMESTAMPTZ,
  status rfq_status NOT NULL DEFAULT 'OPEN',
  awarded_quote_id UUID,                 -- FK added after rfq_quotes exists
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_rfqs_customer ON rfqs(customer_id);
CREATE INDEX idx_rfqs_status ON rfqs(status);
CREATE INDEX idx_rfqs_geo ON rfqs(delivery_lat, delivery_lng);

CREATE TABLE rfq_quotes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  rfq_id UUID NOT NULL REFERENCES rfqs(id) ON DELETE CASCADE,
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id),
  price_per_unit NUMERIC(12,2) NOT NULL,
  available_quantity NUMERIC(14,2) NOT NULL,
  delivery_time_days INT,
  transport_cost NUMERIC(12,2) DEFAULT 0,
  tax_percent NUMERIC(5,2) DEFAULT 0,
  quote_validity_until TIMESTAMPTZ,
  notes TEXT,
  status quote_status NOT NULL DEFAULT 'SUBMITTED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(rfq_id, supplier_id)
);
CREATE INDEX idx_rfq_quotes_rfq ON rfq_quotes(rfq_id);
CREATE INDEX idx_rfq_quotes_supplier ON rfq_quotes(supplier_id);

ALTER TABLE rfqs ADD CONSTRAINT fk_rfq_awarded_quote FOREIGN KEY (awarded_quote_id) REFERENCES rfq_quotes(id);

-- ======================= BUSINESS ACCOUNTS / PROJECTS =======================
CREATE TYPE business_role AS ENUM ('OWNER','ADMIN','MANAGER','STAFF','VIEWER');

CREATE TABLE businesses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  gstin VARCHAR(20),
  address TEXT,
  owner_user_id UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE business_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id),
  role business_role NOT NULL DEFAULT 'STAFF',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id, user_id)
);
CREATE INDEX idx_business_members_user ON business_members(user_id);

CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  project_type VARCHAR(100),
  site_address TEXT,
  manager_user_id UUID REFERENCES users(id),
  start_date DATE,
  expected_completion_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_projects_business ON projects(business_id);

ALTER TABLE rfqs ADD CONSTRAINT fk_rfq_project FOREIGN KEY (project_id) REFERENCES projects(id);
ALTER TABLE orders ADD COLUMN project_id UUID REFERENCES projects(id);

-- ======================= MULTI-TRUCK / MULTI-LOAD ORDERS =======================
CREATE TYPE trip_status AS ENUM ('PENDING','ASSIGNED','PICKED_UP','OUT_FOR_DELIVERY','DELIVERED','CANCELLED');

-- An order that needs more than one truckload gets one row here per trip.
-- A normal single-truck order simply has zero rows in this table — nothing
-- about the existing single-truck order flow changes.
CREATE TABLE order_trips (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  trip_number INT NOT NULL,
  truck_id UUID REFERENCES trucks(id),
  driver_name VARCHAR(255),
  driver_phone VARCHAR(15),
  load_quantity NUMERIC(14,2) NOT NULL,
  status trip_status NOT NULL DEFAULT 'PENDING',
  pickup_time TIMESTAMPTZ,
  delivery_time TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(order_id, trip_number)
);
CREATE INDEX idx_order_trips_order ON order_trips(order_id);

ALTER TABLE orders ADD COLUMN total_quantity NUMERIC(14,2);        -- total across all trips; null = single-truck order (use order_items instead)
ALTER TABLE orders ADD COLUMN requires_multi_truck BOOLEAN NOT NULL DEFAULT false;

-- ======================= PROOF OF DELIVERY (POD) =======================
CREATE TABLE proof_of_deliveries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  trip_id UUID REFERENCES order_trips(id),   -- null for single-truck orders
  delivered_quantity NUMERIC(14,2) NOT NULL,
  shortage_notes TEXT,                        -- filled in for partial/short delivery
  photo_urls JSONB DEFAULT '[]',
  signature_url TEXT,
  customer_confirmed BOOLEAN NOT NULL DEFAULT false,
  otp_verified BOOLEAN NOT NULL DEFAULT false,
  lat NUMERIC(9,6),
  lng NUMERIC(9,6),
  delivered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pod_order ON proof_of_deliveries(order_id);

-- ======================= MATERIAL SPECIFICATIONS (configurable by category) ==
-- Admin defines which spec fields apply to a category (e.g. Gitti -> "Size"
-- with options 10mm/20mm/40mm) instead of hardcoding per-material columns.
CREATE TABLE category_spec_fields (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category_id UUID NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  field_name VARCHAR(100) NOT NULL,      -- e.g. "Size", "Brand", "Grade"
  field_type VARCHAR(20) NOT NULL DEFAULT 'select' CHECK (field_type IN ('select','text','number')),
  options JSONB DEFAULT '[]',            -- e.g. ["10mm","20mm","40mm"] for 'select'
  is_required BOOLEAN NOT NULL DEFAULT false,
  sort_order INT DEFAULT 0
);
CREATE INDEX idx_category_spec_fields_category ON category_spec_fields(category_id);

ALTER TABLE supplier_materials ADD COLUMN specs JSONB DEFAULT '{}'; -- { "Size": "20mm", "Brand": "UltraTech" }

-- ======================= INVENTORY MANAGEMENT =======================
ALTER TABLE supplier_materials ADD COLUMN reserved_quantity NUMERIC(14,2) NOT NULL DEFAULT 0;
ALTER TABLE supplier_materials ADD COLUMN sold_quantity NUMERIC(14,2) NOT NULL DEFAULT 0;
ALTER TABLE supplier_materials ADD COLUMN low_stock_threshold NUMERIC(14,2);
ALTER TABLE supplier_materials ADD COLUMN expected_restock_date DATE;
-- Availability is derived (available_quantity - reserved_quantity <= 0) at
-- read time rather than a separately-stored status, so it can never drift
-- out of sync with the quantities themselves.

-- ======================= DISPUTES =======================
CREATE TYPE dispute_issue_type AS ENUM (
  'WRONG_MATERIAL','SHORT_QUANTITY','DAMAGED_MATERIAL','QUALITY_ISSUE',
  'LATE_DELIVERY','TRUCK_NO_SHOW','INCORRECT_CHARGES','OTHER'
);
CREATE TYPE dispute_status AS ENUM ('OPEN','UNDER_REVIEW','WAITING_FOR_INFORMATION','RESOLVED','REJECTED','CLOSED');

CREATE TABLE disputes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id),
  raised_by UUID NOT NULL REFERENCES users(id),
  issue_type dispute_issue_type NOT NULL,
  description TEXT NOT NULL,
  evidence_urls JSONB DEFAULT '[]',
  requested_resolution TEXT,
  status dispute_status NOT NULL DEFAULT 'OPEN',
  admin_notes TEXT,
  resolution TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_disputes_order ON disputes(order_id);
CREATE INDEX idx_disputes_status ON disputes(status);

CREATE TABLE dispute_status_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  dispute_id UUID NOT NULL REFERENCES disputes(id) ON DELETE CASCADE,
  from_status dispute_status,
  to_status dispute_status NOT NULL,
  changed_by UUID REFERENCES users(id),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ======================= SUPPLIER + TRUCK VERIFICATION (documents) =======
CREATE TYPE verification_owner_type AS ENUM ('SUPPLIER','TRUCK');
CREATE TYPE document_verification_status AS ENUM ('PENDING','VERIFIED','REJECTED','EXPIRED');

CREATE TABLE verification_documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_type verification_owner_type NOT NULL,
  owner_id UUID NOT NULL,                -- supplier_profiles.id | trucks.id, per owner_type
  doc_type VARCHAR(50) NOT NULL,         -- e.g. 'pan','gstin','bank_details','rc_book','insurance','permit','fitness','driver_license'
  file_url TEXT NOT NULL,
  status document_verification_status NOT NULL DEFAULT 'PENDING',
  expiry_date DATE,
  verified_by UUID REFERENCES users(id),
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_verification_docs_owner ON verification_documents(owner_type, owner_id);
CREATE INDEX idx_verification_docs_expiry ON verification_documents(expiry_date) WHERE expiry_date IS NOT NULL;

-- ======================= INVOICES =======================
CREATE TABLE invoices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL UNIQUE REFERENCES orders(id),
  invoice_number VARCHAR(30) NOT NULL UNIQUE,
  material_charges NUMERIC(12,2) NOT NULL,
  delivery_charges NUMERIC(12,2) NOT NULL,
  platform_charges NUMERIC(12,2) NOT NULL DEFAULT 0,
  discount_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  tax_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_amount NUMERIC(12,2) NOT NULL,
  gst_number VARCHAR(20),
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ======================= ADVANCED DELIVERY PRICING =======================
-- Per-vehicle-category rate multipliers, admin-editable, on top of the
-- base/per-km rate already in admin_settings (see settingsRepository.ts).
CREATE TABLE vehicle_rate_multipliers (
  vehicle_category VARCHAR(30) PRIMARY KEY,
  multiplier NUMERIC(5,2) NOT NULL DEFAULT 1.0
);
INSERT INTO vehicle_rate_multipliers (vehicle_category, multiplier) VALUES
  ('pickup', 0.6), ('mini_truck', 0.8), ('6_wheeler', 1.0), ('10_wheeler', 1.3),
  ('12_wheeler', 1.5), ('16_wheeler', 1.8), ('18_wheeler', 2.0),
  ('tractor', 0.9), ('tractor_trolley', 1.1), ('other', 1.0);

INSERT INTO admin_settings (key, value) VALUES
  ('loading_charge', '150'),
  ('unloading_charge', '150'),
  ('waiting_charge_per_hour', '100'),
  ('default_toll_charge', '0'),
  ('remote_area_charge', '200'),
  ('remote_area_distance_km', '60')
ON CONFLICT (key) DO NOTHING;

-- ======================= NOTIFICATIONS: extra type values only =======================
-- notifications table already exists in db/schema.sql (user_id, title, body,
-- type, is_read, data, created_at) — no structural change needed; `type`
-- is free text there (e.g. 'rfq_created','quote_submitted','order_update',
-- 'dispute_update','inventory_low','document_expiry','commission_due').
