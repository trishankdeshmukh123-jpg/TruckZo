-- BuildTruck MVP — PostgreSQL schema
-- Money columns use NUMERIC (never FLOAT) to avoid rounding drift.
-- All timestamps are timestamptz. All tables have created_at/updated_at.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ======================= ENUMS =======================
CREATE TYPE user_role AS ENUM ('customer', 'supplier', 'admin');
CREATE TYPE order_status AS ENUM (
  'PENDING','ACCEPTED','TRUCK_ASSIGNED','PICKUP_STARTED',
  'OUT_FOR_DELIVERY','ARRIVING','DELIVERED','COMPLETED',
  'CANCELLED','REFUNDED'
);
CREATE TYPE payment_method AS ENUM ('UPI','CASH');
CREATE TYPE payment_status AS ENUM ('PENDING','SUCCESS','FAILED','REFUNDED','PARTIALLY_REFUNDED');
CREATE TYPE commission_status AS ENUM ('PAYABLE','SETTLED','WAIVED');
CREATE TYPE supplier_verification_status AS ENUM ('PENDING','APPROVED','REJECTED','SUSPENDED');
CREATE TYPE unit_type AS ENUM ('kg','ton','cft','cum','brick','bag','load','unit');

-- ======================= USERS =======================
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone VARCHAR(15) UNIQUE,              -- Indian mobile number, +91XXXXXXXXXX
  email VARCHAR(255) UNIQUE,
  password_hash TEXT,                    -- null if OTP-only auth
  full_name VARCHAR(255) NOT NULL,
  role user_role NOT NULL DEFAULT 'customer',
  is_supplier_mode_enabled BOOLEAN NOT NULL DEFAULT false, -- admin can allow supplier<->customer switch
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_suspended BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT phone_or_email CHECK (phone IS NOT NULL OR email IS NOT NULL)
);
CREATE INDEX idx_users_role ON users(role);

CREATE TABLE customer_profiles (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  default_address_id UUID, -- FK added after addresses table
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE supplier_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_name VARCHAR(255) NOT NULL,
  business_phone VARCHAR(15) NOT NULL,
  business_address TEXT NOT NULL,
  service_area_pincode VARCHAR(10),
  service_lat NUMERIC(9,6),
  service_lng NUMERIC(9,6),
  service_radius_km NUMERIC(6,2) DEFAULT 25,
  verification_status supplier_verification_status NOT NULL DEFAULT 'PENDING',
  verification_notes TEXT,
  gst_number VARCHAR(20),
  rating_avg NUMERIC(3,2) DEFAULT 0,
  rating_count INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);
CREATE INDEX idx_supplier_verification ON supplier_profiles(verification_status);
CREATE INDEX idx_supplier_geo ON supplier_profiles(service_lat, service_lng);

CREATE TABLE supplier_documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id) ON DELETE CASCADE,
  doc_type VARCHAR(50) NOT NULL,         -- e.g. 'gst_certificate','id_proof','address_proof'
  file_url TEXT NOT NULL,                -- signed/private storage URL
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE driver_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id) ON DELETE CASCADE,
  full_name VARCHAR(255) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  license_number VARCHAR(50),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Vehicle category and capacity bracket are fixed option sets (task spec
-- §2) enforced with CHECK constraints rather than a Postgres ENUM, so
-- adding a new option later is an ALTER TABLE ... CHECK, not an ALTER TYPE.
CREATE TABLE trucks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id) ON DELETE CASCADE,
  registration_number VARCHAR(20) NOT NULL, -- Indian format e.g. MH12AB1234
  vehicle_category VARCHAR(30) NOT NULL CHECK (vehicle_category IN (
    '6_wheeler','10_wheeler','12_wheeler','16_wheeler','18_wheeler',
    'tractor','tractor_trolley','pickup','mini_truck','other'
  )),
  capacity_bracket VARCHAR(20) CHECK (capacity_bracket IN (
    '1_ton','2_ton','3_ton','5_ton','7_ton','10_ton','15_ton','20_ton','25_ton_plus'
  )),
  capacity_tons NUMERIC(6,2),           -- optional precise tonnage alongside the bracket
  rate_per_trip NUMERIC(12,2),
  rate_per_km NUMERIC(12,2),
  current_lat NUMERIC(9,6),             -- truck's current location, for customer search/filter
  current_lng NUMERIC(9,6),
  vehicle_details TEXT,                 -- free-text: model, year, condition, etc.
  driver_id UUID REFERENCES driver_profiles(id),
  is_available BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(registration_number)
);
CREATE INDEX idx_trucks_supplier ON trucks(supplier_id);
CREATE INDEX idx_trucks_category ON trucks(vehicle_category, is_available);
CREATE INDEX idx_trucks_geo ON trucks(current_lat, current_lng);


-- ======================= CATALOG =======================
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(100) NOT NULL UNIQUE,   -- Sand, Gitti/Aggregate, Bricks, Cement...
  slug VARCHAR(100) NOT NULL UNIQUE,
  icon_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE materials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category_id UUID NOT NULL REFERENCES categories(id),
  name VARCHAR(255) NOT NULL,          -- catalog-level generic material (admin managed)
  description TEXT,
  default_unit unit_type NOT NULL DEFAULT 'unit',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_materials_category ON materials(category_id);

-- What a specific supplier actually sells, at their own price/qty
CREATE TABLE supplier_materials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id) ON DELETE CASCADE,
  material_id UUID NOT NULL REFERENCES materials(id),
  price_per_unit NUMERIC(12,2) NOT NULL CHECK (price_per_unit >= 0),
  unit unit_type NOT NULL,
  available_quantity NUMERIC(12,2) NOT NULL DEFAULT 0,
  min_order_quantity NUMERIC(12,2) NOT NULL DEFAULT 1,
  images JSONB DEFAULT '[]',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(supplier_id, material_id)
);
CREATE INDEX idx_supplier_materials_material ON supplier_materials(material_id);

-- ======================= ADDRESSES =======================
CREATE TABLE addresses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label VARCHAR(50),                    -- 'Home','Site','Office'
  line1 TEXT NOT NULL,
  line2 TEXT,
  city VARCHAR(100) NOT NULL,
  district VARCHAR(100),
  state VARCHAR(100) NOT NULL,
  pincode VARCHAR(10) NOT NULL,
  lat NUMERIC(9,6) NOT NULL,
  lng NUMERIC(9,6) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_addresses_user ON addresses(user_id);
ALTER TABLE customer_profiles
  ADD CONSTRAINT fk_default_address FOREIGN KEY (default_address_id) REFERENCES addresses(id);

-- ======================= ORDERS =======================
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number VARCHAR(20) NOT NULL UNIQUE,   -- human-readable e.g. BT-2026-000123
  customer_id UUID NOT NULL REFERENCES users(id),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id),
  delivery_address_id UUID NOT NULL REFERENCES addresses(id),
  truck_id UUID REFERENCES trucks(id),
  status order_status NOT NULL DEFAULT 'PENDING',

  -- server-calculated, authoritative money fields (never trust client input)
  material_cost NUMERIC(12,2) NOT NULL,
  delivery_distance_km NUMERIC(8,2) NOT NULL,
  delivery_charge NUMERIC(12,2) NOT NULL,
  platform_charges NUMERIC(12,2) NOT NULL DEFAULT 0,
  discount_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_amount NUMERIC(12,2) NOT NULL,

  commission_rate_snapshot NUMERIC(5,2) NOT NULL, -- % at time of order, for audit
  commission_amount NUMERIC(12,2) NOT NULL DEFAULT 0,

  payment_method payment_method NOT NULL,
  delivery_otp_hash TEXT,               -- hashed, single-use
  delivery_otp_expires_at TIMESTAMPTZ,

  cancelled_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_supplier ON orders(supplier_id);
CREATE INDEX idx_orders_status ON orders(status);

CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  supplier_material_id UUID NOT NULL REFERENCES supplier_materials(id),
  quantity NUMERIC(12,2) NOT NULL CHECK (quantity > 0),
  unit_price_snapshot NUMERIC(12,2) NOT NULL, -- price at order time, for audit
  line_total NUMERIC(12,2) NOT NULL
);
CREATE INDEX idx_order_items_order ON order_items(order_id);

CREATE TABLE order_status_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  from_status order_status,
  to_status order_status NOT NULL,
  changed_by UUID REFERENCES users(id),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_status_history_order ON order_status_history(order_id);

-- ======================= PAYMENTS & COMMISSION =======================
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  method payment_method NOT NULL,
  status payment_status NOT NULL DEFAULT 'PENDING',
  amount NUMERIC(12,2) NOT NULL,
  provider VARCHAR(50),                 -- 'mock','razorpay','payu', etc.
  provider_payment_id VARCHAR(255),     -- external reference only, never raw credentials
  provider_payload JSONB,               -- sanitized webhook payload for audit
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payments_order ON payments(order_id);

CREATE TABLE commission_ledger (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id),
  commissionable_amount NUMERIC(12,2) NOT NULL,
  commission_rate NUMERIC(5,2) NOT NULL,
  commission_amount NUMERIC(12,2) NOT NULL,
  status commission_status NOT NULL DEFAULT 'PAYABLE',
  settlement_id UUID,                    -- FK added after settlements table
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_commission_supplier ON commission_ledger(supplier_id, status);

CREATE TABLE settlements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id),
  total_amount NUMERIC(12,2) NOT NULL,
  method VARCHAR(30) NOT NULL,           -- 'UPI','bank_transfer','admin_manual'
  reference VARCHAR(255),
  settled_by UUID REFERENCES users(id),  -- admin who recorded it, if manual
  settled_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE commission_ledger
  ADD CONSTRAINT fk_settlement FOREIGN KEY (settlement_id) REFERENCES settlements(id);

-- ======================= REVIEWS, NOTIFICATIONS, SUPPORT =======================
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) UNIQUE,
  customer_id UUID NOT NULL REFERENCES users(id),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id),
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_reviews_supplier ON reviews(supplier_id);

CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  type VARCHAR(50),                     -- 'order_update','promo','system'
  is_read BOOLEAN NOT NULL DEFAULT false,
  data JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);

CREATE TABLE support_tickets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id),
  order_id UUID REFERENCES orders(id),
  subject VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'OPEN', -- OPEN, IN_PROGRESS, RESOLVED, CLOSED
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ======================= LIVE TRACKING =======================
-- Written ONLY while an order is in an active-delivery status; deleted/expired after.
CREATE TABLE live_locations (
  order_id UUID PRIMARY KEY REFERENCES orders(id) ON DELETE CASCADE,
  truck_id UUID NOT NULL REFERENCES trucks(id),
  lat NUMERIC(9,6) NOT NULL,
  lng NUMERIC(9,6) NOT NULL,
  heading NUMERIC(6,2),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ======================= COUPONS =======================
CREATE TABLE coupons (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code VARCHAR(50) NOT NULL UNIQUE,
  discount_type VARCHAR(20) NOT NULL,    -- 'flat' | 'percent'
  discount_value NUMERIC(12,2) NOT NULL,
  max_discount NUMERIC(12,2),
  min_order_amount NUMERIC(12,2) DEFAULT 0,
  valid_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_until TIMESTAMPTZ,
  usage_limit INT,
  times_used INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- ======================= GOVERNMENT TENDER MODULE =======================
-- Separate from the normal marketplace (materials/orders above). BuildTruck
-- is a coordination/listing layer only here — it does NOT award tenders or
-- represent any government body; see docs/ARCHITECTURE.md §13.

CREATE TABLE tender_materials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id) ON DELETE CASCADE,
  category_id UUID REFERENCES categories(id),   -- reuses the normal catalog's categories
  material_name VARCHAR(255) NOT NULL,
  quantity NUMERIC(14,2) NOT NULL,
  unit unit_type NOT NULL,
  rate NUMERIC(12,2) NOT NULL,
  supply_location VARCHAR(255) NOT NULL,
  service_area VARCHAR(255),
  is_available BOOLEAN NOT NULL DEFAULT true,
  verification_status supplier_verification_status NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_tender_materials_supplier ON tender_materials(supplier_id);
CREATE INDEX idx_tender_materials_category ON tender_materials(category_id, verification_status);

CREATE TABLE tender_trucks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id) ON DELETE CASCADE,
  vehicle_category VARCHAR(30) NOT NULL CHECK (vehicle_category IN (
    '6_wheeler','10_wheeler','12_wheeler','16_wheeler','18_wheeler',
    'tractor','tractor_trolley','pickup','mini_truck','other'
  )),
  capacity_bracket VARCHAR(20) CHECK (capacity_bracket IN (
    '1_ton','2_ton','3_ton','5_ton','7_ton','10_ton','15_ton','20_ton','25_ton_plus'
  )),
  capacity_tons NUMERIC(6,2),
  registration_number VARCHAR(20) NOT NULL,
  current_lat NUMERIC(9,6),
  current_lng NUMERIC(9,6),
  rate_per_trip NUMERIC(12,2),
  rate_per_km NUMERIC(12,2),
  driver_name VARCHAR(255),
  driver_phone VARCHAR(15),
  vehicle_details TEXT,
  is_available BOOLEAN NOT NULL DEFAULT true,
  verification_status supplier_verification_status NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_tender_trucks_supplier ON tender_trucks(supplier_id);
CREATE INDEX idx_tender_trucks_category ON tender_trucks(vehicle_category, verification_status);

-- ======================= SERVICE REQUESTS (generic "send requirement") ====
-- One table covers three cases so we don't triplicate near-identical
-- tables: a customer requesting a standalone truck hire (target = trucks.id),
-- or a tender user requesting materials/trucks (target = tender_materials.id
-- / tender_trucks.id). target_id is intentionally NOT a foreign key since
-- it's polymorphic across three source tables — request_type says which one.
CREATE TYPE service_request_type AS ENUM ('TRUCK_HIRE', 'TENDER_MATERIAL', 'TENDER_TRUCK');
CREATE TYPE service_request_status AS ENUM ('OPEN', 'CONTACTED', 'CLOSED');

CREATE TABLE service_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  request_type service_request_type NOT NULL,
  requester_id UUID NOT NULL REFERENCES users(id),
  target_id UUID NOT NULL,              -- trucks.id | tender_materials.id | tender_trucks.id, by request_type
  quantity NUMERIC(14,2),
  message TEXT,
  contact_phone VARCHAR(15),
  status service_request_status NOT NULL DEFAULT 'OPEN',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_service_requests_target ON service_requests(request_type, target_id);
CREATE INDEX idx_service_requests_requester ON service_requests(requester_id);

-- ======================= ADMIN-CONFIGURABLE SETTINGS =======================
-- Single-row (or key/value) config table so pricing & commission are NEVER hard-coded.
CREATE TABLE admin_settings (
  key VARCHAR(100) PRIMARY KEY,
  value JSONB NOT NULL,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO admin_settings (key, value) VALUES
  ('commission_percent', '5'),
  ('commissionable_components', '["material_cost","delivery_charge"]'),
  ('base_delivery_charge', '100'),
  ('per_km_charge', '15'),
  ('min_delivery_charge', '100'),
  ('max_delivery_distance_km', '150'),
  ('platform_flat_charge', '0');
