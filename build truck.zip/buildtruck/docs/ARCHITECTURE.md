# BuildTruck — Architecture & Product Plan (MVP)

> India-wide marketplace connecting customers who need construction materials
> (sand, gitti, bricks, cement, etc.) with verified suppliers/truck owners who
> supply + deliver them. One app, three roles: Customer, Supplier, Admin.

## 1. High-Level Architecture

```
Mobile App (React Native/Expo)        Admin Web Dashboard (Next.js)
  Customer + Supplier mode                    |
        \                                     |
         \                                    v
          ---------------------> Backend API (Node.js + TypeScript, Express)
                                              |
                        -----------------------------------------
                        |              |                        |
                 PostgreSQL      Redis (cache /          External services:
                 (primary DB)     live-location TTL)      Payment gateway (mocked)
                                                            Maps/Geo (mocked)
                                                            FCM push notifications
```

**Why this stack:** React Native/Expo gives one codebase for the customer+supplier
mobile experience across Android/iOS (Android matters most for India). Next.js
gives a fast admin dashboard. Node/TypeScript backend keeps the whole system in
one language, Express for a simple, well-understood REST API (GraphQL would be
over-engineering for an MVP). PostgreSQL is relational and ACID-compliant — this
is a financial system as much as a marketplace, so correctness matters more than
schema flexibility.

## 2. Complete User Flow (Customer)

1. Open app -> allow location or enter address
2. Browse categories or search materials
3. Pick material -> set quantity
4. App shows suppliers who serve that delivery location
5. Pick supplier -> confirm/edit delivery address
6. **Backend** computes distance -> delivery charge -> total (client never computes money)
7. Customer sees full price breakdown, picks UPI or Cash
8. Places order -> supplier notified
9. Supplier accepts -> assigns truck -> customer notified
10. Truck shares live location while delivery is active
11. Truck arrives -> delivery OTP generated
12. Customer enters OTP -> order -> COMPLETED
13. Commission recorded server-side, added to supplier's ledger
14. Customer rates supplier

## 3. Order Status State Machine

```
PENDING -> ACCEPTED -> TRUCK_ASSIGNED -> PICKUP_STARTED -> OUT_FOR_DELIVERY
   -> ARRIVING -> DELIVERED -> COMPLETED
PENDING/ACCEPTED -> CANCELLED (customer or supplier, before pickup only)
COMPLETED -> REFUNDED (admin-initiated, exceptional path)
```
Transitions are enforced server-side only (see `orderService.ts`) — the app
can request a transition, but the backend is the single source of truth for
what's a legal next state.

## 4. Pricing Logic (server-side, admin-configurable)

```
materialCost      = unitPrice x quantity              (from supplier_materials)
deliveryDistance  = computed via locationService (geocode + route/haversine)
deliveryCharge    = max(minDeliveryCharge,
                         baseDeliveryCharge + perKmCharge x distanceKm)
                     capped by maxDeliveryDistance (order rejected beyond it)
platformCharges   = optional flat/percentage fee, admin-configurable, default 0
discount          = coupon engine (admin-configurable), default 0
finalTotal        = materialCost + deliveryCharge + platformCharges - discount
```
All of `baseDeliveryCharge`, `perKmCharge`, `minDeliveryCharge`,
`maxDeliveryDistance` live in `admin_settings`, not code — see `pricingService.ts`.

## 5. Commission Logic (server-side, admin-configurable)

```
commissionRate       = admin_settings.commission_percent   (default 5%)
commissionableAmount = materialCost + deliveryCharge   (platformCharges excluded
                        by default — admin setting decides what's commissionable)
commissionAmount     = commissionableAmount x commissionRate / 100
```
- **UPI order:** platform collects payment -> commission is deducted at
  settlement -> net amount transferred to supplier (transfer step is a stub
  until a real payment gateway with payouts is integrated).
- **Cash order:** platform never touches the cash. On COMPLETED, a
  `commission_ledger` row is created with status `PAYABLE`. Supplier sees a
  running "pending commission" balance and settles it periodically (UPI to
  platform / admin marks as settled). This is never presented to the supplier
  as "the platform received your cash" — it's explicitly a payable balance.

## 6. Payment Architecture

`PaymentProvider` interface (see `paymentService.ts`) with a `MockPaymentProvider`
for MVP. Swapping to Razorpay/PayU/Cashfree later means implementing the same
interface — no other code changes. Card/UPI credentials are never stored;
only provider references (payment IDs) are persisted.

Payment statuses: `PENDING, SUCCESS, FAILED, REFUNDED, PARTIALLY_REFUNDED`

**ENVIRONMENT VARIABLE REQUIRED** for real integration:
`PAYMENT_PROVIDER_KEY_ID`, `PAYMENT_PROVIDER_KEY_SECRET`, `PAYMENT_WEBHOOK_SECRET`

## 7. Live Tracking Architecture

- `live_locations` table (or Redis, TTL'd) stores the latest truck ping —
  only written while `orders.status` is in an active-delivery state.
- Driver app pings `/orders/:id/location` every N seconds during
  `PICKUP_STARTED` -> `ARRIVING`; writes stop immediately outside that window.
- Customer app polls (MVP) or subscribes via WebSocket (V2) to get location +
  ETA. ETA = distance-to-destination / provider's route ETA, via
  `locationService.ts`'s `MapProvider` abstraction (mocked for MVP; swap in
  Google Maps Distance Matrix / Mapbox Directions later).

**ENVIRONMENT VARIABLE REQUIRED:** `MAPS_PROVIDER_API_KEY`

## 8. Security Model

- JWT auth, role claim (`customer | supplier | admin`) checked by middleware
  on every protected route.
- **All money math (material cost, delivery charge, commission) is
  recalculated server-side on order creation** — client-submitted prices are
  never trusted, only used as a display hint.
- Admin routes require `role=admin` + are separately rate-limited.
- Documents (supplier verification) stored in private cloud storage with
  signed URLs, never public.
- Delivery OTP is single-use, expires with the order, hashed at rest.

## 9. Screen Map

**Customer**
Home (location, search, categories, popular materials, nearby suppliers,
recent orders) -> Category list -> Material detail -> Supplier comparison ->
Cart (qty, delivery charge, total, payment method) -> Address confirm ->
Order placed -> Order tracking (map, ETA, status) -> OTP confirm -> Rate
supplier -> Order history -> Support/complaint

**Supplier mode** (same app, mode switch)
Supplier dashboard (today's orders, pending, active deliveries, earnings,
pending commission) -> Orders list -> Order detail (accept/reject, assign
truck, update status) -> Materials (list/add/edit) -> Trucks (list/add/edit)
-> Earnings & settlement history -> Profile & verification status

**Admin (web dashboard)**
Overview (KPIs + charts) -> Customers -> Suppliers (approve/verify) -> Trucks ->
Materials/Categories -> Orders -> Payments -> Commission ledger -> Settlements ->
Complaints -> Coupons/offers -> Settings (commission %, delivery pricing,
max distance, categories)

## 10. Database

See `db/schema.sql`. Tables: users, customer_profiles, supplier_profiles,
driver_profiles, trucks, categories, materials, supplier_materials,
addresses, orders, order_items, order_status_history, payments,
commission_ledger, settlements, reviews, notifications, support_tickets,
live_locations, coupons, admin_settings.

## 11. MVP Scope vs Roadmap

**MVP (this build):** auth + roles, material listing/search, supplier
profiles, distance-based pricing, cart -> order, Cash + mock-UPI payment,
supplier order management, OTP delivery confirmation, commission ledger,
admin dashboard core, basic notifications, ratings.

**V2:** real payment gateway + payouts, WebSocket live tracking, in-app
chat, coupon engine, multi-truck route optimization, supplier payout
automation, fraud/abuse detection.

**V3 / Scale:** multi-language, regional pricing rules, bulk/B2B orders,
supplier inventory forecasting, dedicated logistics partner network,
separate high-volume driver app.

## 12. Legal / Compliance — NOT done automatically

This MVP includes **placeholders only** for Terms & Conditions, Privacy
Policy, Refund/Cancellation Policy, Supplier Agreement, Commission
Agreement, and GST/invoice fields. None of this is legally reviewed.
Get a lawyer/CA to review before real transactions go live, especially:
GST applicability on commission vs. material sales, RBI rules around
holding/passing through customer payments, and state-level trade licenses
for construction material resale/transport.

## 13. Vehicle Categories & Standalone Truck Hire

Trucks (both the normal marketplace `trucks` table and the tender
module's `tender_trucks`) carry a fixed **vehicle category** (6/10/12/16/18
Wheeler, Tractor, Tractor + Trolley, Pickup, Mini Truck, Other) and a
separate **capacity bracket** (1–25+ Ton), enforced by CHECK constraints in
`db/schema.sql` so the option set can be extended later without an
`ALTER TYPE`. Trucks also carry `rate_per_trip`, `rate_per_km`, and a
current lat/lng so customers can search/filter by category, capacity,
location, availability, and price via `GET /trucks/search` — independent
of the material-ordering flow, for hiring a truck directly.

## 14. Government Tender Module

A separate, additional section — it does not replace or modify the normal
marketplace. Suppliers list materials and trucks specifically earmarked
for government-project requirements (`tender_materials`, `tender_trucks`),
each starting `PENDING` until an admin verifies it. Tender users search
these listings and send a requirement/request, recorded in a generic
`service_requests` table (also used for standalone truck-hire requests, to
avoid three near-identical tables).

**Important:** BuildTruck's tender module is a coordination/listing layer
only. It does not process, evaluate, or award government tenders, and is
not an official government portal — this is stated on every tender screen
in the app and admin dashboard.

## 10 Alternative Brand Name Suggestions (BuildTruck stays the placeholder)

1. MaalMove
2. TruckMandi
3. GitiGo
4. LoadSetu
5. BuildKart Direct
6. SandTruck
7. MaterialYaan
8. NirmanNow
9. TruckSaathi
10. GharBuild Express

## 15. Advanced modules (migration 002)
RFQ/quotations, multi-truck trips, proof of delivery, business accounts &
projects, disputes, document verification, inventory, invoices, notifications
and advanced delivery pricing are additive: tables in
`db/migrations/002_advanced_features.sql`, services in `backend/src/services`,
routes mounted in `backend/src/index.ts`. Single-truck orders are untouched
(no rows in `order_trips`). Government Tender remains a separate module.
See README for what is wired to UI and known limitations.
