import { useEffect, useState, useCallback } from 'react';
import { fetchJson } from './api';

// Fetches a real admin list from the backend. No sample-data fallback: if
// the backend is unreachable, the page shows the error instead of
// presenting invented rows as if they were real records.
export function useAdminList<T = any>(path: string) {
  const [rows, setRows] = useState<T[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchJson<{ results: T[] }>(path);
      setRows(res.results); setError(null);
    } catch (e) { setError((e as Error).message); } finally { setLoading(false); }
  }, [path]);
  useEffect(() => { reload(); }, [reload]);
  return { rows, error, loading, reload };
}
