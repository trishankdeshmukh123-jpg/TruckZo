/** @type {import('next').NextConfig} */
module.exports = {
  reactStrictMode: true,
  env: {
    // ENVIRONMENT VARIABLE REQUIRED: point this at the deployed backend API.
    NEXT_PUBLIC_API_BASE_URL: process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000',
  },
};
