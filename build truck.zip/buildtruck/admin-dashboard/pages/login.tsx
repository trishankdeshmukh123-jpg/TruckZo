import React, { useState } from 'react';
import { useRouter } from 'next/router';
import { fetchJson, setToken } from '../lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const res = await fetchJson<{ token: string; role: string }>('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      if (res.role !== 'admin') { setError('This account is not an admin.'); return; }
      setToken(res.token);
      router.push('/');
    } catch (err) { setError((err as Error).message); }
  }

  return (
    <div style={{ maxWidth: 360, margin: '120px auto' }} className="card">
      <h2 style={{ marginTop: 0 }}>BuildTruck Admin</h2>
      <form onSubmit={submit}>
        <div className="formRow"><label>Email</label><input value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div className="formRow"><label>Password</label><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        {error && <p style={{ color: 'var(--danger)' }}>{error}</p>}
        <button className="btn primary" type="submit">Sign in</button>
      </form>
    </div>
  );
}
