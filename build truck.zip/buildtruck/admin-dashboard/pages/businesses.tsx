import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/businesses');
  return (
    <Layout>
      <h1 className="pageTitle">Business accounts</h1>
      <p className="pageSubtitle">Contractor / builder business accounts.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Name</th><th>GSTIN</th><th>Owner</th><th>Created</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.name ?? "")}</td><td>{String(r.gstin ?? "")}</td><td>{String(r.owner_name ?? "")}</td><td>{String(r.created_at ?? "")}</td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
