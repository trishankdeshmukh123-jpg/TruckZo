import React, { useState } from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';
import { fetchJson } from '../lib/api';

export default function VerificationPage() {
  const { rows, error, loading, reload } = useAdminList<any>('/verification/documents');
  const [msg, setMsg] = useState('');

  async function decide(id: string, status: 'VERIFIED' | 'REJECTED') {
    try { await fetchJson(`/verification/documents/${id}/decide`, { method: 'POST', body: JSON.stringify({ status }) }); reload(); }
    catch (e) { setMsg((e as Error).message); }
  }
  async function runExpiry() {
    try { await fetchJson('/admin/maintenance/expire-documents', { method: 'POST' }); setMsg('Expiry check run.'); reload(); }
    catch (e) { setMsg((e as Error).message); }
  }

  return (
    <Layout>
      <h1 className="pageTitle">Supplier & truck verification</h1>
      <p className="pageSubtitle">Verify or reject uploaded documents. Run the expiry check periodically (or via cron hitting /admin/maintenance/expire-documents).</p>
      <button className="btn" onClick={runExpiry}>Run document expiry check</button>
      {error && <div className="noteBox">Could not load: {error}</div>}
      {msg && <p>{msg}</p>}
      {loading ? <p>Loading…</p> : (
        <table style={{ marginTop: 16 }}>
          <thead><tr><th>Owner</th><th>Document</th><th>File</th><th>Expiry</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {rows.map((d: any) => (
              <tr key={d.id}>
                <td>{d.owner_type}</td><td>{d.doc_type}</td>
                <td><a href={d.file_url} target="_blank" rel="noreferrer">open</a></td>
                <td>{d.expiry_date ?? '—'}</td><td><Badge label={d.status} /></td>
                <td style={{ display: 'flex', gap: 6 }}>
                  <button className="btn primary" onClick={() => decide(d.id, 'VERIFIED')}>Verify</button>
                  <button className="btn danger" onClick={() => decide(d.id, 'REJECTED')}>Reject</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
