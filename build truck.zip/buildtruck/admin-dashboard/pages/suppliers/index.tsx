import React, { useState } from 'react';
import Link from 'next/link';
import Layout from '../../components/Layout';
import Badge from '../../components/Badge';
import { suppliers as sampleSuppliers } from '../../data/sampleAdminData';
import { formatINR } from '../../lib/api';

export default function SuppliersPage() {
  const [suppliers, setSuppliers] = useState(sampleSuppliers);

  function setStatus(id: string, status: 'APPROVED' | 'REJECTED' | 'SUSPENDED') {
    // Real implementation: POST /admin/suppliers/:id/verify (not yet built
    // — see backend README, and supplier_profiles.verification_status in
    // db/schema.sql). Updates local state for the demo.
    setSuppliers((prev) => prev.map((s) => (s.id === id ? { ...s, status } : s)));
  }

  return (
    <Layout>
      <h1 className="pageTitle">Suppliers</h1>
      <p className="pageSubtitle">Approve, reject, or suspend suppliers. Verification documents are reviewed here.</p>
      <table>
        <thead>
          <tr><th>Business</th><th>City</th><th>Rating</th><th>Orders</th><th>Pending commission</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
          {suppliers.map((s) => (
            <tr key={s.id}>
              <td>{s.name}</td><td>{s.city}</td><td>⭐ {s.rating}</td><td>{s.orders}</td>
              <td>{formatINR(s.pendingCommission)}</td>
              <td><Badge label={s.status} /></td>
              <td style={{ display: 'flex', gap: 6 }}>
                {s.status !== 'APPROVED' && <button className="btn primary" onClick={() => setStatus(s.id, 'APPROVED')}>Approve</button>}
                {s.status !== 'REJECTED' && <button className="btn danger" onClick={() => setStatus(s.id, 'REJECTED')}>Reject</button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Layout>
  );
}
