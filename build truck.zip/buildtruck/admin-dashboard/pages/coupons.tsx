import React from 'react';
import Layout from '../components/Layout';

const sampleCoupons = [
  { id: 'cp-1', code: 'FIRST100', type: 'flat', value: 100, minOrder: 1000, used: 214, active: true },
  { id: 'cp-2', code: 'MONSOON10', type: 'percent', value: 10, minOrder: 5000, used: 58, active: true },
];

export default function CouponsPage() {
  return (
    <Layout>
      <h1 className="pageTitle">Coupons & Offers</h1>
      <p className="pageSubtitle">Promotional discount codes, backed by db/schema.sql's coupons table.</p>
      <table>
        <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Min order</th><th>Used</th><th>Status</th></tr></thead>
        <tbody>
          {sampleCoupons.map((c) => (
            <tr key={c.id}>
              <td>{c.code}</td><td>{c.type}</td>
              <td>{c.type === 'flat' ? `₹${c.value}` : `${c.value}%`}</td>
              <td>₹{c.minOrder}</td><td>{c.used}</td>
              <td>{c.active ? <span className="badge success">Active</span> : <span className="badge default">Inactive</span>}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="btn primary" style={{ marginTop: 16 }}>+ Create coupon</button>
    </Layout>
  );
}
