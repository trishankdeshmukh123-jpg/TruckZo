import React from 'react';
import Layout from '../components/Layout';
import { materials, categories } from '../data/sampleAdminData';

export default function MaterialsPage() {
  return (
    <Layout>
      <h1 className="pageTitle">Materials & Categories</h1>
      <p className="pageSubtitle">Add, rename, or deactivate categories and the catalog-level materials under them.</p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div>
          <h3>Categories</h3>
          <table>
            <thead><tr><th>Name</th><th>Materials</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {categories.map((c) => (
                <tr key={c.id}>
                  <td>{c.name}</td><td>{c.materials}</td>
                  <td>{c.active ? <span className="badge success">Active</span> : <span className="badge default">Inactive</span>}</td>
                  <td><button className="btn">Edit</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="btn primary" style={{ marginTop: 12 }}>+ Add category</button>
        </div>

        <div>
          <h3>Materials (catalog)</h3>
          <table>
            <thead><tr><th>Name</th><th>Category</th><th>Suppliers</th><th>Status</th></tr></thead>
            <tbody>
              {materials.map((m) => (
                <tr key={m.id}>
                  <td>{m.name}</td><td>{m.category}</td><td>{m.suppliers}</td>
                  <td>{m.active ? <span className="badge success">Active</span> : <span className="badge default">Inactive</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="btn primary" style={{ marginTop: 12 }}>+ Add material</button>
        </div>
      </div>
    </Layout>
  );
}
