import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/pods');
  return (
    <Layout>
      <h1 className="pageTitle">Proof of delivery</h1>
      <p className="pageSubtitle">Audit view of all PODs.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Order</th><th>Delivered qty</th><th>Shortage notes</th><th>OTP verified</th><th>Delivered at</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.order_number ?? "")}</td><td>{String(r.delivered_quantity ?? "")}</td><td>{String(r.shortage_notes ?? "")}</td><td>{String(r.otp_verified ?? "")}</td><td>{String(r.delivered_at ?? "")}</td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
