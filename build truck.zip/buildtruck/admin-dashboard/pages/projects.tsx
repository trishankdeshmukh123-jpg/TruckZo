import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/projects');
  return (
    <Layout>
      <h1 className="pageTitle">Projects</h1>
      <p className="pageSubtitle">Projects across all business accounts.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Project</th><th>Business</th><th>Type</th><th>Site</th><th>Start</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.name ?? "")}</td><td>{String(r.business_name ?? "")}</td><td>{String(r.project_type ?? "")}</td><td>{String(r.site_address ?? "")}</td><td>{String(r.start_date ?? "")}</td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
