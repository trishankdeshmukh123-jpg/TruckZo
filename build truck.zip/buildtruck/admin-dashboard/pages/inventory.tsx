import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/inventory');
  return (
    <Layout>
      <h1 className="pageTitle">Inventory</h1>
      <p className="pageSubtitle">Supplier stock levels across the platform.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Supplier</th><th>Material</th><th>Available</th><th>Reserved</th><th>Sold</th><th>Low-stock threshold</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.business_name ?? "")}</td><td>{String(r.material_name ?? "")}</td><td>{String(r.available_quantity ?? "")}</td><td>{String(r.reserved_quantity ?? "")}</td><td>{String(r.sold_quantity ?? "")}</td><td>{String(r.low_stock_threshold ?? "")}</td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
