import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/quotes');
  return (
    <Layout>
      <h1 className="pageTitle">Quotations</h1>
      <p className="pageSubtitle">All supplier quotations on RFQs.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>RFQ material</th><th>Supplier</th><th>Rate</th><th>Qty</th><th>Days</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.material_name ?? "")}</td><td>{String(r.business_name ?? "")}</td><td>{String(r.price_per_unit ?? "")}</td><td>{String(r.available_quantity ?? "")}</td><td>{String(r.delivery_time_days ?? "")}</td><td><Badge label={String(r.status)} /></td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
