import React from 'react';
import Layout from '../../components/Layout';
import Badge from '../../components/Badge';
import { useAdminList } from '../../lib/useAdminList';
import { formatINR } from '../../lib/api';

export default function OrdersPage() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/orders');
  return (
    <Layout>
      <h1 className="pageTitle">Orders</h1>
      <p className="pageSubtitle">All orders across the platform (live from the database).</p>
      {error && <div className="noteBox">Could not load: {error}</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Order #</th><th>Customer</th><th>Supplier</th><th>Total</th><th>Payment</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map((o: any) => (
              <tr key={o.id}>
                <td>{o.order_number}</td><td>{o.customer_name}</td><td>{o.supplier_name}</td>
                <td>{formatINR(Number(o.total_amount))}</td><td>{o.payment_method}</td><td><Badge label={o.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
