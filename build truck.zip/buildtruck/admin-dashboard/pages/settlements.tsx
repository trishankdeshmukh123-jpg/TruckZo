import React from 'react';
import Layout from '../components/Layout';
import { settlements } from '../data/sampleAdminData';
import { formatINR } from '../lib/api';

export default function SettlementsPage() {
  return (
    <Layout>
      <h1 className="pageTitle">Settlements</h1>
      <p className="pageSubtitle">Record of commission actually collected from suppliers on Cash orders.</p>
      <table>
        <thead><tr><th>Supplier</th><th>Amount</th><th>Method</th><th>Settled on</th></tr></thead>
        <tbody>
          {settlements.map((s) => (
            <tr key={s.id}><td>{s.supplier}</td><td>{formatINR(s.amount)}</td><td>{s.method}</td><td>{s.settledAt}</td></tr>
          ))}
        </tbody>
      </table>
      <button className="btn primary" style={{ marginTop: 16 }}>+ Record manual settlement</button>
    </Layout>
  );
}
