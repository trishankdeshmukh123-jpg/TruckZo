import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/trips');
  return (
    <Layout>
      <h1 className="pageTitle">Trips (multi-load)</h1>
      <p className="pageSubtitle">Individual trips of multi-truck orders.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Order</th><th>Trip #</th><th>Load</th><th>Driver</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.order_number ?? "")}</td><td>{String(r.trip_number ?? "")}</td><td>{String(r.load_quantity ?? "")}</td><td>{String(r.driver_name ?? "")}</td><td><Badge label={String(r.status)} /></td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
