import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/invoices');
  return (
    <Layout>
      <h1 className="pageTitle">Invoices</h1>
      <p className="pageSubtitle">All generated invoices.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Invoice #</th><th>Order</th><th>Material</th><th>Delivery</th><th>Total</th><th>Generated</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.invoice_number ?? "")}</td><td>{String(r.order_number ?? "")}</td><td>{String(r.material_charges ?? "")}</td><td>{String(r.delivery_charges ?? "")}</td><td>{String(r.total_amount ?? "")}</td><td>{String(r.generated_at ?? "")}</td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
