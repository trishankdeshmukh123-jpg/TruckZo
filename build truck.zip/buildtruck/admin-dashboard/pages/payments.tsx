import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { payments } from '../data/sampleAdminData';
import { formatINR } from '../lib/api';

export default function PaymentsPage() {
  return (
    <Layout>
      <h1 className="pageTitle">Payments</h1>
      <p className="pageSubtitle">UPI payment records (Cash orders are not platform payments — see Commission Ledger for what suppliers owe on them).</p>
      <table>
        <thead><tr><th>Order #</th><th>Method</th><th>Amount</th><th>Provider</th><th>Status</th></tr></thead>
        <tbody>
          {payments.map((p) => (
            <tr key={p.id}>
              <td>{p.orderNumber}</td><td>{p.method}</td><td>{formatINR(p.amount)}</td><td>{p.provider}</td>
              <td><Badge label={p.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </Layout>
  );
}
