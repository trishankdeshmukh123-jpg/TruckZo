import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { commissionLedger } from '../data/sampleAdminData';
import { formatINR } from '../lib/api';

export default function CommissionPage() {
  return (
    <Layout>
      <h1 className="pageTitle">Commission Ledger</h1>
      <p className="pageSubtitle">
        Every completed order's commission, whether already settled or still payable. Cash orders show
        as PAYABLE until the supplier settles or you mark it settled manually.
      </p>
      <table>
        <thead><tr><th>Order #</th><th>Supplier</th><th>Commissionable amount</th><th>Rate</th><th>Commission</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {commissionLedger.map((c) => (
            <tr key={c.id}>
              <td>{c.orderNumber}</td><td>{c.supplier}</td><td>{formatINR(c.commissionableAmount)}</td>
              <td>{c.rate}%</td><td>{formatINR(c.amount)}</td>
              <td><Badge label={c.status} /></td>
              <td>{c.status === 'PAYABLE' && <button className="btn primary">Mark settled</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Layout>
  );
}
