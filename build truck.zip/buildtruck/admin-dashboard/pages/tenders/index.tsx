import React, { useState } from 'react';
import Layout from '../../components/Layout';
import Badge from '../../components/Badge';
import { tenderMaterials as sampleMaterials, tenderTrucks as sampleTrucks } from '../../data/sampleAdminData';
import { formatINR } from '../../lib/api';

export default function TendersPage() {
  const [materials, setMaterials] = useState(sampleMaterials);
  const [trucks, setTrucks] = useState(sampleTrucks);

  function verifyMaterial(id: string, status: 'APPROVED' | 'REJECTED') {
    // Real implementation: POST /admin/tender/materials/:id/verify (built —
    // see backend/src/routes/admin.ts). Updates local state for the demo.
    setMaterials((prev) => prev.map((m) => (m.id === id ? { ...m, status } : m)));
  }
  function verifyTruck(id: string, status: 'APPROVED' | 'REJECTED') {
    setTrucks((prev) => prev.map((t) => (t.id === id ? { ...t, status } : t)));
  }

  return (
    <Layout>
      <h1 className="pageTitle">Government Tenders</h1>
      <p className="pageSubtitle">
        Verify tender material and truck listings before they appear in tender search. BuildTruck is a
        coordination platform only — it does not award tenders or represent any government body.
      </p>

      <h3>Materials</h3>
      <table>
        <thead><tr><th>Material</th><th>Supplier</th><th>Quantity</th><th>Rate</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          {materials.map((m) => (
            <tr key={m.id}>
              <td>{m.materialName}</td><td>{m.supplier}</td><td>{m.quantity} {m.unit}</td>
              <td>{formatINR(m.rate)}/{m.unit}</td><td>{m.location}</td>
              <td><Badge label={m.status} /></td>
              <td style={{ display: 'flex', gap: 6 }}>
                {m.status !== 'APPROVED' && <button className="btn primary" onClick={() => verifyMaterial(m.id, 'APPROVED')}>Approve</button>}
                {m.status !== 'REJECTED' && <button className="btn danger" onClick={() => verifyMaterial(m.id, 'REJECTED')}>Reject</button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3 style={{ marginTop: 32 }}>Trucks</h3>
      <table>
        <thead><tr><th>Category</th><th>Reg. No.</th><th>Capacity</th><th>Supplier</th><th>Rate/trip</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          {trucks.map((t) => (
            <tr key={t.id}>
              <td>{t.vehicleCategory}</td><td>{t.registrationNumber}</td><td>{t.capacityBracket}</td>
              <td>{t.supplier}</td><td>{formatINR(t.ratePerTrip)}</td>
              <td><Badge label={t.status} /></td>
              <td style={{ display: 'flex', gap: 6 }}>
                {t.status !== 'APPROVED' && <button className="btn primary" onClick={() => verifyTruck(t.id, 'APPROVED')}>Approve</button>}
                {t.status !== 'REJECTED' && <button className="btn danger" onClick={() => verifyTruck(t.id, 'REJECTED')}>Reject</button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Layout>
  );
}
