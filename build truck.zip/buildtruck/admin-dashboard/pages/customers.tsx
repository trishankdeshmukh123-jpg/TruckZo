import React, { useState } from 'react';
import Layout from '../components/Layout';
import { customers as sampleCustomers } from '../data/sampleAdminData';

export default function CustomersPage() {
  const [customers, setCustomers] = useState(sampleCustomers);

  function toggleSuspend(id: string) {
    // Real implementation: POST /admin/customers/:id/suspend (not yet
    // built — see backend README). Updates local state for the demo.
    setCustomers((prev) => prev.map((c) => (c.id === id ? { ...c, suspended: !c.suspended } : c)));
  }

  return (
    <Layout>
      <h1 className="pageTitle">Customers</h1>
      <p className="pageSubtitle">{customers.length} customers on the platform.</p>
      <table>
        <thead>
          <tr><th>Name</th><th>Phone</th><th>City</th><th>Orders</th><th>Joined</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
          {customers.map((c) => (
            <tr key={c.id}>
              <td>{c.name}</td><td>{c.phone}</td><td>{c.city}</td><td>{c.orders}</td><td>{c.joined}</td>
              <td>{c.suspended ? <span className="badge danger">Suspended</span> : <span className="badge success">Active</span>}</td>
              <td><button className="btn" onClick={() => toggleSuspend(c.id)}>{c.suspended ? 'Unsuspend' : 'Suspend'}</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </Layout>
  );
}
