import React from 'react';
import Layout from '../components/Layout';
import { formatINR } from '../lib/api';
import { kpis, ordersByDay, popularMaterials } from '../data/sampleAdminData';

export default function OverviewPage() {
  const maxOrders = Math.max(...ordersByDay.map((d) => d.count));
  const maxMaterial = Math.max(...popularMaterials.map((m) => m.orders));

  return (
    <Layout>
      <h1 className="pageTitle">Overview</h1>
      <p className="pageSubtitle">Platform-wide KPIs across all customers, suppliers and orders.</p>

      <div className="kpiGrid">
        <Kpi label="Total users" value={kpis.totalUsers.toLocaleString('en-IN')} />
        <Kpi label="Active suppliers" value={kpis.activeSuppliers.toLocaleString('en-IN')} />
        <Kpi label="Total orders" value={kpis.totalOrders.toLocaleString('en-IN')} />
        <Kpi label="Completed orders" value={kpis.completedOrders.toLocaleString('en-IN')} />
        <Kpi label="Cancelled orders" value={kpis.cancelledOrders.toLocaleString('en-IN')} />
        <Kpi label="Gross order value" value={formatINR(kpis.grossOrderValue)} />
        <Kpi label="Platform commission" value={formatINR(kpis.platformCommission)} />
        <Kpi label="Pending supplier settlements" value={formatINR(kpis.pendingSettlements)} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Orders this week</h3>
          {ordersByDay.map((d) => (
            <div key={d.day} style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span>{d.day}</span><span>{d.count}</span>
              </div>
              <div className="bar"><div className="barFill" style={{ width: `${(d.count / maxOrders) * 100}%` }} /></div>
            </div>
          ))}
        </div>

        <div className="card">
          <h3 style={{ marginTop: 0 }}>Popular materials</h3>
          {popularMaterials.map((m) => (
            <div key={m.name} style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span>{m.name}</span><span>{m.orders}</span>
              </div>
              <div className="bar"><div className="barFill" style={{ width: `${(m.orders / maxMaterial) * 100}%` }} /></div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div className="card">
      <div className="kpiLabel">{label}</div>
      <div className="kpiValue">{value}</div>
    </div>
  );
}
