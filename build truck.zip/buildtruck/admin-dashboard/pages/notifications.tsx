import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/notifications');
  return (
    <Layout>
      <h1 className="pageTitle">Notifications log</h1>
      <p className="pageSubtitle">Recent notifications sent to users.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>User</th><th>Type</th><th>Title</th><th>Read</th><th>Created</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.full_name ?? "")}</td><td>{String(r.type ?? "")}</td><td>{String(r.title ?? "")}</td><td>{String(r.is_read ?? "")}</td><td>{String(r.created_at ?? "")}</td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
