// This page is wired to the REAL backend endpoints already implemented in
// backend/src/routes/admin.ts — GET /admin/settings/pricing,
// GET /admin/settings/commission, POST /admin/settings. Everything the
// spec calls out as "must be configurable, not hard-coded" lives here:
// commission %, base delivery charge, per-km charge, min delivery charge,
// max delivery distance.

import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { fetchJson } from '../lib/api';

interface PricingSettings {
  baseDeliveryCharge: number; perKmCharge: number; minDeliveryCharge: number; maxDeliveryDistanceKm: number;
}
interface CommissionSettings { commissionPercent: number; }

const FALLBACK_PRICING: PricingSettings = { baseDeliveryCharge: 100, perKmCharge: 15, minDeliveryCharge: 100, maxDeliveryDistanceKm: 150 };
const FALLBACK_COMMISSION: CommissionSettings = { commissionPercent: 5 };

export default function SettingsPage() {
  const [pricing, setPricing] = useState<PricingSettings>(FALLBACK_PRICING);
  const [commission, setCommission] = useState<CommissionSettings>(FALLBACK_COMMISSION);
  const [usingFallback, setUsingFallback] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const [p, c] = await Promise.all([
          fetchJson<PricingSettings>('/admin/settings/pricing'),
          fetchJson<CommissionSettings>('/admin/settings/commission'),
        ]);
        setPricing(p); setCommission(c);
      } catch {
        setUsingFallback(true); // backend not running — showing seeded defaults from db/schema.sql
      }
    })();
  }, []);

  async function save(key: string, value: number) {
    setSaving(true); setSavedMsg('');
    try {
      await fetchJson('/admin/settings', { method: 'POST', body: JSON.stringify({ key, value }) });
      setSavedMsg(`Saved ${key} = ${value}`);
    } catch {
      setSavedMsg('Could not reach backend — start it locally to persist changes (see backend/README).');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Layout>
      <h1 className="pageTitle">Settings</h1>
      <p className="pageSubtitle">Commission and delivery pricing — changing these here takes effect immediately, no code deploy.</p>
      {usingFallback && (
        <div className="noteBox">
          Backend isn't reachable right now — showing the same default values seeded in db/schema.sql.
          Start the backend (see backend/README.md) to load and save real values.
        </div>
      )}

      <div className="card" style={{ maxWidth: 480, marginBottom: 20 }}>
        <h3 style={{ marginTop: 0 }}>Commission</h3>
        <div className="formRow">
          <label>Default commission percentage</label>
          <input
            type="number" value={commission.commissionPercent}
            onChange={(e) => setCommission({ commissionPercent: Number(e.target.value) })}
          />
        </div>
        <button className="btn primary" disabled={saving} onClick={() => save('commission_percent', commission.commissionPercent)}>
          Save commission %
        </button>
      </div>

      <div className="card" style={{ maxWidth: 480 }}>
        <h3 style={{ marginTop: 0 }}>Delivery pricing</h3>
        <div className="formRow">
          <label>Base delivery charge (₹)</label>
          <input type="number" value={pricing.baseDeliveryCharge} onChange={(e) => setPricing({ ...pricing, baseDeliveryCharge: Number(e.target.value) })} />
        </div>
        <div className="formRow">
          <label>Per-km charge (₹)</label>
          <input type="number" value={pricing.perKmCharge} onChange={(e) => setPricing({ ...pricing, perKmCharge: Number(e.target.value) })} />
        </div>
        <div className="formRow">
          <label>Minimum delivery charge (₹)</label>
          <input type="number" value={pricing.minDeliveryCharge} onChange={(e) => setPricing({ ...pricing, minDeliveryCharge: Number(e.target.value) })} />
        </div>
        <div className="formRow">
          <label>Maximum delivery distance (km)</label>
          <input type="number" value={pricing.maxDeliveryDistanceKm} onChange={(e) => setPricing({ ...pricing, maxDeliveryDistanceKm: Number(e.target.value) })} />
        </div>
        <button
          className="btn primary" disabled={saving}
          onClick={async () => {
            await save('base_delivery_charge', pricing.baseDeliveryCharge);
            await save('per_km_charge', pricing.perKmCharge);
            await save('min_delivery_charge', pricing.minDeliveryCharge);
            await save('max_delivery_distance_km', pricing.maxDeliveryDistanceKm);
          }}
        >
          Save delivery pricing
        </button>
      </div>

      {savedMsg && <p style={{ marginTop: 16, fontSize: 13, color: '#2E7D4F' }}>{savedMsg}</p>}
    </Layout>
  );
}
