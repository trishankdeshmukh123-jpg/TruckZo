import React from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';

export default function Page() {
  const { rows, error, loading } = useAdminList<any>('/admin/list/rfqs');
  return (
    <Layout>
      <h1 className="pageTitle">RFQs</h1>
      <p className="pageSubtitle">All customer requirements / bulk RFQs.</p>
      {error && <div className="noteBox">Could not load data: {error}. Start the backend and sign in as admin.</div>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Material</th><th>Qty</th><th>Unit</th><th>Location</th><th>Customer</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map((r: any) => (<tr key={r.id}><td>{String(r.material_name ?? "")}</td><td>{String(r.quantity ?? "")}</td><td>{String(r.unit ?? "")}</td><td>{String(r.delivery_location ?? "")}</td><td>{String(r.customer_name ?? "")}</td><td><Badge label={String(r.status)} /></td></tr>))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
