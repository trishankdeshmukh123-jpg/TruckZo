import React, { useState } from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { useAdminList } from '../lib/useAdminList';
import { fetchJson } from '../lib/api';

const STATUSES = ['UNDER_REVIEW', 'WAITING_FOR_INFORMATION', 'RESOLVED', 'REJECTED', 'CLOSED'];

export default function DisputesPage() {
  const { rows, error, loading, reload } = useAdminList<any>('/disputes');
  const [note, setNote] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState('');

  async function setStatus(id: string, status: string) {
    try {
      await fetchJson(`/disputes/${id}/status`, { method: 'POST', body: JSON.stringify({ status, note: note[id] || undefined, resolution: status === 'RESOLVED' ? note[id] : undefined }) });
      setMsg(`Dispute updated to ${status}`); reload();
    } catch (e) { setMsg((e as Error).message); }
  }

  return (
    <Layout>
      <h1 className="pageTitle">Disputes</h1>
      <p className="pageSubtitle">Review evidence, add notes, change status. Refunds are never automatic — record any approved refund/adjustment in the resolution note.</p>
      {error && <div className="noteBox">Could not load: {error}</div>}
      {msg && <p>{msg}</p>}
      {loading ? <p>Loading…</p> : (
        <table>
          <thead><tr><th>Issue</th><th>Description</th><th>Requested</th><th>Status</th><th>Note / resolution</th><th>Set status</th></tr></thead>
          <tbody>
            {rows.map((d: any) => (
              <tr key={d.id}>
                <td>{String(d.issue_type).replace(/_/g, ' ')}</td>
                <td>{d.description}</td>
                <td>{d.requested_resolution}</td>
                <td><Badge label={d.status} /></td>
                <td><input value={note[d.id] ?? ''} onChange={(e) => setNote({ ...note, [d.id]: e.target.value })} /></td>
                <td style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                  {STATUSES.map((s) => <button key={s} className="btn" onClick={() => setStatus(d.id, s)}>{s.replace(/_/g, ' ')}</button>)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Layout>
  );
}
