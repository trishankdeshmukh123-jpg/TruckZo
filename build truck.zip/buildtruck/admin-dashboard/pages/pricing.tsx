import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { fetchJson } from '../lib/api';

const KEYS: [string, string][] = [
  ['loading_charge', 'Loading charge (₹)'], ['unloading_charge', 'Unloading charge (₹)'],
  ['waiting_charge_per_hour', 'Waiting charge per hour (₹)'], ['default_toll_charge', 'Default toll (₹)'],
  ['remote_area_charge', 'Remote-area charge (₹)'], ['remote_area_distance_km', 'Remote-area distance threshold (km)'],
];
const FACTOR_FIELD: Record<string, string> = {
  loading_charge: 'loadingCharge', unloading_charge: 'unloadingCharge', waiting_charge_per_hour: 'waitingChargePerHour',
  default_toll_charge: 'defaultTollCharge', remote_area_charge: 'remoteAreaCharge', remote_area_distance_km: 'remoteAreaDistanceKm',
};

export default function PricingPage() {
  const [values, setValues] = useState<Record<string, number>>({});
  const [multipliers, setMultipliers] = useState<{ vehicle_category: string; multiplier: number }[]>([]);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    fetchJson<any>('/admin/settings/advanced-pricing').then((r) => {
      const v: Record<string, number> = {};
      Object.entries(FACTOR_FIELD).forEach(([k, f]) => { v[k] = r.factors[f]; });
      setValues(v); setMultipliers(r.multipliers.map((m: any) => ({ ...m, multiplier: Number(m.multiplier) })));
    }).catch((e) => setMsg(e.message));
  }, []);

  async function save(key: string) {
    try { await fetchJson('/admin/settings', { method: 'POST', body: JSON.stringify({ key, value: values[key] }) }); setMsg(`Saved ${key}`); }
    catch (e) { setMsg((e as Error).message); }
  }
  async function saveMult(cat: string, multiplier: number) {
    try { await fetchJson('/admin/settings/vehicle-multiplier', { method: 'POST', body: JSON.stringify({ vehicleCategory: cat, multiplier }) }); setMsg(`Saved ${cat}`); }
    catch (e) { setMsg((e as Error).message); }
  }

  return (
    <Layout>
      <h1 className="pageTitle">Advanced delivery pricing</h1>
      <p className="pageSubtitle">Base fare / per-km / minimum / max distance are on the Settings page. These factors extend the formula.</p>
      {msg && <p>{msg}</p>}
      <div className="card" style={{ maxWidth: 480, marginBottom: 20 }}>
        {KEYS.map(([k, label]) => (
          <div className="formRow" key={k}>
            <label>{label}</label>
            <input type="number" value={values[k] ?? ''} onChange={(e) => setValues({ ...values, [k]: Number(e.target.value) })} />
            <button className="btn" style={{ marginLeft: 8 }} onClick={() => save(k)}>Save</button>
          </div>
        ))}
      </div>
      <div className="card" style={{ maxWidth: 480 }}>
        <h3 style={{ marginTop: 0 }}>Vehicle category multipliers</h3>
        {multipliers.map((m, i) => (
          <div className="formRow" key={m.vehicle_category}>
            <label>{m.vehicle_category}</label>
            <input type="number" step="0.1" value={m.multiplier} onChange={(e) => { const c = [...multipliers]; c[i] = { ...m, multiplier: Number(e.target.value) }; setMultipliers(c); }} />
            <button className="btn" style={{ marginLeft: 8 }} onClick={() => saveMult(m.vehicle_category, m.multiplier)}>Save</button>
          </div>
        ))}
      </div>
    </Layout>
  );
}
