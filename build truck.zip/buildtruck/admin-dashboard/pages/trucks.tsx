import React from 'react';
import Layout from '../components/Layout';
import { trucks } from '../data/sampleAdminData';
import { formatINR } from '../lib/api';

export default function TrucksPage() {
  return (
    <Layout>
      <h1 className="pageTitle">Trucks</h1>
      <p className="pageSubtitle">All registered trucks across suppliers, with vehicle category, capacity and rates.</p>
      <table>
        <thead>
          <tr><th>Registration No.</th><th>Category</th><th>Capacity</th><th>Rate/trip</th><th>Rate/km</th><th>Driver</th><th>Supplier</th><th>Status</th></tr>
        </thead>
        <tbody>
          {trucks.map((t) => (
            <tr key={t.id}>
              <td>{t.registrationNumber}</td><td>{t.vehicleCategory}</td><td>{t.capacityBracket}</td>
              <td>{formatINR(t.ratePerTrip)}</td><td>{formatINR(t.ratePerKm)}</td>
              <td>{t.driver}</td><td>{t.supplier}</td>
              <td>{t.available ? <span className="badge success">Available</span> : <span className="badge default">On delivery</span>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Layout>
  );
}
