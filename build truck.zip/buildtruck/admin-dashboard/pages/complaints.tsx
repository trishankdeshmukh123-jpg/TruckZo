import React, { useState } from 'react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';
import { complaints as sampleComplaints } from '../data/sampleAdminData';

export default function ComplaintsPage() {
  const [complaints, setComplaints] = useState(sampleComplaints);
  function resolve(id: string) {
    setComplaints((prev) => prev.map((c) => (c.id === id ? { ...c, status: 'RESOLVED' } : c)));
  }
  return (
    <Layout>
      <h1 className="pageTitle">Complaints</h1>
      <p className="pageSubtitle">Support tickets raised by customers or suppliers.</p>
      <table>
        <thead><tr><th>From</th><th>Subject</th><th>Order #</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {complaints.map((c) => (
            <tr key={c.id}>
              <td>{c.from}</td><td>{c.subject}</td><td>{c.orderNumber}</td>
              <td><Badge label={c.status} /></td>
              <td>{c.status !== 'RESOLVED' && <button className="btn primary" onClick={() => resolve(c.id)}>Mark resolved</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Layout>
  );
}
