// Sample data for the admin dashboard demo. Real implementation reads from
// the backend's users/orders/commission_ledger/settlements tables via new
// admin list endpoints (GET /admin/customers, /admin/suppliers,
// /admin/orders, etc.) — not yet built; see backend README. The dashboard
// pages below call those endpoints first and fall back to this data.

export const kpis = {
  totalUsers: 4820,
  activeSuppliers: 186,
  totalOrders: 12904,
  completedOrders: 11720,
  cancelledOrders: 612,
  grossOrderValue: 48250000,
  platformCommission: 2318000,
  pendingSettlements: 184600,
};

export const ordersByDay = [
  { day: 'Mon', count: 210 }, { day: 'Tue', count: 245 }, { day: 'Wed', count: 198 },
  { day: 'Thu', count: 260 }, { day: 'Fri', count: 301 }, { day: 'Sat', count: 340 }, { day: 'Sun', count: 190 },
];

export const popularMaterials = [
  { name: 'River Sand', orders: 3210 }, { name: 'OPC Cement', orders: 2870 },
  { name: '20mm Aggregate', orders: 1980 }, { name: 'Red Clay Bricks', orders: 1540 },
  { name: 'M-Sand', orders: 1102 },
];

export const customers = [
  { id: 'u-1', name: 'Rahul Sharma', phone: '+919876543210', city: 'Mumbai', orders: 8, joined: '2026-02-11', suspended: false },
  { id: 'u-2', name: 'Priya Nair', phone: '+919876500001', city: 'Pune', orders: 3, joined: '2026-03-02', suspended: false },
  { id: 'u-3', name: 'Mohd. Imran', phone: '+919876500002', city: 'Nagpur', orders: 15, joined: '2025-12-19', suspended: false },
  { id: 'u-4', name: 'Anjali Deshmukh', phone: '+919876500003', city: 'Thane', orders: 1, joined: '2026-06-01', suspended: true },
];

export const suppliers = [
  { id: 's-1', name: 'Shree Balaji Sand & Aggregates', city: 'Mumbai', rating: 4.6, status: 'APPROVED', orders: 412, pendingCommission: 3170 },
  { id: 's-2', name: 'RK Construction Materials', city: 'Pune', rating: 4.3, status: 'APPROVED', orders: 210, pendingCommission: 1520 },
  { id: 's-3', name: 'Ganesh Brick & Cement Depot', city: 'Nagpur', rating: 4.8, status: 'PENDING', orders: 0, pendingCommission: 0 },
  { id: 's-4', name: 'New India Building Supplies', city: 'Thane', rating: 3.9, status: 'REJECTED', orders: 4, pendingCommission: 0 },
];

export const orders = [
  { id: 'o-1', orderNumber: 'BT-2026-005011', customer: 'Rahul Sharma', supplier: 'Shree Balaji Sand & Aggregates', total: 7570, status: 'PENDING', paymentMethod: 'UPI' },
  { id: 'o-2', orderNumber: 'BT-2026-005002', customer: 'Priya Nair', supplier: 'RK Construction Materials', total: 77400, status: 'ACCEPTED', paymentMethod: 'CASH' },
  { id: 'o-3', orderNumber: 'BT-2026-004981', customer: 'Mohd. Imran', supplier: 'Ganesh Brick & Cement Depot', total: 25850, status: 'OUT_FOR_DELIVERY', paymentMethod: 'CASH' },
  { id: 'o-4', orderNumber: 'BT-2026-004900', customer: 'Anjali Deshmukh', supplier: 'Shree Balaji Sand & Aggregates', total: 9800, status: 'COMPLETED', paymentMethod: 'UPI' },
  { id: 'o-5', orderNumber: 'BT-2026-004822', customer: 'Rahul Sharma', supplier: 'RK Construction Materials', total: 14200, status: 'CANCELLED', paymentMethod: 'CASH' },
];

export const payments = [
  { id: 'p-1', orderNumber: 'BT-2026-005011', method: 'UPI', status: 'SUCCESS', amount: 7570, provider: 'mock' },
  { id: 'p-2', orderNumber: 'BT-2026-004900', method: 'UPI', status: 'SUCCESS', amount: 9800, provider: 'mock' },
  { id: 'p-3', orderNumber: 'BT-2026-004822', method: 'CASH', status: 'REFUNDED', amount: 14200, provider: 'n/a' },
];

export const commissionLedger = [
  { id: 'c-1', orderNumber: 'BT-2026-004900', supplier: 'Shree Balaji Sand & Aggregates', commissionableAmount: 9800, rate: 5, amount: 490, status: 'PAYABLE' },
  { id: 'c-2', orderNumber: 'BT-2026-004777', supplier: 'RK Construction Materials', commissionableAmount: 77400, rate: 5, amount: 3870, status: 'SETTLED' },
];

export const settlements = [
  { id: 'st-1', supplier: 'RK Construction Materials', amount: 3870, method: 'UPI', settledAt: '2026-09-18' },
];

export const complaints = [
  { id: 'cp-1', from: 'Rahul Sharma', subject: 'Truck arrived 2 hours late', orderNumber: 'BT-2026-004822', status: 'OPEN' },
  { id: 'cp-2', from: 'Priya Nair', subject: 'Cement bags were damp', orderNumber: 'BT-2026-005002', status: 'IN_PROGRESS' },
];

export const materials = [
  { id: 'm-1', name: 'River Sand (Fine)', category: 'Sand', suppliers: 34, active: true },
  { id: 'm-2', name: 'OPC 53 Grade Cement', category: 'Cement', suppliers: 51, active: true },
  { id: 'm-3', name: '20mm Aggregate', category: 'Gitti / Aggregate', suppliers: 22, active: true },
];

export const trucks = [
  { id: 't-1', registrationNumber: 'MH12AB1234', vehicleCategory: '10 Wheeler', capacityBracket: '15 Ton', ratePerTrip: 4500, ratePerKm: 55, driver: 'Suresh Patil', supplier: 'Shree Balaji Sand & Aggregates', available: true },
  { id: 't-2', registrationNumber: 'MH04CD5678', vehicleCategory: '6 Wheeler', capacityBracket: '10 Ton', ratePerTrip: 3200, ratePerKm: 40, driver: 'Ramesh Yadav', supplier: 'Shree Balaji Sand & Aggregates', available: false },
  { id: 't-3', registrationNumber: 'MH14EF9012', vehicleCategory: 'Mini Truck', capacityBracket: '3 Ton', ratePerTrip: 1800, ratePerKm: 25, driver: 'Vikram Singh', supplier: 'RK Construction Materials', available: true },
];

export const tenderMaterials = [
  { id: 'tm-1', materialName: 'River Sand', supplier: 'Ganesh Brick & Cement Depot', quantity: 5000, unit: 'ton', rate: 1350, location: 'Nashik, Maharashtra', status: 'APPROVED' },
  { id: 'tm-2', materialName: '20mm Aggregate', supplier: 'RK Construction Materials', quantity: 3000, unit: 'ton', rate: 1150, location: 'Pune, Maharashtra', status: 'PENDING' },
];

export const tenderTrucks = [
  { id: 'tt-1', vehicleCategory: '12 Wheeler', capacityBracket: '20 Ton', registrationNumber: 'MH20GH3456', supplier: 'Ganesh Brick & Cement Depot', ratePerTrip: 6000, ratePerKm: 65, status: 'PENDING' },
];

export const categories = [
  { id: 'cat-sand', name: 'Sand', materials: 3, active: true },
  { id: 'cat-cement', name: 'Cement', materials: 2, active: true },
  { id: 'cat-bricks', name: 'Bricks', materials: 2, active: true },
];
