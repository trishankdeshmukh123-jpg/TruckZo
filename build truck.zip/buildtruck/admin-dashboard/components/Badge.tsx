import React from 'react';

const TONE_FOR: Record<string, string> = {
  COMPLETED: 'success', APPROVED: 'success', SUCCESS: 'success', SETTLED: 'success',
  CANCELLED: 'danger', REJECTED: 'danger', FAILED: 'danger', REFUNDED: 'danger',
  PENDING: 'warning', OPEN: 'warning', PAYABLE: 'warning', IN_PROGRESS: 'warning',
};

export default function Badge({ label }: { label: string }) {
  const tone = TONE_FOR[label] ?? 'default';
  return <span className={`badge ${tone}`}>{label}</span>;
}
