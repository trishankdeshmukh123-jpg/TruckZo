import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';

const NAV = [
  { href: '/', label: 'Overview' },
  { href: '/customers', label: 'Customers' },
  { href: '/suppliers', label: 'Suppliers' },
  { href: '/trucks', label: 'Trucks' },
  { href: '/tenders', label: 'Government Tenders' },
  { href: '/materials', label: 'Materials & Categories' },
  { href: '/orders', label: 'Orders' },
  { href: '/rfqs', label: 'RFQs' },
  { href: '/quotes', label: 'Quotations' },
  { href: '/businesses', label: 'Business accounts' },
  { href: '/projects', label: 'Projects' },
  { href: '/trips', label: 'Trips' },
  { href: '/pods', label: 'PODs' },
  { href: '/disputes', label: 'Disputes' },
  { href: '/verification', label: 'Verification' },
  { href: '/inventory', label: 'Inventory' },
  { href: '/pricing', label: 'Advanced pricing' },
  { href: '/invoices', label: 'Invoices' },
  { href: '/notifications', label: 'Notifications' },
  { href: '/payments', label: 'Payments' },
  { href: '/commission', label: 'Commission Ledger' },
  { href: '/settlements', label: 'Settlements' },
  { href: '/complaints', label: 'Complaints' },
  { href: '/coupons', label: 'Coupons & Offers' },
  { href: '/settings', label: 'Settings' },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  return (
    <div className="layout">
      <aside className="sidebar">
        <h1>🏗️ BuildTruck</h1>
        {NAV.map((item) => (
          <Link key={item.href} href={item.href} className={router.pathname === item.href ? 'active' : ''}>
            {item.label}
          </Link>
        ))}
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
