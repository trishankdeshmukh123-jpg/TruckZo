// Business/Contractor accounts: a business has members with roles, and can
// run multiple projects. Individual customer accounts are completely
// unaffected — a user only gets business features by creating or being
// added to a business.

import { db } from '../config/db';
import { BusinessRole } from '../types/enums';

export async function createBusiness(ownerUserId: string, name: string, gstin?: string, address?: string) {
  const result = await db.query(
    `INSERT INTO businesses (name, gstin, address, owner_user_id) VALUES ($1,$2,$3,$4) RETURNING id`,
    [name, gstin ?? null, address ?? null, ownerUserId]
  );
  await db.query(`INSERT INTO business_members (business_id, user_id, role) VALUES ($1,$2,'OWNER')`, [result.rows[0].id, ownerUserId]);
  return result.rows[0];
}

export async function listMyBusinesses(userId: string) {
  const result = await db.query(
    `SELECT b.*, bm.role FROM businesses b JOIN business_members bm ON bm.business_id = b.id WHERE bm.user_id = $1`,
    [userId]
  );
  return result.rows;
}

export class BusinessAccessDeniedError extends Error {
  constructor() { super('You are not a member of this business'); this.name = 'BusinessAccessDeniedError'; }
}

// Used by the route layer for EVERY business-scoped endpoint. `minRole`
// lets routes that mutate (add members, create projects) require
// OWNER/ADMIN/MANAGER while read-only routes accept any member including VIEWER.
const ROLE_RANK: Record<BusinessRole, number> = { VIEWER: 0, STAFF: 1, MANAGER: 2, ADMIN: 3, OWNER: 4 };

export async function assertBusinessAccess(businessId: string, userId: string, platformRole: string, minRole: BusinessRole = 'VIEWER'): Promise<void> {
  if (platformRole === 'admin') return;
  const result = await db.query(
    'SELECT role FROM business_members WHERE business_id = $1 AND user_id = $2',
    [businessId, userId]
  );
  if (!result.rows.length || ROLE_RANK[result.rows[0].role as BusinessRole] < ROLE_RANK[minRole]) {
    throw new BusinessAccessDeniedError();
  }
}

export async function addMember(businessId: string, userId: string, role: BusinessRole) {
  await db.query(
    `INSERT INTO business_members (business_id, user_id, role) VALUES ($1,$2,$3)
     ON CONFLICT (business_id, user_id) DO UPDATE SET role = $3`,
    [businessId, userId, role]
  );
}

export async function listMembers(businessId: string) {
  const result = await db.query(
    `SELECT bm.id, bm.role, u.id AS user_id, u.full_name, u.phone FROM business_members bm
     JOIN users u ON u.id = bm.user_id WHERE bm.business_id = $1`,
    [businessId]
  );
  return result.rows;
}

// ---- Projects ----
export interface CreateProjectInput {
  name: string; projectType?: string; siteAddress?: string; managerUserId?: string;
  startDate?: string; expectedCompletionDate?: string;
}

export async function createProject(businessId: string, input: CreateProjectInput) {
  const result = await db.query(
    `INSERT INTO projects (business_id, name, project_type, site_address, manager_user_id, start_date, expected_completion_date)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [businessId, input.name, input.projectType ?? null, input.siteAddress ?? null,
     input.managerUserId ?? null, input.startDate ?? null, input.expectedCompletionDate ?? null]
  );
  return result.rows[0];
}

export async function listProjects(businessId: string) {
  const result = await db.query('SELECT * FROM projects WHERE business_id = $1 ORDER BY created_at DESC', [businessId]);
  return result.rows;
}

// Resolves which business a project belongs to — needed by routes that
// only receive a projectId (e.g. the dashboard route) and must still check
// business membership before returning financial data.
export async function getProjectBusinessId(projectId: string): Promise<string | null> {
  const result = await db.query('SELECT business_id FROM projects WHERE id = $1', [projectId]);
  return result.rows[0]?.business_id ?? null;
}

// Project dashboard: orders, spend, delivered quantity, pending RFQs — all
// computed live from the real orders/rfqs tables, never a cached summary.
export async function getProjectDashboard(projectId: string) {
  const orders = await db.query(
    `SELECT status, total_amount, material_cost FROM orders WHERE project_id = $1`, [projectId]
  );
  const rfqs = await db.query(`SELECT status FROM rfqs WHERE project_id = $1`, [projectId]);
  const totalSpend = orders.rows.reduce((sum, o) => sum + Number(o.total_amount), 0);
  const activeOrders = orders.rows.filter((o) => !['COMPLETED', 'CANCELLED', 'REFUNDED'].includes(o.status)).length;
  return {
    totalOrders: orders.rows.length,
    activeOrders,
    completedOrders: orders.rows.filter((o) => o.status === 'COMPLETED').length,
    totalSpend,
    openRfqs: rfqs.rows.filter((r) => ['OPEN', 'QUOTED', 'SHORTLISTED'].includes(r.status)).length,
    totalRfqs: rfqs.rows.length,
  };
}
