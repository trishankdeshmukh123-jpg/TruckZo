// Multi-truck / multi-load orders. An order that needs more than one
// truckload gets rows in order_trips; a normal single-truck order has none
// (and every existing single-truck code path in orderService is untouched).
//
// TRANSACTIONS: creating a trip locks the parent order row (SELECT ... FOR
// UPDATE) and checks the running sum of trip quantities against the
// order's total_quantity inside one transaction — this is what actually
// prevents two concurrent "add a trip" calls from together loading more
// than the order's total quantity (a single-statement UPDATE can't express
// that cross-row sum check the way inventoryService's single-row
// reserve/release can).

import { db, withTransaction, TxHandle } from '../config/db';
import { TripStatus } from '../types/enums';
import { notify } from './notificationService';

export async function markOrderMultiTruck(orderId: string, totalQuantity: number) {
  if (!(totalQuantity > 0)) throw new Error('Total quantity must be greater than zero');
  await db.query(`UPDATE orders SET requires_multi_truck = true, total_quantity = $1 WHERE id = $2`, [totalQuantity, orderId]);
}

export async function createTrip(orderId: string, tripNumber: number, loadQuantity: number) {
  if (!(loadQuantity > 0)) throw new Error('Load quantity must be greater than zero');

  return withTransaction(async (tx) => {
    // Row lock on the order for the duration of this transaction — a
    // second concurrent createTrip() for the same order blocks here until
    // the first commits, so the sum check below can't race.
    const order = await tx.query('SELECT total_quantity FROM orders WHERE id = $1 FOR UPDATE', [orderId]);
    if (!order.rows.length) throw new Error('Order not found');
    const totalQuantity = order.rows[0].total_quantity != null ? Number(order.rows[0].total_quantity) : null;

    if (totalQuantity != null) {
      const existing = await tx.query(
        `SELECT COALESCE(SUM(load_quantity), 0) AS sum FROM order_trips WHERE order_id = $1 AND status != 'CANCELLED'`,
        [orderId]
      );
      const alreadyPlanned = Number(existing.rows[0].sum);
      if (alreadyPlanned + loadQuantity > totalQuantity) {
        throw new Error(
          `This trip's ${loadQuantity} would bring the planned total to ${alreadyPlanned + loadQuantity}, ` +
          `which exceeds the order's total quantity of ${totalQuantity}.`
        );
      }
    }

    const result = await tx.query(
      `INSERT INTO order_trips (order_id, trip_number, load_quantity, status) VALUES ($1,$2,$3,'PENDING') RETURNING id, status`,
      [orderId, tripNumber, loadQuantity]
    );
    return result.rows[0];
  });
}

export async function assignTruckToTrip(tripId: string, truckId: string, driverName?: string, driverPhone?: string) {
  await db.query(
    `UPDATE order_trips SET truck_id = $1, driver_name = $2, driver_phone = $3, status = 'ASSIGNED', updated_at = now() WHERE id = $4`,
    [truckId, driverName ?? null, driverPhone ?? null, tripId]
  );
}

const TRIP_TRANSITIONS: Record<TripStatus, TripStatus[]> = {
  PENDING: ['ASSIGNED', 'CANCELLED'],
  ASSIGNED: ['PICKED_UP', 'CANCELLED'],
  PICKED_UP: ['OUT_FOR_DELIVERY'],
  OUT_FOR_DELIVERY: ['DELIVERED'],
  DELIVERED: [],
  CANCELLED: [],
};

export async function updateTripStatus(tripId: string, toStatus: TripStatus) {
  const { orderId, tripNumber } = await withTransaction(async (tx) => {
    const current = await tx.query('SELECT status, order_id, trip_number FROM order_trips WHERE id = $1 FOR UPDATE', [tripId]);
    if (!current.rows.length) throw new Error('Trip not found');
    const fromStatus: TripStatus = current.rows[0].status;
    if (!TRIP_TRANSITIONS[fromStatus].includes(toStatus)) {
      throw new Error(`Cannot move trip from ${fromStatus} to ${toStatus}`);
    }
    const timeField = toStatus === 'PICKED_UP' ? 'pickup_time' : toStatus === 'DELIVERED' ? 'delivery_time' : null;
    await tx.query(
      `UPDATE order_trips SET status = $1, updated_at = now()${timeField ? `, ${timeField} = now()` : ''} WHERE id = $2`,
      [toStatus, tripId]
    );
    return { orderId: current.rows[0].order_id, tripNumber: current.rows[0].trip_number };
  });

  // Best-effort notification outside the transaction (same pattern as
  // orderService/inventoryService) — a notify() failure must not roll back
  // a trip status change that already committed.
  if (toStatus === 'DELIVERED') {
    const orderRow = await db.query('SELECT customer_id FROM orders WHERE id = $1', [orderId]);
    if (orderRow.rows.length) {
      await notify(orderRow.rows[0].customer_id, 'delivery_completed', `Trip #${tripNumber} delivered`, "One of your order's trips has been delivered.", { orderId, tripId });
    }
  }
}

export interface OrderProgress {
  totalQuantity: number | null;
  deliveredQuantity: number;
  remainingQuantity: number | null;
  tripsTotal: number;
  tripsCompleted: number;
  trips: any[];
}

export async function getOrderProgress(orderId: string): Promise<OrderProgress> {
  const order = await db.query('SELECT total_quantity FROM orders WHERE id = $1', [orderId]);
  const trips = await db.query('SELECT * FROM order_trips WHERE order_id = $1 ORDER BY trip_number ASC', [orderId]);
  const totalQuantity = order.rows[0]?.total_quantity != null ? Number(order.rows[0].total_quantity) : null;
  const deliveredQuantity = trips.rows
    .filter((t) => t.status === 'DELIVERED')
    .reduce((sum, t) => sum + Number(t.load_quantity), 0);
  return {
    totalQuantity,
    deliveredQuantity,
    remainingQuantity: totalQuantity != null ? Math.max(0, totalQuantity - deliveredQuantity) : null,
    tripsTotal: trips.rows.length,
    tripsCompleted: trips.rows.filter((t) => t.status === 'DELIVERED').length,
    trips: trips.rows,
  };
}
