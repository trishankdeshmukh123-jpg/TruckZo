// Generic "send requirement/request" used by standalone truck hire and
// both Government Tender search flows (see db/schema.sql's service_requests
// table for why this is one table, not three).

import { db } from '../config/db';
import { ServiceRequestType } from '../types/enums';

export async function createServiceRequest(params: {
  requestType: ServiceRequestType;
  requesterId: string;
  targetId: string;
  quantity?: number;
  message?: string;
  contactPhone?: string;
}) {
  const result = await db.query(
    `INSERT INTO service_requests (request_type, requester_id, target_id, quantity, message, contact_phone)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, status, created_at`,
    [params.requestType, params.requesterId, params.targetId, params.quantity ?? null, params.message ?? null, params.contactPhone ?? null]
  );
  return result.rows[0];
}

export async function listRequestsForTarget(requestType: ServiceRequestType, targetId: string) {
  const result = await db.query(
    `SELECT sr.id, sr.quantity, sr.message, sr.contact_phone, sr.status, sr.created_at,
            u.full_name AS requester_name, u.phone AS requester_phone
     FROM service_requests sr JOIN users u ON u.id = sr.requester_id
     WHERE sr.request_type = $1 AND sr.target_id = $2 ORDER BY sr.created_at DESC`,
    [requestType, targetId]
  );
  return result.rows;
}
