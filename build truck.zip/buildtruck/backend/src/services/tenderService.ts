// Government Tender module. Suppliers list materials/trucks specifically
// earmarked for government-project requirements; tender users search and
// send requirements. IMPORTANT: this is a coordination/listing layer only
// — BuildTruck does not award tenders, is not a government portal, and
// makes no claims about contract eligibility. See docs/ARCHITECTURE.md §13.

import { db } from '../config/db';
import { VehicleCategory, CapacityBracket } from '../types/enums';

// ---- Tender materials ----
export interface CreateTenderMaterialInput {
  categoryId?: string;
  materialName: string;
  quantity: number;
  unit: string;
  rate: number;
  supplyLocation: string;
  serviceArea?: string;
}

export async function createTenderMaterial(supplierId: string, input: CreateTenderMaterialInput) {
  const result = await db.query(
    `INSERT INTO tender_materials
      (supplier_id, category_id, material_name, quantity, unit, rate, supply_location, service_area, verification_status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'PENDING') RETURNING id, verification_status`,
    [supplierId, input.categoryId ?? null, input.materialName, input.quantity, input.unit,
     input.rate, input.supplyLocation, input.serviceArea ?? null]
  );
  return result.rows[0];
}

export async function searchTenderMaterials(filters: { categoryId?: string; location?: string; onlyAvailable?: boolean }) {
  const conditions: string[] = [`tm.verification_status = 'APPROVED'`];
  const params: unknown[] = [];
  if (filters.categoryId) { params.push(filters.categoryId); conditions.push(`tm.category_id = $${params.length}`); }
  if (filters.location) { params.push(`%${filters.location}%`); conditions.push(`tm.supply_location ILIKE $${params.length}`); }
  if (filters.onlyAvailable) conditions.push('tm.is_available = true');

  const result = await db.query(
    `SELECT tm.id, tm.material_name, tm.quantity, tm.unit, tm.rate, tm.supply_location, tm.service_area,
            tm.is_available, sp.business_name AS supplier_name, sp.business_phone AS supplier_phone
     FROM tender_materials tm JOIN supplier_profiles sp ON sp.id = tm.supplier_id
     WHERE ${conditions.join(' AND ')} ORDER BY tm.created_at DESC`,
    params
  );
  return result.rows;
}

// ---- Tender trucks ----
export interface CreateTenderTruckInput {
  vehicleCategory: VehicleCategory;
  capacityBracket?: CapacityBracket;
  capacityTons?: number;
  registrationNumber: string;
  currentLat?: number;
  currentLng?: number;
  ratePerTrip?: number;
  ratePerKm?: number;
  driverName?: string;
  driverPhone?: string;
  vehicleDetails?: string;
}

export async function createTenderTruck(supplierId: string, input: CreateTenderTruckInput) {
  const result = await db.query(
    `INSERT INTO tender_trucks
      (supplier_id, vehicle_category, capacity_bracket, capacity_tons, registration_number,
       current_lat, current_lng, rate_per_trip, rate_per_km, driver_name, driver_phone, vehicle_details, verification_status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'PENDING') RETURNING id, verification_status`,
    [supplierId, input.vehicleCategory, input.capacityBracket ?? null, input.capacityTons ?? null,
     input.registrationNumber, input.currentLat ?? null, input.currentLng ?? null,
     input.ratePerTrip ?? null, input.ratePerKm ?? null, input.driverName ?? null,
     input.driverPhone ?? null, input.vehicleDetails ?? null]
  );
  return result.rows[0];
}

export async function searchTenderTrucks(filters: { vehicleCategory?: VehicleCategory; capacityBracket?: CapacityBracket; onlyAvailable?: boolean }) {
  const conditions: string[] = [`tt.verification_status = 'APPROVED'`];
  const params: unknown[] = [];
  if (filters.vehicleCategory) { params.push(filters.vehicleCategory); conditions.push(`tt.vehicle_category = $${params.length}`); }
  if (filters.capacityBracket) { params.push(filters.capacityBracket); conditions.push(`tt.capacity_bracket = $${params.length}`); }
  if (filters.onlyAvailable) conditions.push('tt.is_available = true');

  const result = await db.query(
    `SELECT tt.id, tt.vehicle_category, tt.capacity_bracket, tt.capacity_tons, tt.registration_number,
            tt.current_lat, tt.current_lng, tt.rate_per_trip, tt.rate_per_km, tt.driver_name, tt.driver_phone,
            tt.vehicle_details, tt.is_available, sp.business_name AS supplier_name
     FROM tender_trucks tt JOIN supplier_profiles sp ON sp.id = tt.supplier_id
     WHERE ${conditions.join(' AND ')} ORDER BY tt.created_at DESC`,
    params
  );
  return result.rows;
}

// ---- Admin verification (shared shape for both) ----
export async function verifyTenderMaterial(id: string, status: 'APPROVED' | 'REJECTED') {
  await db.query('UPDATE tender_materials SET verification_status = $1, updated_at = now() WHERE id = $2', [status, id]);
}
export async function verifyTenderTruck(id: string, status: 'APPROVED' | 'REJECTED') {
  await db.query('UPDATE tender_trucks SET verification_status = $1, updated_at = now() WHERE id = $2', [status, id]);
}

export async function listAllTenderMaterials() {
  const result = await db.query(
    `SELECT tm.*, sp.business_name AS supplier_name FROM tender_materials tm
     JOIN supplier_profiles sp ON sp.id = tm.supplier_id ORDER BY tm.created_at DESC`
  );
  return result.rows;
}
export async function listAllTenderTrucks() {
  const result = await db.query(
    `SELECT tt.*, sp.business_name AS supplier_name FROM tender_trucks tt
     JOIN supplier_profiles sp ON sp.id = tt.supplier_id ORDER BY tt.created_at DESC`
  );
  return result.rows;
}
