// Dispute / complaint / resolution system. Refunds are never automatic —
// an admin must explicitly decide, per the task's explicit requirement.

import { db } from '../config/db';
import { notify } from './notificationService';
import { assertOrderAccess, OrderAccessDeniedError } from './orderService';
import { DisputeIssueType, DisputeStatus } from '../types/enums';

export { OrderAccessDeniedError };

export interface CreateDisputeInput {
  orderId: string; issueType: DisputeIssueType; description: string;
  evidenceUrls?: string[]; requestedResolution?: string;
}

export async function createDispute(raisedBy: string, raisedByRole: string, input: CreateDisputeInput) {
  // Only a party to the order (its customer, its supplier, or admin) can
  // raise a dispute about it — prevents an unrelated user from opening
  // disputes against orders they have no connection to.
  await assertOrderAccess(input.orderId, raisedBy, raisedByRole);

  const result = await db.query(
    `INSERT INTO disputes (order_id, raised_by, issue_type, description, evidence_urls, requested_resolution, status)
     VALUES ($1,$2,$3,$4,$5,$6,'OPEN') RETURNING id, status, created_at`,
    [input.orderId, raisedBy, input.issueType, input.description, JSON.stringify(input.evidenceUrls ?? []), input.requestedResolution ?? null]
  );
  await logDisputeStatus(result.rows[0].id, null, 'OPEN', raisedBy);
  return result.rows[0];
}

export async function listDisputesForUser(userId: string) {
  const result = await db.query('SELECT * FROM disputes WHERE raised_by = $1 ORDER BY created_at DESC', [userId]);
  return result.rows;
}

export async function listAllDisputes(status?: DisputeStatus) {
  const result = status
    ? await db.query('SELECT * FROM disputes WHERE status = $1 ORDER BY created_at DESC', [status])
    : await db.query('SELECT * FROM disputes ORDER BY created_at DESC');
  return result.rows;
}

export async function getDispute(id: string) {
  const result = await db.query('SELECT * FROM disputes WHERE id = $1', [id]);
  return result.rows[0] ?? null;
}

export class DisputeAccessDeniedError extends Error {
  constructor() { super('You do not have access to this dispute'); this.name = 'DisputeAccessDeniedError'; }
}

// A dispute is visible to whoever raised it, admin, or the OTHER party to
// the underlying order (so a supplier can see a dispute a customer raised
// about their order, and vice versa) — not to any other logged-in user.
export async function assertDisputeAccess(disputeId: string, userId: string, role: string): Promise<void> {
  if (role === 'admin') return;
  const dispute = await getDispute(disputeId);
  if (!dispute) throw new Error('Dispute not found');
  if (dispute.raised_by === userId) return;
  try {
    await assertOrderAccess(dispute.order_id, userId, role);
  } catch {
    throw new DisputeAccessDeniedError();
  }
}

// Admin-only: change status, optionally attach notes/resolution. Refund
// approval, if any, is a separate explicit admin action recorded in
// `resolution` — this function never triggers a refund itself.
export async function updateDisputeStatus(disputeId: string, toStatus: DisputeStatus, changedBy: string, note?: string, resolution?: string) {
  const current = await getDispute(disputeId);
  if (!current) throw new Error('Dispute not found');

  await db.query(
    `UPDATE disputes SET status = $1, admin_notes = COALESCE($2, admin_notes), resolution = COALESCE($3, resolution), updated_at = now() WHERE id = $4`,
    [toStatus, note ?? null, resolution ?? null, disputeId]
  );
  await logDisputeStatus(disputeId, current.status, toStatus, changedBy, note);
  await notify(current.raised_by, 'dispute_update', 'Dispute update', `Your dispute status changed to ${toStatus}.`, { disputeId, toStatus });
}

async function logDisputeStatus(disputeId: string, from: DisputeStatus | null, to: DisputeStatus, changedBy: string, note?: string) {
  await db.query(
    `INSERT INTO dispute_status_history (dispute_id, from_status, to_status, changed_by, note) VALUES ($1,$2,$3,$4,$5)`,
    [disputeId, from, to, changedBy, note ?? null]
  );
}

export async function getDisputeHistory(disputeId: string) {
  const result = await db.query('SELECT * FROM dispute_status_history WHERE dispute_id = $1 ORDER BY created_at ASC', [disputeId]);
  return result.rows;
}
