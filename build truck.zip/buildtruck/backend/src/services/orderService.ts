// Order lifecycle: creation (with server-side price/commission calc, inside
// a single DB transaction), status transitions (validated against
// ORDER_STATUS_TRANSITIONS), and delivery OTP issue/verify. This is the
// module that turns a cart into a COMPLETED order with a correct, auditable
// money trail.
//
// TRANSACTIONS: order creation (order row + order_items + stock reservation)
// and order completion (status + commission + inventory fulfillment +
// invoice generation) each run inside ONE withTransaction() block. If any
// step fails, the whole thing rolls back — no orphaned order_items, no
// double-reserved stock, no order marked COMPLETED without its invoice.
// Cancellation (status + stock release) is transactional the same way.

import crypto from 'crypto';
import { db, withTransaction, TxHandle } from '../config/db';
import { calculatePriceQuote, PriceQuoteInput } from './pricingService';
import { calculateCommission, recordCommissionOnCompletion } from './commissionService';
import { paymentProvider } from './paymentService';
import { reserveStock, releaseReservation, fulfillStock } from './inventoryService';
import { generateInvoiceForOrder } from './invoiceService';
import { notify, NotificationType } from './notificationService';
import { sendOtpSms } from './smsAdapter';
import {
  OrderStatus, PaymentMethod, ORDER_STATUS_TRANSITIONS, CANCELLABLE_STATUSES,
} from '../types/enums';

export class InvalidTransitionError extends Error {
  constructor(from: OrderStatus, to: OrderStatus) {
    super(`Cannot transition order from ${from} to ${to}`);
    this.name = 'InvalidTransitionError';
  }
}

interface CreateOrderInput {
  customerId: string;
  supplierId: string;
  supplierMaterialItems: { supplierMaterialId: string; unitPrice: number; quantity: number }[];
  deliveryAddressId: string;
  originLat: number; originLng: number;
  destLat: number; destLng: number;
  paymentMethod: PaymentMethod;
  discountAmount?: number;
  vehicleCategory?: string;    // real pricing factor — see pricingService
  numberOfTrips?: number;
  waitingHours?: number;
  tollCharge?: number;
}

export async function createOrder(input: CreateOrderInput) {
  // Price is calculated BEFORE the transaction opens — it only reads admin
  // settings and calls the map provider, no writes, so there's nothing to
  // roll back here and no reason to hold a DB connection during it.
  const priceInput: PriceQuoteInput = {
    items: input.supplierMaterialItems.map((i) => ({ unitPrice: i.unitPrice, quantity: i.quantity })),
    originLat: input.originLat, originLng: input.originLng,
    destLat: input.destLat, destLng: input.destLng,
    discountAmount: input.discountAmount,
    vehicleCategory: input.vehicleCategory, numberOfTrips: input.numberOfTrips,
    waitingHours: input.waitingHours, tollCharge: input.tollCharge,
  };
  const price = await calculatePriceQuote(priceInput);
  const commission = await calculateCommission(price);
  const orderNumber = generateOrderNumber();

  const { orderId } = await withTransaction(async (tx) => {
    const result = await tx.query(
      `INSERT INTO orders
        (order_number, customer_id, supplier_id, delivery_address_id, status,
         material_cost, delivery_distance_km, delivery_charge, platform_charges,
         discount_amount, total_amount, commission_rate_snapshot, commission_amount,
         payment_method, total_quantity, requires_multi_truck)
       VALUES ($1,$2,$3,$4,'PENDING',$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
       RETURNING id`,
      [
        orderNumber, input.customerId, input.supplierId, input.deliveryAddressId,
        price.materialCost, price.deliveryDistanceKm, price.deliveryCharge,
        price.platformCharges, price.discountAmount, price.totalAmount,
        commission.commissionRate, commission.commissionAmount, input.paymentMethod,
        input.supplierMaterialItems.reduce((sum, i) => sum + i.quantity, 0),
        (input.numberOfTrips ?? 1) > 1,
      ]
    );
    const orderId = result.rows[0].id;

    for (const item of input.supplierMaterialItems) {
      await tx.query(
        `INSERT INTO order_items (order_id, supplier_material_id, quantity, unit_price_snapshot, line_total)
         VALUES ($1,$2,$3,$4,$5)`,
        [orderId, item.supplierMaterialId, item.quantity, item.unitPrice, item.unitPrice * item.quantity]
      );
      // Reserve stock in the SAME transaction as the order/order_items rows.
      // If any item is out of stock, the whole order creation (including
      // items already inserted above) rolls back — no orphaned order.
      await reserveStock(item.supplierMaterialId, item.quantity, tx);
    }

    await logStatusChange(orderId, null, 'PENDING', input.customerId, undefined, tx);
    return { orderId };
  });

  // Payment-intent creation calls an external provider (or the mock) — kept
  // OUTSIDE the DB transaction on purpose: a slow/failed external HTTP call
  // must never hold a Postgres transaction open, and the order itself is
  // already durably committed by this point. If this insert fails, the
  // order still exists as PENDING with no payment row yet; a retry path for
  // that edge case is a follow-up (see README known limitations).
  if (input.paymentMethod === 'UPI') {
    const intent = await paymentProvider.createIntent(orderId, price.totalAmount);
    await db.query(
      `INSERT INTO payments (order_id, method, status, amount, provider, provider_payment_id)
       VALUES ($1,'UPI',$2,$3,$4,$5)`,
      [orderId, intent.status, price.totalAmount, process.env.PAYMENT_PROVIDER ?? 'mock', intent.providerPaymentId]
    );
  }

  return { orderId, orderNumber, price, commission };
}

export async function transitionOrderStatus(
  orderId: string, toStatus: OrderStatus, changedBy: string, note?: string
): Promise<void> {
  const current = await db.query('SELECT status FROM orders WHERE id = $1', [orderId]);
  if (!current.rows.length) throw new Error('Order not found');
  const fromStatus: OrderStatus = current.rows[0].status;

  const allowed = ORDER_STATUS_TRANSITIONS[fromStatus];
  if (!allowed.includes(toStatus)) {
    throw new InvalidTransitionError(fromStatus, toStatus);
  }

  if (toStatus === 'COMPLETED') {
    // Status + commission + inventory fulfillment + invoice generation all
    // happen together: an order should never end up COMPLETED with some of
    // these steps missing because a later one failed.
    await withTransaction(async (tx) => {
      await tx.query('UPDATE orders SET status = $1, completed_at = now(), updated_at = now() WHERE id = $2', [toStatus, orderId]);
      await logStatusChange(orderId, fromStatus, toStatus, changedBy, note, tx);

      const orderRow = await tx.query(
        `SELECT material_cost, delivery_charge, platform_charges, payment_method, supplier_id
         FROM orders WHERE id = $1`, [orderId]
      );
      const o = orderRow.rows[0];
      const commission = await calculateCommission({
        materialCost: Number(o.material_cost),
        deliveryCharge: Number(o.delivery_charge),
        platformCharges: Number(o.platform_charges),
      });
      await recordCommissionOnCompletion({
        orderId, supplierId: o.supplier_id, paymentMethod: o.payment_method, commission, tx,
      });

      const items = await tx.query('SELECT supplier_material_id, quantity FROM order_items WHERE order_id = $1', [orderId]);
      for (const item of items.rows) {
        await fulfillStock(item.supplier_material_id, Number(item.quantity), tx);
      }

      await generateInvoiceForOrder(orderId, tx);
    });
  } else {
    await db.query('UPDATE orders SET status = $1, updated_at = now() WHERE id = $2', [toStatus, orderId]);
    await logStatusChange(orderId, fromStatus, toStatus, changedBy, note);
    if (toStatus === 'ARRIVING') {
      await issueDeliveryOtp(orderId);
    }
  }

  // Notification is a best-effort side effect outside the transaction —
  // a failure to notify must never undo an otherwise-successful status change.
  await notifyOrderStatusChange(orderId, toStatus);
}

export async function cancelOrder(orderId: string, cancelledBy: string, reason: string): Promise<void> {
  await withTransaction(async (tx) => {
    const current = await tx.query('SELECT status FROM orders WHERE id = $1', [orderId]);
    if (!current.rows.length) throw new Error('Order not found');
    const fromStatus: OrderStatus = current.rows[0].status;
    if (!CANCELLABLE_STATUSES.includes(fromStatus)) {
      throw new Error(`Order in status ${fromStatus} can no longer be cancelled by the app — contact support.`);
    }
    await tx.query(
      'UPDATE orders SET status = $1, cancelled_reason = $2, updated_at = now() WHERE id = $3',
      ['CANCELLED', reason, orderId]
    );
    await logStatusChange(orderId, fromStatus, 'CANCELLED', cancelledBy, reason, tx);

    // Release reserved stock in the SAME transaction as the cancellation —
    // a cancelled order must never leave stock permanently locked, and a
    // failed release must roll back the cancellation too (rather than
    // cancelling the order but silently leaving stock reserved forever).
    const items = await tx.query('SELECT supplier_material_id, quantity FROM order_items WHERE order_id = $1', [orderId]);
    for (const item of items.rows) {
      await releaseReservation(item.supplier_material_id, Number(item.quantity), tx);
    }
  });
}

// ---- Delivery OTP ----
async function issueDeliveryOtp(orderId: string): Promise<void> {
  const otp = String(crypto.randomInt(100000, 999999));
  const otpHash = crypto.createHash('sha256').update(otp).digest('hex');
  await db.query(
    `UPDATE orders SET delivery_otp_hash = $1, delivery_otp_expires_at = now() + interval '2 hours' WHERE id = $2`,
    [otpHash, orderId]
  );
  const order = await db.query(
    `SELECT u.phone FROM orders o JOIN users u ON u.id = o.customer_id WHERE o.id = $1`,
    [orderId]
  );
  if (order.rows.length && order.rows[0].phone) {
    // Delivery OTP is also shown in the app UI (GET /orders/:id does not
    // expose the OTP itself, only order status — the customer sees the OTP
    // via a driver-facing display in person, SMS is a convenience channel).
    // SMS dispatch failure is deliberately swallowed here: the delivery
    // itself must not be blocked by an SMS provider outage, and
    // SmsNotConfiguredError in production is an expected, non-fatal case
    // for this particular call (unlike requestOtp, where SMS IS the only
    // channel and a failure must be surfaced).
    await sendOtpSms(order.rows[0].phone, otp).catch(() => {
      // Best-effort — see comment above.
    });
  }
}

export async function verifyDeliveryOtp(orderId: string, submittedOtp: string): Promise<boolean> {
  const row = await db.query(
    'SELECT delivery_otp_hash, delivery_otp_expires_at, status FROM orders WHERE id = $1',
    [orderId]
  );
  if (!row.rows.length) throw new Error('Order not found');
  const { delivery_otp_hash, delivery_otp_expires_at, status } = row.rows[0];
  if (status !== 'ARRIVING') throw new Error('Order is not awaiting OTP confirmation');
  if (!delivery_otp_hash || new Date(delivery_otp_expires_at) < new Date()) {
    throw new Error('OTP expired — ask the driver to regenerate it');
  }
  const submittedHash = crypto.createHash('sha256').update(submittedOtp).digest('hex');
  if (submittedHash !== delivery_otp_hash) return false;

  await db.query(
    `UPDATE orders SET status = 'DELIVERED', delivery_otp_hash = NULL, updated_at = now() WHERE id = $1`,
    [orderId]
  );
  await logStatusChange(orderId, 'ARRIVING', 'DELIVERED', null, 'OTP verified by customer');
  return true;
}

async function logStatusChange(
  orderId: string, from: OrderStatus | null, to: OrderStatus, changedBy: string | null, note?: string, tx: TxHandle = db
): Promise<void> {
  await tx.query(
    `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, note)
     VALUES ($1,$2,$3,$4,$5)`,
    [orderId, from, to, changedBy, note ?? null]
  );
}

function generateOrderNumber(): string {
  const year = new Date().getFullYear();
  const rand = Math.floor(100000 + Math.random() * 900000);
  return `BT-${year}-${rand}`;
}

// ---- Read paths ----
export async function listOrdersForCustomer(customerId: string) {
  const result = await db.query(
    `SELECT o.*, sp.business_name AS supplier_name
     FROM orders o JOIN supplier_profiles sp ON sp.id = o.supplier_id
     WHERE o.customer_id = $1 ORDER BY o.created_at DESC`,
    [customerId]
  );
  return result.rows;
}

export async function listOrdersForSupplier(supplierId: string) {
  const result = await db.query(
    `SELECT o.*, u.full_name AS customer_name
     FROM orders o JOIN users u ON u.id = o.customer_id
     WHERE o.supplier_id = $1 ORDER BY o.created_at DESC`,
    [supplierId]
  );
  return result.rows;
}

export async function getOrderById(orderId: string) {
  const order = await db.query('SELECT * FROM orders WHERE id = $1', [orderId]);
  if (!order.rows.length) return null;
  const items = await db.query(
    `SELECT oi.*, m.name AS material_name FROM order_items oi
     JOIN supplier_materials sm ON sm.id = oi.supplier_material_id
     JOIN materials m ON m.id = sm.material_id
     WHERE oi.order_id = $1`,
    [orderId]
  );
  return { ...order.rows[0], items: items.rows };
}

export class OrderAccessDeniedError extends Error {
  constructor() { super('You do not have access to this order'); this.name = 'OrderAccessDeniedError'; }
}

// Ownership check used by the route layer (routes/orders.ts, and anything
// else that reads/acts on a specific order — disputes, invoices, trips,
// POD). A requester may act on an order only if they ARE its customer, OR
// they own the supplier_profiles row the order was placed with, OR they
// are an admin. This is the one place that rule is defined, so every route
// enforces it the same way rather than each re-deriving it.
export async function assertOrderAccess(orderId: string, userId: string, role: string): Promise<void> {
  if (role === 'admin') return;
  const result = await db.query(
    `SELECT 1 FROM orders o
     LEFT JOIN supplier_profiles sp ON sp.id = o.supplier_id
     WHERE o.id = $1 AND (o.customer_id = $2 OR sp.user_id = $2)`,
    [orderId, userId]
  );
  if (!result.rows.length) throw new OrderAccessDeniedError();
}

async function notifyOrderStatusChange(orderId: string, status: OrderStatus): Promise<void> {
  const messages: Partial<Record<OrderStatus, { type: NotificationType; title: string; body: string }>> = {
    ACCEPTED: { type: 'order_accepted', title: 'Order accepted', body: 'The supplier has accepted your order.' },
    TRUCK_ASSIGNED: { type: 'truck_assigned', title: 'Truck assigned', body: 'A truck has been assigned to your order.' },
    PICKUP_STARTED: { type: 'trip_started', title: 'Pickup started', body: 'Your material has been picked up.' },
    OUT_FOR_DELIVERY: { type: 'out_for_delivery', title: 'Out for delivery', body: 'Your order is on the way.' },
    ARRIVING: { type: 'arriving', title: 'Truck arriving', body: 'Your truck is arriving — have the delivery OTP ready.' },
    COMPLETED: { type: 'delivery_completed', title: 'Order completed', body: 'Your order has been delivered and completed.' },
  };
  const entry = messages[status];
  if (!entry) return;
  const order = await db.query('SELECT customer_id FROM orders WHERE id = $1', [orderId]);
  if (order.rows.length) {
    await notify(order.rows[0].customer_id, entry.type, entry.title, entry.body, { orderId, status });
  }
}
