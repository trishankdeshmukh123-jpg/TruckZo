// Inventory management, layered onto supplier_materials' existing
// available_quantity plus the reserved_quantity/sold_quantity columns
// (migration 002). Hooked into orderService's real lifecycle inside a
// single DB transaction (see db.ts's withTransaction and orderService.ts) —
// reserve on order creation, fulfill on completion, release on
// cancellation all happen atomically with the order row itself.
//
// Every mutating function takes an optional `tx` (a TxHandle from
// withTransaction, or the plain pool `db` by default) so callers can either
// run one in isolation (as before) or compose several inside one
// transaction without any other code change.

import { db, TxHandle } from '../config/db';
import { notify } from './notificationService';

export async function reserveStock(supplierMaterialId: string, quantity: number, tx: TxHandle = db) {
  // The UPDATE's WHERE clause is re-checked under the row lock Postgres
  // takes for the duration of the statement, so two concurrent reservations
  // against the same row can never both succeed past the available stock —
  // this is safe against overselling even without an explicit SELECT ... FOR UPDATE.
  const result = await tx.query(
    `UPDATE supplier_materials
     SET reserved_quantity = reserved_quantity + $1
     WHERE id = $2 AND (available_quantity - reserved_quantity) >= $1
     RETURNING id`,
    [quantity, supplierMaterialId]
  );
  if (!result.rows.length) {
    throw new Error('Not enough available stock for this quantity');
  }
}

export async function releaseReservation(supplierMaterialId: string, quantity: number, tx: TxHandle = db) {
  await tx.query(
    `UPDATE supplier_materials SET reserved_quantity = GREATEST(0, reserved_quantity - $1) WHERE id = $2`,
    [quantity, supplierMaterialId]
  );
}

// On delivery completion: move quantity from reserved -> sold, and reduce
// available_quantity for real (the stock has physically left).
export async function fulfillStock(supplierMaterialId: string, quantity: number, tx: TxHandle = db) {
  const result = await tx.query(
    `UPDATE supplier_materials
     SET reserved_quantity = GREATEST(0, reserved_quantity - $1),
         sold_quantity = sold_quantity + $1,
         available_quantity = GREATEST(0, available_quantity - $1)
     WHERE id = $2
     RETURNING available_quantity, low_stock_threshold, supplier_id, material_id`,
    [quantity, supplierMaterialId]
  );
  const row = result.rows[0];
  if (row && row.low_stock_threshold != null && Number(row.available_quantity) <= Number(row.low_stock_threshold)) {
    // Notification is deliberately NOT part of the transaction's rollback
    // surface — it fires after the caller commits (see orderService), so a
    // notify() failure never blocks or rolls back the actual stock update.
    const supplierUser = await db.query(
      `SELECT u.id FROM users u JOIN supplier_profiles sp ON sp.user_id = u.id WHERE sp.id = $1`, [row.supplier_id]
    );
    if (supplierUser.rows.length) {
      await notify(supplierUser.rows[0].id, 'inventory_low', 'Low stock alert', 'One of your materials has dropped below its low-stock threshold.', { supplierMaterialId });
    }
  }
}

export async function listInventoryForSupplier(supplierId: string) {
  const result = await db.query(
    `SELECT sm.*, m.name AS material_name, m.default_unit
     FROM supplier_materials sm JOIN materials m ON m.id = sm.material_id
     WHERE sm.supplier_id = $1 ORDER BY m.name ASC`,
    [supplierId]
  );
  return result.rows.map((r) => ({
    ...r,
    is_low_stock: r.low_stock_threshold != null && Number(r.available_quantity) <= Number(r.low_stock_threshold),
  }));
}

export async function updateInventorySettings(supplierMaterialId: string, lowStockThreshold?: number, expectedRestockDate?: string) {
  await db.query(
    `UPDATE supplier_materials SET low_stock_threshold = $1, expected_restock_date = $2, updated_at = now() WHERE id = $3`,
    [lowStockThreshold ?? null, expectedRestockDate ?? null, supplierMaterialId]
  );
}
