// RFQ / bulk requirement / quotation system. A customer (or business user,
// via project_id) posts a requirement; suppliers discover it and submit
// quotes; the customer compares and awards one.

import { db } from '../config/db';
import { notify } from './notificationService';
import { RfqStatus, QuoteStatus } from '../types/enums';

export interface CreateRfqInput {
  materialName: string; specification?: string; quantity: number; unit: string;
  requiredDeliveryDate?: string; deliveryLocation: string; deliveryLat?: number; deliveryLng?: number;
  additionalRequirements?: string; targetPrice?: number; attachments?: string[];
  expiryAt?: string; projectId?: string; projectName?: string;
}

export async function createRfq(customerId: string, input: CreateRfqInput) {
  const result = await db.query(
    `INSERT INTO rfqs (customer_id, project_id, project_name, material_name, specification, quantity, unit,
       required_delivery_date, delivery_location, delivery_lat, delivery_lng, additional_requirements,
       target_price, attachments, expiry_at, status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,'OPEN')
     RETURNING id, status, created_at`,
    [customerId, input.projectId ?? null, input.projectName ?? null, input.materialName, input.specification ?? null,
     input.quantity, input.unit, input.requiredDeliveryDate ?? null, input.deliveryLocation,
     input.deliveryLat ?? null, input.deliveryLng ?? null, input.additionalRequirements ?? null,
     input.targetPrice ?? null, JSON.stringify(input.attachments ?? []), input.expiryAt ?? null]
  );
  return result.rows[0];
}

export async function listMyRfqs(customerId: string) {
  const result = await db.query(
    `SELECT r.*, (SELECT COUNT(*) FROM rfq_quotes q WHERE q.rfq_id = r.id) AS quote_count
     FROM rfqs r WHERE r.customer_id = $1 ORDER BY r.created_at DESC`,
    [customerId]
  );
  return result.rows;
}

// Supplier-facing discovery: open RFQs, optionally near a location.
export async function listOpenRfqsForSuppliers(materialName?: string) {
  const result = materialName
    ? await db.query(`SELECT * FROM rfqs WHERE status = 'OPEN' AND material_name ILIKE $1 ORDER BY created_at DESC`, [`%${materialName}%`])
    : await db.query(`SELECT * FROM rfqs WHERE status = 'OPEN' ORDER BY created_at DESC`);
  return result.rows;
}

export async function getRfq(id: string) {
  const result = await db.query('SELECT * FROM rfqs WHERE id = $1', [id]);
  return result.rows[0] ?? null;
}

export interface SubmitQuoteInput {
  pricePerUnit: number; availableQuantity: number; deliveryTimeDays?: number;
  transportCost?: number; taxPercent?: number; quoteValidityUntil?: string; notes?: string;
}

export async function submitQuote(rfqId: string, supplierId: string, input: SubmitQuoteInput) {
  const rfq = await getRfq(rfqId);
  if (!rfq) throw new Error('RFQ not found');
  if (rfq.status !== 'OPEN' && rfq.status !== 'QUOTED') throw new Error('This RFQ is no longer accepting quotes');

  const result = await db.query(
    `INSERT INTO rfq_quotes (rfq_id, supplier_id, price_per_unit, available_quantity, delivery_time_days,
       transport_cost, tax_percent, quote_validity_until, notes)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (rfq_id, supplier_id) DO UPDATE SET
       price_per_unit = $3, available_quantity = $4, delivery_time_days = $5,
       transport_cost = $6, tax_percent = $7, quote_validity_until = $8, notes = $9, updated_at = now()
     RETURNING id, status, created_at`,
    [rfqId, supplierId, input.pricePerUnit, input.availableQuantity, input.deliveryTimeDays ?? null,
     input.transportCost ?? 0, input.taxPercent ?? 0, input.quoteValidityUntil ?? null, input.notes ?? null]
  );
  await db.query(`UPDATE rfqs SET status = 'QUOTED', updated_at = now() WHERE id = $1 AND status = 'OPEN'`, [rfqId]);
  await notify(rfq.customer_id, 'quote_submitted', 'New quote received', `A supplier submitted a quote on your RFQ for ${rfq.material_name}.`, { rfqId });
  return result.rows[0];
}

export async function listQuotesForRfq(rfqId: string) {
  const result = await db.query(
    `SELECT q.*, sp.business_name, sp.rating_avg, sp.rating_count, sp.verification_status,
            sp.service_lat, sp.service_lng
     FROM rfq_quotes q JOIN supplier_profiles sp ON sp.id = q.supplier_id
     WHERE q.rfq_id = $1 ORDER BY q.price_per_unit ASC`,
    [rfqId]
  );
  return result.rows;
}

export async function shortlistQuote(rfqId: string, quoteId: string) {
  await db.query(`UPDATE rfq_quotes SET status = 'SHORTLISTED', updated_at = now() WHERE id = $1 AND rfq_id = $2`, [quoteId, rfqId]);
  await db.query(`UPDATE rfqs SET status = 'SHORTLISTED', updated_at = now() WHERE id = $1`, [rfqId]);
}

// Awarding closes the RFQ and notifies both the winning and losing suppliers.
export async function awardRfq(rfqId: string, quoteId: string) {
  const quote = await db.query('SELECT * FROM rfq_quotes WHERE id = $1 AND rfq_id = $2', [quoteId, rfqId]);
  if (!quote.rows.length) throw new Error('Quote not found for this RFQ');
  const supplierUser = await db.query(
    `SELECT u.id FROM users u JOIN supplier_profiles sp ON sp.user_id = u.id WHERE sp.id = $1`,
    [quote.rows[0].supplier_id]
  );

  await db.query(`UPDATE rfq_quotes SET status = 'AWARDED', updated_at = now() WHERE id = $1`, [quoteId]);
  await db.query(
    `UPDATE rfq_quotes SET status = 'REJECTED', updated_at = now() WHERE rfq_id = $1 AND id != $2 AND status != 'REJECTED'`,
    [rfqId, quoteId]
  );
  await db.query(`UPDATE rfqs SET status = 'AWARDED', awarded_quote_id = $1, updated_at = now() WHERE id = $2`, [quoteId, rfqId]);

  if (supplierUser.rows.length) {
    await notify(supplierUser.rows[0].id, 'quote_accepted', 'Your quote was accepted', 'Your RFQ quote has been awarded. The customer will place an order.', { rfqId, quoteId });
  }
}

export async function expireOldRfqs() {
  await db.query(`UPDATE rfqs SET status = 'EXPIRED', updated_at = now() WHERE status IN ('OPEN','QUOTED') AND expiry_at IS NOT NULL AND expiry_at < now()`);
}
