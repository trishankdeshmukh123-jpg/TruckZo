// Standalone truck listing + search/filter for the normal marketplace
// (task spec §2) — separate from tenderService.ts, which covers the
// Government Tender module's own truck listings (a different table).

import { db } from '../config/db';
import { mapProvider } from './locationService';
import { VehicleCategory, CapacityBracket } from '../types/enums';

export interface UpsertTruckInput {
  registrationNumber: string;
  vehicleCategory: VehicleCategory;
  capacityBracket?: CapacityBracket;
  capacityTons?: number;
  ratePerTrip?: number;
  ratePerKm?: number;
  currentLat?: number;
  currentLng?: number;
  vehicleDetails?: string;
  driverName?: string;
  driverPhone?: string;
  isAvailable?: boolean;
}

export async function createTruck(supplierId: string, input: UpsertTruckInput) {
  let driverId: string | null = null;
  if (input.driverName && input.driverPhone) {
    const driver = await db.query(
      `INSERT INTO driver_profiles (supplier_id, full_name, phone) VALUES ($1,$2,$3) RETURNING id`,
      [supplierId, input.driverName, input.driverPhone]
    );
    driverId = driver.rows[0].id;
  }
  const result = await db.query(
    `INSERT INTO trucks
      (supplier_id, registration_number, vehicle_category, capacity_bracket, capacity_tons,
       rate_per_trip, rate_per_km, current_lat, current_lng, vehicle_details, driver_id, is_available)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
     RETURNING id`,
    [
      supplierId, input.registrationNumber, input.vehicleCategory, input.capacityBracket ?? null,
      input.capacityTons ?? null, input.ratePerTrip ?? null, input.ratePerKm ?? null,
      input.currentLat ?? null, input.currentLng ?? null, input.vehicleDetails ?? null,
      driverId, input.isAvailable ?? true,
    ]
  );
  return result.rows[0];
}

export async function listSupplierTrucks(supplierId: string) {
  const result = await db.query(
    `SELECT t.*, d.full_name AS driver_name, d.phone AS driver_phone
     FROM trucks t LEFT JOIN driver_profiles d ON d.id = t.driver_id
     WHERE t.supplier_id = $1 ORDER BY t.created_at DESC`,
    [supplierId]
  );
  return result.rows;
}

export interface TruckSearchFilters {
  vehicleCategory?: VehicleCategory;
  capacityBracket?: CapacityBracket;
  lat?: number;
  lng?: number;
  maxDistanceKm?: number;
  onlyAvailable?: boolean;
  maxRatePerTrip?: number;
  maxRatePerKm?: number;
}

// Customer-facing search/filter (task spec §2: "Customers should be able
// to search/filter trucks by vehicle category, capacity, location,
// availability, price").
export async function searchTrucks(filters: TruckSearchFilters) {
  const conditions: string[] = ['sp.verification_status = \'APPROVED\''];
  const params: unknown[] = [];

  if (filters.vehicleCategory) {
    params.push(filters.vehicleCategory);
    conditions.push(`t.vehicle_category = $${params.length}`);
  }
  if (filters.capacityBracket) {
    params.push(filters.capacityBracket);
    conditions.push(`t.capacity_bracket = $${params.length}`);
  }
  if (filters.onlyAvailable) {
    conditions.push('t.is_available = true');
  }
  if (filters.maxRatePerTrip) {
    params.push(filters.maxRatePerTrip);
    conditions.push(`t.rate_per_trip <= $${params.length}`);
  }
  if (filters.maxRatePerKm) {
    params.push(filters.maxRatePerKm);
    conditions.push(`t.rate_per_km <= $${params.length}`);
  }

  const rows = await db.query(
    `SELECT t.id, t.registration_number, t.vehicle_category, t.capacity_bracket, t.capacity_tons,
            t.rate_per_trip, t.rate_per_km, t.current_lat, t.current_lng, t.vehicle_details, t.is_available,
            d.full_name AS driver_name, d.phone AS driver_phone,
            sp.business_name AS supplier_name, sp.rating_avg, sp.rating_count
     FROM trucks t
     JOIN supplier_profiles sp ON sp.id = t.supplier_id
     LEFT JOIN driver_profiles d ON d.id = t.driver_id
     WHERE ${conditions.join(' AND ')}`,
    params
  );

  let results = rows.rows.map((r) => ({
    id: r.id, registrationNumber: r.registration_number, vehicleCategory: r.vehicle_category,
    capacityBracket: r.capacity_bracket, capacityTons: r.capacity_tons ? Number(r.capacity_tons) : null,
    ratePerTrip: r.rate_per_trip ? Number(r.rate_per_trip) : null, ratePerKm: r.rate_per_km ? Number(r.rate_per_km) : null,
    currentLat: r.current_lat ? Number(r.current_lat) : null, currentLng: r.current_lng ? Number(r.current_lng) : null,
    vehicleDetails: r.vehicle_details, isAvailable: r.is_available,
    driverName: r.driver_name, driverPhone: r.driver_phone,
    supplierName: r.supplier_name, rating: Number(r.rating_avg), ratingCount: r.rating_count,
    distanceKm: null as number | null,
  }));

  if (filters.lat != null && filters.lng != null) {
    results = await Promise.all(results.map(async (r) => {
      if (r.currentLat == null || r.currentLng == null) return r;
      const distanceKm = await mapProvider.distanceKm(
        { lat: filters.lat!, lng: filters.lng! }, { lat: r.currentLat, lng: r.currentLng }
      );
      return { ...r, distanceKm: Math.round(distanceKm * 10) / 10 };
    }));
    if (filters.maxDistanceKm) {
      results = results.filter((r) => r.distanceKm == null || r.distanceKm <= filters.maxDistanceKm!);
    }
    results.sort((a, b) => (a.distanceKm ?? Infinity) - (b.distanceKm ?? Infinity));
  }

  return results;
}
