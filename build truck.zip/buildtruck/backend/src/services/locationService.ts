// Map/geo abstraction. MockMapProvider (haversine) needs zero external
// dependencies. GoogleMapsProvider below is a real, runnable implementation
// for the moment you have a key — same MapProvider interface, so nothing
// else in the codebase changes when you switch providers.
//
// ENVIRONMENT VARIABLES REQUIRED for real maps:
//   MAPS_PROVIDER=google
//   MAPS_PROVIDER_API_KEY=<Google Cloud API key with Distance Matrix,
//     Geocoding and Directions APIs enabled — see console.cloud.google.com>
// Google Maps is used as the concrete example since it has the best India
// road-network coverage; Mapbox would follow the same shape (Directions +
// Geocoding APIs).

export interface LatLng { lat: number; lng: number; }

export interface MapProvider {
  distanceKm(a: LatLng, b: LatLng): Promise<number>;
  etaMinutes(a: LatLng, b: LatLng): Promise<number>;
  geocode(address: string): Promise<LatLng>;
}

class MockMapProvider implements MapProvider {
  async distanceKm(a: LatLng, b: LatLng): Promise<number> {
    return haversineKm(a, b);
  }
  async etaMinutes(a: LatLng, b: LatLng): Promise<number> {
    const distance = await this.distanceKm(a, b);
    const avgSpeedKmh = 30; // rough city/highway-mix average for a loaded truck
    return Math.round((distance / avgSpeedKmh) * 60);
  }
  async geocode(_address: string): Promise<LatLng> {
    throw new Error(
      'MockMapProvider cannot geocode free-text addresses. Set MAPS_PROVIDER=google ' +
      'with MAPS_PROVIDER_API_KEY, or require lat/lng from the client-side map picker.'
    );
  }
}

function haversineKm(a: LatLng, b: LatLng): number {
  const R = 6371;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

// Real implementation using Google's Distance Matrix (road distance/ETA,
// far more accurate than haversine for actual truck routes) and Geocoding
// APIs.
class GoogleMapsProvider implements MapProvider {
  private apiKey = process.env.MAPS_PROVIDER_API_KEY as string;

  async distanceKm(a: LatLng, b: LatLng): Promise<number> {
    const url = new URL('https://maps.googleapis.com/maps/api/distancematrix/json');
    url.searchParams.set('origins', `${a.lat},${a.lng}`);
    url.searchParams.set('destinations', `${b.lat},${b.lng}`);
    url.searchParams.set('key', this.apiKey);
    const res = await fetch(url.toString());
    const data = await res.json();
    const element = data.rows?.[0]?.elements?.[0];
    if (element?.status !== 'OK') {
      // Fall back to straight-line distance rather than failing the order
      // outright — road distance is nice-to-have, not required to price.
      return haversineKm(a, b);
    }
    return element.distance.value / 1000; // meters -> km
  }

  async etaMinutes(a: LatLng, b: LatLng): Promise<number> {
    const url = new URL('https://maps.googleapis.com/maps/api/distancematrix/json');
    url.searchParams.set('origins', `${a.lat},${a.lng}`);
    url.searchParams.set('destinations', `${b.lat},${b.lng}`);
    url.searchParams.set('key', this.apiKey);
    const res = await fetch(url.toString());
    const data = await res.json();
    const element = data.rows?.[0]?.elements?.[0];
    if (element?.status !== 'OK') {
      const distance = await this.distanceKm(a, b);
      return Math.round((distance / 30) * 60);
    }
    return Math.round(element.duration.value / 60); // seconds -> minutes
  }

  async geocode(address: string): Promise<LatLng> {
    const url = new URL('https://maps.googleapis.com/maps/api/geocode/json');
    url.searchParams.set('address', address);
    url.searchParams.set('region', 'in'); // bias results to India
    url.searchParams.set('key', this.apiKey);
    const res = await fetch(url.toString());
    const data = await res.json();
    const loc = data.results?.[0]?.geometry?.location;
    if (!loc) throw new Error(`Could not geocode address: ${address}`);
    return { lat: loc.lat, lng: loc.lng };
  }
}

function buildMapProvider(): MapProvider {
  if (process.env.MAPS_PROVIDER === 'google') {
    if (!process.env.MAPS_PROVIDER_API_KEY) {
      throw new Error('MAPS_PROVIDER=google requires MAPS_PROVIDER_API_KEY to be set.');
    }
    return new GoogleMapsProvider();
  }
  return new MockMapProvider();
}

export const mapProvider: MapProvider = buildMapProvider();

// Lets pricing/UI mark a distance as "approximate (straight-line)" vs a
// real road-distance figure, rather than silently presenting haversine as
// if it were exact — see task requirement on maps/distance honesty.
export function isUsingRealMapProvider(): boolean {
  return process.env.MAPS_PROVIDER === 'google';
}

export async function getDistanceKm(origin: LatLng, dest: LatLng): Promise<number> {
  return mapProvider.distanceKm(origin, dest);
}
