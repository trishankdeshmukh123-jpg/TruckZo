// Read-only catalog: categories + materials. Powers Home/Categories/
// MaterialList screens with live data instead of the bundled sample set.

import { db } from '../config/db';

export async function listCategories() {
  const result = await db.query(
    `SELECT id, name, slug, icon_url, sort_order FROM categories
     WHERE is_active = true ORDER BY sort_order ASC`
  );
  return result.rows;
}

export async function listMaterials(categoryId?: string) {
  const result = categoryId
    ? await db.query(
        `SELECT id, category_id, name, description, default_unit FROM materials
         WHERE is_active = true AND category_id = $1 ORDER BY name ASC`,
        [categoryId]
      )
    : await db.query(
        `SELECT id, category_id, name, description, default_unit FROM materials
         WHERE is_active = true ORDER BY name ASC`
      );
  return result.rows;
}

export async function getMaterial(id: string) {
  const result = await db.query(
    `SELECT id, category_id, name, description, default_unit FROM materials WHERE id = $1`,
    [id]
  );
  return result.rows[0] ?? null;
}

// ---- Category-configurable material specs (task spec: "configurable by
// category instead of hardcoding") ----
export async function getCategorySpecFields(categoryId: string) {
  const result = await db.query(
    `SELECT id, field_name, field_type, options, is_required FROM category_spec_fields
     WHERE category_id = $1 ORDER BY sort_order ASC`,
    [categoryId]
  );
  return result.rows;
}

export async function createCategorySpecField(categoryId: string, fieldName: string, fieldType: 'select' | 'text' | 'number', options?: string[], isRequired?: boolean) {
  const result = await db.query(
    `INSERT INTO category_spec_fields (category_id, field_name, field_type, options, is_required)
     VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [categoryId, fieldName, fieldType, JSON.stringify(options ?? []), isRequired ?? false]
  );
  return result.rows[0];
}
