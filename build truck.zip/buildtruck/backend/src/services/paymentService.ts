// Payment gateway abstraction. MockPaymentProvider lets the MVP run
// end-to-end without a real gateway. RazorpayProvider below is a real,
// runnable implementation you can switch on the moment you have keys —
// nothing else in the codebase changes, because both implement the same
// PaymentProvider interface and paymentProvider is selected once, here.
//
// ENVIRONMENT VARIABLES REQUIRED for real payments:
//   PAYMENT_PROVIDER=razorpay
//   PAYMENT_PROVIDER_KEY_ID=<Razorpay key id>
//   PAYMENT_PROVIDER_KEY_SECRET=<Razorpay key secret>
//   PAYMENT_WEBHOOK_SECRET=<Razorpay webhook signing secret>
// Get these from the Razorpay dashboard (Settings -> API Keys, and
// Settings -> Webhooks for the webhook secret). Razorpay is used as the
// concrete example because it's the most common India-first gateway with
// native UPI support; PayU/Cashfree would follow the same shape.

import crypto from 'crypto';
import { PaymentStatus } from '../types/enums';

export interface PaymentIntentResult {
  providerPaymentId: string;
  status: PaymentStatus;
  checkoutUrl?: string; // client opens this (or the Razorpay Checkout SDK) to complete payment
}

export interface PaymentProvider {
  createIntent(orderId: string, amount: number): Promise<PaymentIntentResult>;
  verifyWebhook(rawBody: string, signature: string): boolean;
  refund(providerPaymentId: string, amount: number): Promise<{ status: PaymentStatus }>;
}

class MockPaymentProvider implements PaymentProvider {
  async createIntent(orderId: string, _amount: number): Promise<PaymentIntentResult> {
    // Auto-succeeds for local/dev testing.
    return { providerPaymentId: `mock_${orderId}_${Date.now()}`, status: 'SUCCESS' };
  }
  verifyWebhook(_rawBody: string, _signature: string): boolean {
    return true; // never do this in production — see RazorpayProvider below
  }
  async refund(_providerPaymentId: string, _amount: number): Promise<{ status: PaymentStatus }> {
    return { status: 'REFUNDED' };
  }
}

// Real implementation. Amounts are in paise (₹1 = 100 paise) per Razorpay's API.
class RazorpayProvider implements PaymentProvider {
  private keyId = process.env.PAYMENT_PROVIDER_KEY_ID as string;
  private keySecret = process.env.PAYMENT_PROVIDER_KEY_SECRET as string;
  private webhookSecret = process.env.PAYMENT_WEBHOOK_SECRET as string;
  private authHeader = 'Basic ' + Buffer.from(`${this.keyId}:${this.keySecret}`).toString('base64');

  async createIntent(orderId: string, amount: number): Promise<PaymentIntentResult> {
    const res = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { Authorization: this.authHeader, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amount: Math.round(amount * 100), // paise
        currency: 'INR',
        receipt: orderId,
        notes: { buildtruck_order_id: orderId },
      }),
    });
    if (!res.ok) throw new Error(`Razorpay order creation failed: ${res.status}`);
    const data = await res.json();
    return {
      providerPaymentId: data.id,
      status: 'PENDING', // client completes payment via Razorpay Checkout using this order id
      checkoutUrl: undefined, // Razorpay uses an SDK/modal, not a redirect URL — pass data.id to the mobile Checkout SDK
    };
  }

  // Verifies the webhook signature per Razorpay's docs: HMAC-SHA256 of the
  // raw request body using the webhook secret, compared to the
  // X-Razorpay-Signature header. NEVER trust a webhook payload without this.
  verifyWebhook(rawBody: string, signature: string): boolean {
    const expected = crypto.createHmac('sha256', this.webhookSecret).update(rawBody).digest('hex');
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  }

  async refund(providerPaymentId: string, amount: number): Promise<{ status: PaymentStatus }> {
    const res = await fetch(`https://api.razorpay.com/v1/payments/${providerPaymentId}/refund`, {
      method: 'POST',
      headers: { Authorization: this.authHeader, 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: Math.round(amount * 100) }),
    });
    if (!res.ok) throw new Error(`Razorpay refund failed: ${res.status}`);
    return { status: 'REFUNDED' };
  }
}

function buildPaymentProvider(): PaymentProvider {
  if (process.env.PAYMENT_PROVIDER === 'razorpay') {
    if (!process.env.PAYMENT_PROVIDER_KEY_ID || !process.env.PAYMENT_PROVIDER_KEY_SECRET || !process.env.PAYMENT_WEBHOOK_SECRET) {
      throw new Error(
        'PAYMENT_PROVIDER=razorpay requires PAYMENT_PROVIDER_KEY_ID, PAYMENT_PROVIDER_KEY_SECRET and PAYMENT_WEBHOOK_SECRET to be set.'
      );
    }
    return new RazorpayProvider();
  }
  return new MockPaymentProvider();
}

export const paymentProvider: PaymentProvider = buildPaymentProvider();
