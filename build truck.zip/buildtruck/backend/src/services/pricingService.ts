// Server-side pricing. This is the ONLY place order totals are allowed to be
// computed. The mobile app may show a preview using the same formula, but
// whatever it sends is re-derived here from scratch before an order is saved.
//
// The full configurable delivery-pricing engine (base fare, per-km rate,
// vehicle-category multiplier, loading, unloading, waiting, toll, remote-area
// charge, number of trips) is applied here directly — this is no longer a
// separate "advanced" path used only by RFQs; it IS the real checkout
// calculation. A normal single-truck order simply passes vehicleCategory
// undefined (multiplier 1.0), numberOfTrips 1, waitingHours 0 — the same
// formula, just with the extras at their neutral defaults.

import { getPricingSettings, getAdvancedPricingFactors, getVehicleRateMultiplier } from '../config/settingsRepository';
import { getDistanceKm, isUsingRealMapProvider } from './locationService';

export interface PriceBreakdown {
  materialCost: number;
  deliveryDistanceKm: number;
  isApproximateDistance: boolean;  // true = haversine straight-line fallback, not real road distance
  deliveryCharge: number;
  deliveryChargeBreakdown: {
    baseFare: number; distanceCharge: number; loadingCharge: number; unloadingCharge: number;
    waitingCharge: number; tollCharge: number; remoteAreaCharge: number; vehicleMultiplier: number;
    numberOfTrips: number;
  };
  platformCharges: number;
  discountAmount: number;
  totalAmount: number;
}

export interface PriceQuoteInput {
  items: { unitPrice: number; quantity: number }[];
  originLat: number; originLng: number;   // supplier or pickup location
  destLat: number; destLng: number;       // delivery address
  discountAmount?: number;                // from a validated coupon, computed elsewhere — never client-supplied directly
  vehicleCategory?: string;               // from the assigned/selected truck; defaults to no multiplier (1.0)
  numberOfTrips?: number;                 // multi-load orders; defaults to 1
  waitingHours?: number;                  // defaults to 0
  tollCharge?: number;                    // actual toll if known; falls back to admin default
}

export class DeliveryOutOfRangeError extends Error {
  constructor(distanceKm: number, maxKm: number) {
    super(`Delivery distance ${distanceKm}km exceeds max allowed ${maxKm}km`);
    this.name = 'DeliveryOutOfRangeError';
  }
}

export async function calculatePriceQuote(input: PriceQuoteInput): Promise<PriceBreakdown> {
  const settings = await getPricingSettings();
  const advanced = await getAdvancedPricingFactors();

  const materialCost = round2(
    input.items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0)
  );

  const deliveryDistanceKm = await getDistanceKm(
    { lat: input.originLat, lng: input.originLng },
    { lat: input.destLat, lng: input.destLng }
  );

  if (deliveryDistanceKm > settings.maxDeliveryDistanceKm) {
    throw new DeliveryOutOfRangeError(deliveryDistanceKm, settings.maxDeliveryDistanceKm);
  }

  const numberOfTrips = input.numberOfTrips ?? 1;
  const vehicleMultiplier = await getVehicleRateMultiplier(input.vehicleCategory ?? 'other');

  const baseFare = round2(settings.baseDeliveryCharge * vehicleMultiplier);
  const distanceCharge = round2(settings.perKmCharge * vehicleMultiplier * deliveryDistanceKm);
  const loadingCharge = advanced.loadingCharge;
  const unloadingCharge = advanced.unloadingCharge;
  const waitingCharge = round2((input.waitingHours ?? 0) * advanced.waitingChargePerHour);
  const tollCharge = input.tollCharge ?? advanced.defaultTollCharge;
  const isRemote = deliveryDistanceKm > advanced.remoteAreaDistanceKm;
  const remoteAreaCharge = isRemote ? advanced.remoteAreaCharge : 0;

  const perTripCharge = Math.max(
    settings.minDeliveryCharge,
    baseFare + distanceCharge + loadingCharge + unloadingCharge + waitingCharge + tollCharge + remoteAreaCharge
  );
  const deliveryCharge = round2(perTripCharge * numberOfTrips);

  const platformCharges = round2(settings.platformFlatCharge);
  const discountAmount = round2(input.discountAmount ?? 0);

  const totalAmount = round2(
    materialCost + deliveryCharge + platformCharges - discountAmount
  );

  return {
    materialCost,
    deliveryDistanceKm: round2(deliveryDistanceKm),
    isApproximateDistance: !isUsingRealMapProvider(),
    deliveryCharge,
    deliveryChargeBreakdown: {
      baseFare, distanceCharge, loadingCharge, unloadingCharge, waitingCharge,
      tollCharge, remoteAreaCharge, vehicleMultiplier, numberOfTrips,
    },
    platformCharges,
    discountAmount,
    totalAmount,
  };
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

// ---- Standalone advanced quote preview (used by RFQ quoting and the
// mobile "advanced quote" preview screen) — same formula, exposed without
// requiring a full order context (no material items). ----
export interface AdvancedDeliveryChargeInput {
  distanceKm: number;
  vehicleCategory: string;
  numberOfTrips?: number;
  waitingHours?: number;
  tollCharge?: number;
  remoteAreaOverride?: boolean;
}

export interface AdvancedDeliveryChargeBreakdown {
  baseFare: number; distanceCharge: number; loadingCharge: number; unloadingCharge: number;
  waitingCharge: number; tollCharge: number; remoteAreaCharge: number; vehicleMultiplier: number;
  perTripCharge: number; numberOfTrips: number; totalCharge: number;
}

export async function calculateAdvancedDeliveryCharge(input: AdvancedDeliveryChargeInput): Promise<AdvancedDeliveryChargeBreakdown> {
  const base = await getPricingSettings();
  const advanced = await getAdvancedPricingFactors();
  const multiplier = await getVehicleRateMultiplier(input.vehicleCategory);
  const numberOfTrips = input.numberOfTrips ?? 1;

  const baseFare = round2(base.baseDeliveryCharge * multiplier);
  const distanceCharge = round2(base.perKmCharge * multiplier * input.distanceKm);
  const loadingCharge = advanced.loadingCharge;
  const unloadingCharge = advanced.unloadingCharge;
  const waitingCharge = round2((input.waitingHours ?? 0) * advanced.waitingChargePerHour);
  const tollCharge = input.tollCharge ?? advanced.defaultTollCharge;
  const isRemote = input.remoteAreaOverride ?? input.distanceKm > advanced.remoteAreaDistanceKm;
  const remoteAreaCharge = isRemote ? advanced.remoteAreaCharge : 0;

  const perTripCharge = round2(
    Math.max(base.minDeliveryCharge, baseFare + distanceCharge + loadingCharge + unloadingCharge + waitingCharge + tollCharge + remoteAreaCharge)
  );
  const totalCharge = round2(perTripCharge * numberOfTrips);

  return {
    baseFare, distanceCharge, loadingCharge, unloadingCharge, waitingCharge, tollCharge,
    remoteAreaCharge, vehicleMultiplier: multiplier, perTripCharge, numberOfTrips, totalCharge,
  };
}
