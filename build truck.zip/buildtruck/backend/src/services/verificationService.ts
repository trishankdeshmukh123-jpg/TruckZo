// Supplier + truck document verification, with expiry tracking. A
// "Verified" badge (see supplier_profiles.verification_status /
// trucks — read at the profile level) should only be shown once an admin
// has actually verified the relevant documents here.

import { db } from '../config/db';
import { notify } from './notificationService';
import { VerificationOwnerType, DocumentVerificationStatus } from '../types/enums';

export async function uploadDocument(ownerType: VerificationOwnerType, ownerId: string, docType: string, fileUrl: string, expiryDate?: string) {
  const result = await db.query(
    `INSERT INTO verification_documents (owner_type, owner_id, doc_type, file_url, expiry_date, status)
     VALUES ($1,$2,$3,$4,$5,'PENDING') RETURNING id, status`,
    [ownerType, ownerId, docType, fileUrl, expiryDate ?? null]
  );
  return result.rows[0];
}

export async function listDocumentsForOwner(ownerType: VerificationOwnerType, ownerId: string) {
  const result = await db.query(
    'SELECT * FROM verification_documents WHERE owner_type = $1 AND owner_id = $2 ORDER BY created_at DESC',
    [ownerType, ownerId]
  );
  return result.rows;
}

export async function listAllDocuments(status?: DocumentVerificationStatus) {
  const result = status
    ? await db.query('SELECT * FROM verification_documents WHERE status = $1 ORDER BY created_at DESC', [status])
    : await db.query('SELECT * FROM verification_documents ORDER BY created_at DESC');
  return result.rows;
}

export async function decideDocument(docId: string, status: 'VERIFIED' | 'REJECTED', adminId: string) {
  const result = await db.query(
    `UPDATE verification_documents SET status = $1, verified_by = $2, verified_at = now() WHERE id = $3
     RETURNING owner_type, owner_id, doc_type`,
    [status, adminId, docId]
  );
  return result.rows[0];
}

// Run periodically (or on read) to flip PENDING/VERIFIED docs whose
// expiry_date has passed into EXPIRED, and to remind the owner.
export async function expireDocumentsAndNotify() {
  const expiring = await db.query(
    `SELECT vd.id, vd.owner_type, vd.owner_id, vd.doc_type,
            CASE vd.owner_type WHEN 'SUPPLIER' THEN sp.user_id ELSE NULL END AS supplier_user_id
     FROM verification_documents vd
     LEFT JOIN supplier_profiles sp ON vd.owner_type = 'SUPPLIER' AND sp.id = vd.owner_id
     WHERE vd.status = 'VERIFIED' AND vd.expiry_date IS NOT NULL AND vd.expiry_date < CURRENT_DATE`
  );
  for (const doc of expiring.rows) {
    await db.query(`UPDATE verification_documents SET status = 'EXPIRED' WHERE id = $1`, [doc.id]);
    if (doc.supplier_user_id) {
      await notify(doc.supplier_user_id, 'document_expiry', 'Document expired', `Your ${doc.doc_type} document has expired — please re-upload it.`, { docId: doc.id });
    }
  }
}
