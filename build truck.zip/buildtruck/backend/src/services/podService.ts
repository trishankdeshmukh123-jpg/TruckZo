// Proof of Delivery. Created when a driver/supplier confirms a delivery
// (single-truck order or one trip of a multi-truck order). Supports
// partial/shortage delivery by recording delivered_quantity separately
// from the order's/trip's planned quantity.

import { db } from '../config/db';
import { notify } from './notificationService';

export interface CreatePodInput {
  orderId: string; tripId?: string; deliveredQuantity: number;
  shortageNotes?: string; photoUrls?: string[]; signatureUrl?: string;
  customerConfirmed?: boolean; otpVerified?: boolean; lat?: number; lng?: number;
}

export async function createPod(input: CreatePodInput) {
  const result = await db.query(
    `INSERT INTO proof_of_deliveries
      (order_id, trip_id, delivered_quantity, shortage_notes, photo_urls, signature_url,
       customer_confirmed, otp_verified, lat, lng)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     RETURNING id, delivered_at`,
    [input.orderId, input.tripId ?? null, input.deliveredQuantity, input.shortageNotes ?? null,
     JSON.stringify(input.photoUrls ?? []), input.signatureUrl ?? null,
     input.customerConfirmed ?? false, input.otpVerified ?? false, input.lat ?? null, input.lng ?? null]
  );

  const order = await db.query('SELECT customer_id, supplier_id FROM orders WHERE id = $1', [input.orderId]);
  if (order.rows.length) {
    await notify(order.rows[0].customer_id, 'pod_generated', 'Delivery confirmed', `Proof of delivery recorded for ${input.deliveredQuantity} units.`, { orderId: input.orderId, podId: result.rows[0].id });
  }
  return result.rows[0];
}

export async function getPodsForOrder(orderId: string) {
  const result = await db.query('SELECT * FROM proof_of_deliveries WHERE order_id = $1 ORDER BY delivered_at DESC', [orderId]);
  return result.rows;
}
