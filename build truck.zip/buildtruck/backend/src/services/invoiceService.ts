// Invoice generation with GST/tax calculation (migration 003 columns).
// Called automatically from orderService inside the same transaction as
// order completion (see orderService.ts's transitionOrderStatus) — invoices
// are never generated speculatively for an order that hasn't finished, and
// if invoice generation fails, the whole completion rolls back with it.

import { db, TxHandle } from '../config/db';
import { getSetting } from '../config/settingsRepository';

export async function generateInvoiceForOrder(orderId: string, tx: TxHandle = db) {
  const existing = await tx.query('SELECT id FROM invoices WHERE order_id = $1', [orderId]);
  if (existing.rows.length) return existing.rows[0];

  const order = await tx.query(
    `SELECT material_cost, delivery_charge, platform_charges, discount_amount, supplier_id
     FROM orders WHERE id = $1`, [orderId]
  );
  if (!order.rows.length) throw new Error('Order not found');
  const o = order.rows[0];

  const supplierRow = await tx.query('SELECT gst_number FROM supplier_profiles WHERE id = $1', [o.supplier_id]);
  const supplierGst: string | null = supplierRow.rows[0]?.gst_number ?? null;

  // GST rate is admin-configurable (admin_settings.gst_rate_percent,
  // migration 003). Taxable amount = material + delivery + platform
  // charges, net of discount — matches how most Indian service/goods
  // invoices present a single taxable base before tax lines.
  const gstRate = await getSetting<number>('gst_rate_percent');
  const materialCharges = Number(o.material_cost);
  const deliveryCharges = Number(o.delivery_charge);
  const platformCharges = Number(o.platform_charges);
  const discountAmount = Number(o.discount_amount);
  const taxableAmount = round2(materialCharges + deliveryCharges + platformCharges - discountAmount);

  // Interstate (IGST) vs intrastate (CGST+SGST) determination requires
  // knowing both the supplier's and the customer's state. supplier_profiles
  // has no structured state column (only a free-text business_address), so
  // this cannot be reliably automated yet — defaulting to intrastate
  // (CGST+SGST split) is a known simplification, NOT a tax-compliance
  // guarantee. See README "Known limitations" before relying on this for
  // real GST filing; a CA should review before production use.
  const isInterstate = false;
  const taxAmount = round2(taxableAmount * (gstRate / 100));
  const cgstAmount = isInterstate ? 0 : round2(taxAmount / 2);
  const sgstAmount = isInterstate ? 0 : round2(taxAmount / 2);
  const igstAmount = isInterstate ? taxAmount : 0;
  const totalAmount = round2(taxableAmount + taxAmount);

  const invoiceNumber = `INV-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`;

  const result = await tx.query(
    `INSERT INTO invoices
      (order_id, invoice_number, material_charges, delivery_charges, platform_charges,
       discount_amount, tax_amount, total_amount, gst_number, taxable_amount, gst_rate,
       cgst_amount, sgst_amount, igst_amount, is_interstate)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
     RETURNING id, invoice_number, generated_at`,
    [orderId, invoiceNumber, materialCharges, deliveryCharges, platformCharges,
     discountAmount, taxAmount, totalAmount, supplierGst, taxableAmount, gstRate,
     cgstAmount, sgstAmount, igstAmount, isInterstate]
  );
  return result.rows[0];
}

export async function getInvoiceForOrder(orderId: string) {
  const result = await db.query('SELECT * FROM invoices WHERE order_id = $1', [orderId]);
  return result.rows[0] ?? null;
}

export async function listInvoicesForBusiness(businessId: string) {
  const result = await db.query(
    `SELECT inv.* FROM invoices inv
     JOIN orders o ON o.id = inv.order_id
     JOIN projects p ON p.id = o.project_id
     WHERE p.business_id = $1 ORDER BY inv.generated_at DESC`,
    [businessId]
  );
  return result.rows;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
