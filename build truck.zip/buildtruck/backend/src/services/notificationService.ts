// In-app notifications, backed by the `notifications` table already in
// db/schema.sql. Every other new service in this pass calls notify() at
// its key state changes (RFQ created, quote submitted, order accepted,
// dispute updated, etc.) so the notification center is populated by real
// events, not sample data. Push delivery (FCM) is a thin layer on top of
// this — see the ENVIRONMENT VARIABLE note below.
//
// ENVIRONMENT VARIABLE REQUIRED for real push delivery:
// FCM_SERVER_KEY (or FCM service account JSON) — until set, notifications
// are created in-app only (visible via GET /notifications) and no push is sent.

import { db } from '../config/db';

export type NotificationType =
  | 'rfq_created' | 'quote_submitted' | 'quote_accepted' | 'quote_rejected'
  | 'order_accepted' | 'truck_assigned' | 'trip_started' | 'out_for_delivery'
  | 'arriving' | 'delivery_completed' | 'pod_generated' | 'payment_received'
  | 'payment_failed' | 'dispute_update' | 'inventory_low' | 'document_expiry'
  | 'commission_due';

export async function notify(userId: string, type: NotificationType, title: string, body: string, data?: Record<string, unknown>) {
  await db.query(
    `INSERT INTO notifications (user_id, title, body, type, data) VALUES ($1,$2,$3,$4,$5)`,
    [userId, title, body, type, data ? JSON.stringify(data) : null]
  );
  if (process.env.FCM_SERVER_KEY) {
    // TODO(real integration): send a push via FCM using FCM_SERVER_KEY /
    // the user's stored device token (device-token storage not yet built).
  }
}

export async function listForUser(userId: string, unreadOnly = false) {
  const result = await db.query(
    `SELECT id, title, body, type, is_read, data, created_at FROM notifications
     WHERE user_id = $1 ${unreadOnly ? 'AND is_read = false' : ''} ORDER BY created_at DESC LIMIT 100`,
    [userId]
  );
  return result.rows;
}

export async function markRead(userId: string, notificationId: string) {
  await db.query(`UPDATE notifications SET is_read = true WHERE id = $1 AND user_id = $2`, [notificationId, userId]);
}

export async function markAllRead(userId: string) {
  await db.query(`UPDATE notifications SET is_read = true WHERE user_id = $1 AND is_read = false`, [userId]);
}
