// Supplier registration + the "find suppliers near this delivery location"
// search that the mobile app's Supplier Selection screen needs. This was
// the biggest gap flagged in the previous README — customer flow could
// only price a *chosen* supplier, not discover one by location.

import { db } from '../config/db';
import { mapProvider } from './locationService';

export interface RegisterSupplierInput {
  businessName: string;
  businessPhone: string;
  businessAddress: string;
  serviceAreaPincode?: string;
  serviceLat: number;
  serviceLng: number;
  serviceRadiusKm?: number;
  gstNumber?: string;
}

export async function registerSupplier(userId: string, input: RegisterSupplierInput) {
  // A user can only have one supplier_profiles row (UNIQUE(user_id) in schema).
  const existing = await db.query('SELECT id FROM supplier_profiles WHERE user_id = $1', [userId]);
  if (existing.rows.length) {
    throw new Error('This account is already registered as a supplier');
  }

  const result = await db.query(
    `INSERT INTO supplier_profiles
      (user_id, business_name, business_phone, business_address, service_area_pincode,
       service_lat, service_lng, service_radius_km, gst_number, verification_status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'PENDING')
     RETURNING id, verification_status`,
    [
      userId, input.businessName, input.businessPhone, input.businessAddress,
      input.serviceAreaPincode ?? null, input.serviceLat, input.serviceLng,
      input.serviceRadiusKm ?? 25, input.gstNumber ?? null,
    ]
  );

  // Registering as supplier doesn't auto-grant Supplier Mode in the app —
  // admin approval does (see admin.ts's /suppliers/:id/verify, added below).
  return result.rows[0];
}

export interface NearbySupplierOffer {
  supplierId: string;
  businessName: string;
  rating: number;
  ratingCount: number;
  distanceKm: number;
  verified: boolean;
  supplierLat: number;
  supplierLng: number;
  supplierMaterialId: string;
  pricePerUnit: number;
  availableQuantity: number;
  minOrderQuantity: number;
  materialName: string;
  materialUnit: string;
  materialDescription: string | null;
}

// Powers "SupplierSelection" in the app: given a material + delivery point,
// find suppliers who (a) sell it, (b) are approved, (c) have the delivery
// point within their service radius. Sorted cheapest-first, matching the
// mobile UI's "Best price" badge on the first result.
//
// MVP implementation does a bounding-box prefilter in SQL (fast, index-
// friendly) then exact haversine distance + radius check in application
// code. At scale, replace with PostGIS's ST_DWithin/geography type for a
// single indexed query — noted here rather than done now to avoid adding
// a Postgres extension dependency to the MVP.
export async function findNearbySuppliersForMaterial(
  materialId: string,
  deliveryLat: number,
  deliveryLng: number,
  maxResults = 20
): Promise<NearbySupplierOffer[]> {
  // ~1 degree latitude ≈ 111km; use a generous 200km box to prefilter
  // before the exact distance check below.
  const boxDegrees = 200 / 111;

  const rows = await db.query(
    `SELECT sp.id AS supplier_id, sp.business_name, sp.rating_avg, sp.rating_count,
            sp.service_lat, sp.service_lng, sp.service_radius_km, sp.verification_status,
            sm.id AS supplier_material_id, sm.price_per_unit, sm.available_quantity, sm.min_order_quantity,
            m.name AS material_name, m.default_unit AS material_unit, m.description AS material_description
     FROM supplier_materials sm
     JOIN supplier_profiles sp ON sp.id = sm.supplier_id
     JOIN materials m ON m.id = sm.material_id
     WHERE sm.material_id = $1
       AND sm.is_active = true
       AND sp.verification_status = 'APPROVED'
       AND sp.service_lat BETWEEN $2 - $4 AND $2 + $4
       AND sp.service_lng BETWEEN $3 - $4 AND $3 + $4`,
    [materialId, deliveryLat, deliveryLng, boxDegrees]
  );

  const withDistance = await Promise.all(
    rows.rows.map(async (r) => {
      const distanceKm = await mapProvider.distanceKm(
        { lat: deliveryLat, lng: deliveryLng },
        { lat: Number(r.service_lat), lng: Number(r.service_lng) }
      );
      return { r, distanceKm };
    })
  );

  return withDistance
    .filter(({ r, distanceKm }) => distanceKm <= Number(r.service_radius_km))
    .sort((a, b) => a.r.price_per_unit - b.r.price_per_unit)
    .slice(0, maxResults)
    .map(({ r, distanceKm }) => ({
      supplierId: r.supplier_id,
      businessName: r.business_name,
      rating: Number(r.rating_avg),
      ratingCount: r.rating_count,
      distanceKm: Math.round(distanceKm * 10) / 10,
      verified: true, // filtered to APPROVED above
      supplierLat: Number(r.service_lat),
      supplierLng: Number(r.service_lng),
      supplierMaterialId: r.supplier_material_id,
      pricePerUnit: Number(r.price_per_unit),
      availableQuantity: Number(r.available_quantity),
      minOrderQuantity: Number(r.min_order_quantity),
      materialName: r.material_name,
      materialUnit: r.material_unit,
      materialDescription: r.material_description,
    }));
}

export async function setVerificationStatus(
  supplierId: string, status: 'APPROVED' | 'REJECTED' | 'SUSPENDED', notes?: string
): Promise<void> {
  await db.query(
    'UPDATE supplier_profiles SET verification_status = $1, verification_notes = $2, updated_at = now() WHERE id = $3',
    [status, notes ?? null, supplierId]
  );
}

// Resolves the logged-in user's own supplier_profiles row. Every mobile
// supplier screen that needs a supplierId (adding a material, a truck, a
// tender listing) calls this first rather than hardcoding one — there is
// no "demo supplier id" in the real request path.
export async function getMySupplierProfile(userId: string) {
  const result = await db.query(
    `SELECT id, business_name, verification_status, service_lat, service_lng FROM supplier_profiles WHERE user_id = $1`,
    [userId]
  );
  return result.rows[0] ?? null;
}

// ---- Supplier's own material listings (supplier_materials) ----
// This was a gap: trucks had a create endpoint, materials didn't. Without
// this, a supplier could never actually create a real supplier_materials
// row — the material specs (task #4) and inventory columns (task #10)
// added in migration 002 would have had nothing to attach to.
export interface CreateSupplierMaterialInput {
  materialId: string; pricePerUnit: number; unit: string; availableQuantity: number;
  minOrderQuantity?: number; specs?: Record<string, string>; lowStockThreshold?: number;
  expectedRestockDate?: string; images?: string[];
}

export async function createSupplierMaterial(supplierId: string, input: CreateSupplierMaterialInput) {
  const result = await db.query(
    `INSERT INTO supplier_materials
      (supplier_id, material_id, price_per_unit, unit, available_quantity, min_order_quantity, specs,
       low_stock_threshold, expected_restock_date, images)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     ON CONFLICT (supplier_id, material_id) DO UPDATE SET
       price_per_unit = $3, unit = $4, available_quantity = $5, min_order_quantity = $6,
       specs = $7, low_stock_threshold = $8, expected_restock_date = $9, images = $10, updated_at = now()
     RETURNING id`,
    [supplierId, input.materialId, input.pricePerUnit, input.unit, input.availableQuantity,
     input.minOrderQuantity ?? 1, JSON.stringify(input.specs ?? {}), input.lowStockThreshold ?? null,
     input.expectedRestockDate ?? null, JSON.stringify(input.images ?? [])]
  );
  return result.rows[0];
}

export async function listSupplierOwnMaterials(supplierId: string) {
  const result = await db.query(
    `SELECT sm.*, m.name AS material_name, m.default_unit, c.name AS category_name
     FROM supplier_materials sm
     JOIN materials m ON m.id = sm.material_id
     JOIN categories c ON c.id = m.category_id
     WHERE sm.supplier_id = $1 ORDER BY m.name ASC`,
    [supplierId]
  );
  return result.rows;
}

export async function updateSupplierMaterial(id: string, updates: Partial<CreateSupplierMaterialInput> & { isActive?: boolean }) {
  const fields: string[] = [];
  const values: unknown[] = [];
  let i = 1;
  const map: Record<string, unknown> = {
    price_per_unit: updates.pricePerUnit, available_quantity: updates.availableQuantity,
    min_order_quantity: updates.minOrderQuantity, specs: updates.specs ? JSON.stringify(updates.specs) : undefined,
    low_stock_threshold: updates.lowStockThreshold, expected_restock_date: updates.expectedRestockDate,
    is_active: updates.isActive,
  };
  for (const [col, val] of Object.entries(map)) {
    if (val !== undefined) { fields.push(`${col} = $${i}`); values.push(val); i++; }
  }
  if (!fields.length) return;
  values.push(id);
  await db.query(`UPDATE supplier_materials SET ${fields.join(', ')}, updated_at = now() WHERE id = $${i}`, values);
}
