// Server-side commission calculation + ledger writes. Commission is always
// derived from the order's own stored breakdown (never recomputed from
// client input at settlement time — the order row is the source of truth
// once it's created).

import { db, TxHandle } from '../config/db';
import { getCommissionSettings } from '../config/settingsRepository';
import { PriceBreakdown } from './pricingService';
import { PaymentMethod } from '../types/enums';
import { notify } from './notificationService';

export interface CommissionResult {
  commissionRate: number;
  commissionableAmount: number;
  commissionAmount: number;
}

// Only the three fields this function actually reads — using a Pick
// instead of the full PriceBreakdown means callers reconstructing a price
// snapshot from stored order columns (see orderService's COMPLETED branch)
// don't need to fabricate the newer breakdown/approximation fields too.
export type CommissionableAmounts = Pick<PriceBreakdown, 'materialCost' | 'deliveryCharge' | 'platformCharges'>;

export async function calculateCommission(price: CommissionableAmounts): Promise<CommissionResult> {
  const settings = await getCommissionSettings();

  const componentMap: Record<string, number> = {
    material_cost: price.materialCost,
    delivery_charge: price.deliveryCharge,
    platform_charges: price.platformCharges,
  };

  const commissionableAmount = round2(
    settings.commissionableComponents.reduce(
      (sum, component) => sum + (componentMap[component] ?? 0),
      0
    )
  );

  const commissionAmount = round2(
    (commissionableAmount * settings.commissionPercent) / 100
  );

  return {
    commissionRate: settings.commissionPercent,
    commissionableAmount,
    commissionAmount,
  };
}

// Called once an order transitions to COMPLETED. Writes an immutable
// commission_ledger row. For CASH orders this is explicitly a *payable*
// balance the supplier owes the platform — never recorded as "collected".
export async function recordCommissionOnCompletion(params: {
  orderId: string;
  supplierId: string;
  paymentMethod: PaymentMethod;
  commission: CommissionResult;
  tx?: TxHandle;
}): Promise<void> {
  const exec = params.tx ?? db;
  await exec.query(
    `INSERT INTO commission_ledger
       (order_id, supplier_id, commissionable_amount, commission_rate, commission_amount, status)
     VALUES ($1, $2, $3, $4, $5, 'PAYABLE')`,
    [
      params.orderId,
      params.supplierId,
      params.commission.commissionableAmount,
      params.commission.commissionRate,
      params.commission.commissionAmount,
    ]
  );
  // NOTE: for UPI orders, a V2 payout job nets this off against the
  // supplier's payout automatically. For CASH orders, this balance sits as
  // PAYABLE until the supplier settles it (see settlementService, V2) or an
  // admin marks it SETTLED manually from the dashboard.
  //
  // The notify() call below deliberately uses the plain pool `db`, not
  // `tx` — it's a best-effort side effect, not part of the atomic write,
  // consistent with how inventoryService's low-stock notification works.
  if (params.paymentMethod === 'CASH') {
    const supplierUser = await db.query(
      `SELECT u.id FROM users u JOIN supplier_profiles sp ON sp.user_id = u.id WHERE sp.id = $1`,
      [params.supplierId]
    );
    if (supplierUser.rows.length) {
      await notify(supplierUser.rows[0].id, 'commission_due', 'Commission due',
        `A commission of ₹${params.commission.commissionAmount} is now payable on a completed cash order.`,
        { orderId: params.orderId });
    }
  }
}

export async function getSupplierPendingCommission(supplierId: string): Promise<number> {
  const result = await db.query(
    `SELECT COALESCE(SUM(commission_amount), 0) AS pending
     FROM commission_ledger WHERE supplier_id = $1 AND status = 'PAYABLE'`,
    [supplierId]
  );
  return Number(result.rows[0].pending);
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
