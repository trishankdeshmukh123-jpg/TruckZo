// Single SMS send path for the whole backend — OTP delivery (authService,
// orderService) and any other transactional SMS go through here, so there
// is exactly one place that decides "do we actually have SMS configured".
//
// ENVIRONMENT VARIABLE REQUIRED for real delivery: SMS_PROVIDER_API_KEY
// (plus SMS_PROVIDER_SENDER_ID if your provider requires a sender/route id).
// Wire the real HTTP call for your provider (MSG91, Twilio Verify,
// Gupshup, etc.) where marked TODO below.
//
// Production safety: when SMS_PROVIDER_API_KEY is NOT set,
// - in any NON-production NODE_ENV, the message is logged to the server
//   console so OTPs are testable locally without a real SMS account.
// - in NODE_ENV=production, nothing is logged (an OTP in a prod log file
//   would be a real credential leak) and this throws a clear
//   SmsNotConfiguredError instead of silently "succeeding" — callers must
//   surface that as a real error, not pretend the SMS went out.

export class SmsNotConfiguredError extends Error {
  constructor() {
    super('SMS delivery is not configured for this environment (set SMS_PROVIDER_API_KEY).');
    this.name = 'SmsNotConfiguredError';
  }
}

export interface SmsSendResult {
  sent: boolean;
  reason?: string; // e.g. 'logged-to-console-dev-only'
}

export async function sendSms(phone: string, message: string): Promise<SmsSendResult> {
  if (process.env.SMS_PROVIDER_API_KEY) {
    // TODO(real integration): call your SMS provider's send API here, e.g.
    // await fetch('https://api.msg91.com/api/v5/flow/', { ... });
    // Left unimplemented deliberately — there's no single standard HTTP
    // shape across Indian SMS/OTP providers, so wire the one you pick.
    return { sent: true };
  }

  if (process.env.NODE_ENV === 'production') {
    throw new SmsNotConfiguredError();
  }

  // Dev/test only — never reachable when NODE_ENV=production (checked above).
  // eslint-disable-next-line no-console
  console.log(`[buildtruck][dev-only] SMS to ${phone}: ${message}`);
  return { sent: false, reason: 'logged-to-console-dev-only' };
}

export async function sendOtpSms(phone: string, otp: string): Promise<SmsSendResult> {
  return sendSms(phone, `Your BuildTruck OTP is ${otp}. Valid for 10 minutes.`);
}
