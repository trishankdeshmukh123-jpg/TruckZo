// Customer saved addresses. lat/lng are required at creation — free-text
// geocoding needs MAPS_PROVIDER=google (see locationService.ts); until
// then, addresses come from GPS or a client-side map pin.

import { db } from '../config/db';

export interface CreateAddressInput {
  label?: string; line1: string; line2?: string; city: string;
  district?: string; state: string; pincode: string; lat: number; lng: number;
}

export async function listAddresses(userId: string) {
  const result = await db.query(
    `SELECT id, label, line1, line2, city, district, state, pincode, lat, lng
     FROM addresses WHERE user_id = $1 ORDER BY created_at DESC`,
    [userId]
  );
  return result.rows;
}

export async function createAddress(userId: string, input: CreateAddressInput) {
  const result = await db.query(
    `INSERT INTO addresses (user_id, label, line1, line2, city, district, state, pincode, lat, lng)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     RETURNING id, label, line1, line2, city, district, state, pincode, lat, lng`,
    [userId, input.label ?? null, input.line1, input.line2 ?? null, input.city,
     input.district ?? null, input.state, input.pincode, input.lat, input.lng]
  );
  return result.rows[0];
}
