// OTP-based auth for Indian mobile numbers (the primary login method per
// spec §3 "Sign up/login using mobile number/email"). Email/password is
// supported as a secondary path for admin/web users.
//
// SMS delivery goes through smsAdapter.ts — the single place that decides
// whether a real provider is configured. In production with no provider
// configured, sendOtpSms throws SmsNotConfiguredError instead of silently
// "succeeding"; requestOtp lets that propagate so the caller (route layer)
// returns a real error rather than claiming an OTP was sent.

import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { db } from '../config/db';
import { UserRole } from '../types/enums';
import { sendOtpSms } from './smsAdapter';

const JWT_SECRET = process.env.JWT_SECRET as string;
const OTP_TTL_MINUTES = 10;

export class InvalidOtpError extends Error {
  constructor() { super('Invalid or expired OTP'); this.name = 'InvalidOtpError'; }
}

function normalizeIndianPhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 12 && digits.startsWith('91')) return `+${digits}`;
  if (phone.startsWith('+')) return phone;
  throw new Error('Enter a valid 10-digit Indian mobile number');
}

// In-memory OTP store for MVP. Swap for a `phone_otps` table or Redis with
// a TTL before going to production (multiple backend instances need a
// shared store, not process memory) — see README "Known limitations".
const otpStore = new Map<string, { hash: string; expiresAt: number }>();

export async function requestOtp(rawPhone: string): Promise<void> {
  const phone = normalizeIndianPhone(rawPhone);
  const otp = String(crypto.randomInt(100000, 999999));
  const hash = crypto.createHash('sha256').update(otp).digest('hex');
  otpStore.set(phone, { hash, expiresAt: Date.now() + OTP_TTL_MINUTES * 60_000 });

  // Throws SmsNotConfiguredError in production with no SMS provider set —
  // intentionally NOT caught here, so the route returns a real failure
  // rather than telling the user an OTP was sent when it wasn't.
  await sendOtpSms(phone, otp);
}

export async function verifyOtpAndLogin(rawPhone: string, submittedOtp: string, fullName?: string): Promise<{ token: string; userId: string; isNewUser: boolean }> {
  const phone = normalizeIndianPhone(rawPhone);
  const entry = otpStore.get(phone);
  if (!entry || entry.expiresAt < Date.now()) throw new InvalidOtpError();

  const submittedHash = crypto.createHash('sha256').update(submittedOtp).digest('hex');
  if (submittedHash !== entry.hash) throw new InvalidOtpError();
  otpStore.delete(phone); // single use

  const existing = await db.query('SELECT id, role FROM users WHERE phone = $1', [phone]);
  let userId: string;
  let role: UserRole;
  let isNewUser = false;

  if (existing.rows.length) {
    userId = existing.rows[0].id;
    role = existing.rows[0].role;
  } else {
    isNewUser = true;
    const insert = await db.query(
      `INSERT INTO users (phone, full_name, role) VALUES ($1, $2, 'customer') RETURNING id, role`,
      [phone, fullName ?? 'New user']
    );
    userId = insert.rows[0].id;
    role = insert.rows[0].role;
    await db.query('INSERT INTO customer_profiles (user_id) VALUES ($1)', [userId]);
  }

  const token = jwt.sign({ id: userId, role }, JWT_SECRET, { expiresIn: '30d' });
  return { token, userId, isNewUser };
}

// Secondary path for admin/web dashboard logins (email + password).
// ENVIRONMENT VARIABLE REQUIRED: JWT_SECRET (shared with OTP path above).
export async function loginWithPassword(email: string, password: string): Promise<{ token: string; userId: string; role: UserRole }> {
  const bcrypt = await import('bcryptjs');
  const result = await db.query('SELECT id, role, password_hash FROM users WHERE email = $1', [email]);
  if (!result.rows.length || !result.rows[0].password_hash) {
    throw new Error('Invalid email or password');
  }
  const { id, role, password_hash } = result.rows[0];
  const ok = await bcrypt.compare(password, password_hash);
  if (!ok) throw new Error('Invalid email or password');

  const token = jwt.sign({ id, role }, JWT_SECRET, { expiresIn: '7d' });
  return { token, userId: id, role };
}

// Lets an admin flip a user's ability to use Supplier Mode in the app —
// mirrors users.is_supplier_mode_enabled (spec §3: "if allowed by the admin").
export async function setSupplierModeEnabled(userId: string, enabled: boolean): Promise<void> {
  await db.query('UPDATE users SET is_supplier_mode_enabled = $1, updated_at = now() WHERE id = $2', [enabled, userId]);
}
