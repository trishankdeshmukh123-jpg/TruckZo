import express from 'express';
import { ordersRouter } from './routes/orders';
import { adminRouter } from './routes/admin';
import { authRouter } from './routes/auth';
import { suppliersRouter } from './routes/suppliers';
import { paymentsRouter } from './routes/payments';
import { catalogRouter } from './routes/catalog';
import { addressesRouter } from './routes/addresses';
import { trucksRouter } from './routes/trucks';
import { tenderRouter } from './routes/tender';
import { rfqRouter } from './routes/rfq';
import { tripsRouter } from './routes/trips';
import { disputesRouter } from './routes/disputes';
import { verificationRouter } from './routes/verification';
import { inventoryRouter } from './routes/inventory';
import { businessRouter } from './routes/business';
import { invoicesRouter } from './routes/invoices';
import { notificationsRouter } from './routes/notifications';
import { pricingRouter } from './routes/pricing';

const app = express();

// Webhook route needs the raw body for signature verification — mount it
// BEFORE express.json() so this path is exempted from JSON parsing.
app.use('/payments/webhook', express.raw({ type: 'application/json' }));
app.use(express.json());

app.get('/health', (_req, res) => res.json({ status: 'ok' }));
app.use('/auth', authRouter);
app.use('/orders', ordersRouter);
app.use('/admin', adminRouter);
app.use('/suppliers', suppliersRouter);
app.use('/payments', paymentsRouter);
app.use('/', catalogRouter);  // GET /categories, GET /materials, GET /materials/:id
app.use('/addresses', addressesRouter);
app.use('/trucks', trucksRouter);
app.use('/tender', tenderRouter);
app.use('/rfq', rfqRouter);
app.use('/', tripsRouter);    // POST/GET /orders/:orderId/trips, /orders/:orderId/pod, etc. (see routes/trips.ts)
app.use('/disputes', disputesRouter);
app.use('/verification', verificationRouter);
app.use('/inventory', inventoryRouter);
app.use('/business', businessRouter);
app.use('/invoices', invoicesRouter);
app.use('/notifications', notificationsRouter);
app.use('/pricing', pricingRouter);

const PORT = process.env.PORT ?? 4000;
app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`BuildTruck API listening on :${PORT}`);
});
