// JWT auth + role-based access control. Every protected route uses these.
// ENVIRONMENT VARIABLE REQUIRED: JWT_SECRET

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { UserRole } from '../types/enums';

export interface AuthedRequest extends Request {
  user?: { id: string; role: UserRole };
}

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  // eslint-disable-next-line no-console
  console.warn('[buildtruck] JWT_SECRET is not set — set it in your .env file.');
}

export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing bearer token' });
  }
  try {
    const payload = jwt.verify(header.slice(7), JWT_SECRET as string) as { id: string; role: UserRole };
    req.user = payload;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// A customer account that has registered a supplier profile uses Supplier
// Mode in the same app (one account, two modes), so its JWT role stays
// 'customer'. For routes that allow 'supplier', we therefore also accept
// any user who owns a supplier_profiles row.
export function requireRole(...roles: UserRole[]) {
  return async (req: AuthedRequest, res: Response, next: NextFunction) => {
    if (!req.user) return res.status(403).json({ error: 'Forbidden for this role' });
    if (roles.includes(req.user.role)) return next();
    if (roles.includes('supplier')) {
      try {
        const { db } = await import('../config/db');
        const r = await db.query('SELECT 1 FROM supplier_profiles WHERE user_id = $1', [req.user.id]);
        if (r.rows.length) return next();
      } catch { /* fall through to 403 */ }
    }
    return res.status(403).json({ error: 'Forbidden for this role' });
  };
}
