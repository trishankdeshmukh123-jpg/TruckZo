// Central enums — must stay in sync with db/schema.sql's Postgres ENUM types.

export type UserRole = 'customer' | 'supplier' | 'admin';

export type OrderStatus =
  | 'PENDING' | 'ACCEPTED' | 'TRUCK_ASSIGNED' | 'PICKUP_STARTED'
  | 'OUT_FOR_DELIVERY' | 'ARRIVING' | 'DELIVERED' | 'COMPLETED'
  | 'CANCELLED' | 'REFUNDED';

export type PaymentMethod = 'UPI' | 'CASH';
export type PaymentStatus = 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED' | 'PARTIALLY_REFUNDED';
export type CommissionStatus = 'PAYABLE' | 'SETTLED' | 'WAIVED';

// Legal next states for each order status. Enforced in orderService — the
// client can only ever *request* a transition, never dictate it.
export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  PENDING: ['ACCEPTED', 'CANCELLED'],
  ACCEPTED: ['TRUCK_ASSIGNED', 'CANCELLED'],
  TRUCK_ASSIGNED: ['PICKUP_STARTED', 'CANCELLED'],
  PICKUP_STARTED: ['OUT_FOR_DELIVERY'],
  OUT_FOR_DELIVERY: ['ARRIVING'],
  ARRIVING: ['DELIVERED'],
  DELIVERED: ['COMPLETED'],
  COMPLETED: ['REFUNDED'],
  CANCELLED: [],
  REFUNDED: [],
};

// Once a delivery has actually started, cancellation is no longer allowed
// from the app — it has to go through support/admin.
export const CANCELLABLE_STATUSES: OrderStatus[] = ['PENDING', 'ACCEPTED'];

// Order is "active" (truck should be pinging live location) in this window.
export const ACTIVE_DELIVERY_STATUSES: OrderStatus[] = [
  'PICKUP_STARTED', 'OUT_FOR_DELIVERY', 'ARRIVING',
];

// Vehicle category and capacity bracket — fixed option sets shared by
// trucks and tender_trucks (see db/schema.sql CHECK constraints). Kept as
// plain arrays (not a DB enum) so admin can extend the list later without
// an ALTER TYPE migration.
export const VEHICLE_CATEGORIES = [
  '6_wheeler', '10_wheeler', '12_wheeler', '16_wheeler', '18_wheeler',
  'tractor', 'tractor_trolley', 'pickup', 'mini_truck', 'other',
] as const;
export type VehicleCategory = typeof VEHICLE_CATEGORIES[number];

export const CAPACITY_BRACKETS = [
  '1_ton', '2_ton', '3_ton', '5_ton', '7_ton', '10_ton', '15_ton', '20_ton', '25_ton_plus',
] as const;
export type CapacityBracket = typeof CAPACITY_BRACKETS[number];

export type ServiceRequestType = 'TRUCK_HIRE' | 'TENDER_MATERIAL' | 'TENDER_TRUCK';
export type ServiceRequestStatus = 'OPEN' | 'CONTACTED' | 'CLOSED';

// ---- RFQ / Quotation ----
export type RfqStatus = 'DRAFT' | 'OPEN' | 'QUOTED' | 'SHORTLISTED' | 'AWARDED' | 'EXPIRED' | 'CANCELLED' | 'COMPLETED';
export type QuoteStatus = 'SUBMITTED' | 'SHORTLISTED' | 'AWARDED' | 'REJECTED' | 'WITHDRAWN';

// ---- Multi-truck orders ----
export type TripStatus = 'PENDING' | 'ASSIGNED' | 'PICKED_UP' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED';

// ---- Disputes ----
export type DisputeIssueType =
  | 'WRONG_MATERIAL' | 'SHORT_QUANTITY' | 'DAMAGED_MATERIAL' | 'QUALITY_ISSUE'
  | 'LATE_DELIVERY' | 'TRUCK_NO_SHOW' | 'INCORRECT_CHARGES' | 'OTHER';
export type DisputeStatus = 'OPEN' | 'UNDER_REVIEW' | 'WAITING_FOR_INFORMATION' | 'RESOLVED' | 'REJECTED' | 'CLOSED';

// ---- Verification ----
export type VerificationOwnerType = 'SUPPLIER' | 'TRUCK';
export type DocumentVerificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED' | 'EXPIRED';

// ---- Business accounts ----
export type BusinessRole = 'OWNER' | 'ADMIN' | 'MANAGER' | 'STAFF' | 'VIEWER';
