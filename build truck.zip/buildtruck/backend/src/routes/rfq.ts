import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import {
  createRfq, listMyRfqs, listOpenRfqsForSuppliers, getRfq,
  submitQuote, listQuotesForRfq, shortlistQuote, awardRfq,
} from '../services/rfqService';

export const rfqRouter = Router();

rfqRouter.post('/', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const rfq = await createRfq(req.user!.id, req.body);
    res.status(201).json(rfq);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

rfqRouter.get('/mine', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listMyRfqs(req.user!.id) });
});

// Supplier discovery feed.
rfqRouter.get('/open', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listOpenRfqsForSuppliers(req.query.material as string | undefined) });
});

rfqRouter.get('/:id', requireAuth, async (req: AuthedRequest, res: Response) => {
  const rfq = await getRfq(req.params.id);
  if (!rfq) return res.status(404).json({ error: 'RFQ not found' });
  res.json(rfq);
});

rfqRouter.post('/:id/quotes', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  try {
    const quote = await submitQuote(req.params.id, req.body.supplierId, req.body);
    res.status(201).json(quote);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

rfqRouter.get('/:id/quotes', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listQuotesForRfq(req.params.id) });
});

rfqRouter.post('/:id/quotes/:quoteId/shortlist', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await shortlistQuote(req.params.id, req.params.quoteId);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

rfqRouter.post('/:id/quotes/:quoteId/award', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await awardRfq(req.params.id, req.params.quoteId);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});
