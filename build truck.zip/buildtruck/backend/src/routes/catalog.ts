import { Router, Request, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import { listCategories, listMaterials, getMaterial, getCategorySpecFields, createCategorySpecField } from '../services/catalogService';

export const catalogRouter = Router();

catalogRouter.get('/categories', async (_req: Request, res: Response) => {
  res.json({ results: await listCategories() });
});

catalogRouter.get('/materials', async (req: Request, res: Response) => {
  const categoryId = req.query.categoryId ? String(req.query.categoryId) : undefined;
  res.json({ results: await listMaterials(categoryId) });
});

catalogRouter.get('/materials/:id', async (req: Request, res: Response) => {
  const material = await getMaterial(req.params.id);
  if (!material) return res.status(404).json({ error: 'Material not found' });
  res.json(material);
});

// Category-configurable spec fields (e.g. Gitti -> "Size": 10mm/20mm/40mm).
catalogRouter.get('/categories/:id/spec-fields', async (req: Request, res: Response) => {
  res.json({ results: await getCategorySpecFields(req.params.id) });
});

// Admin: define which spec fields apply to a category.
catalogRouter.post('/categories/:id/spec-fields', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  try {
    const field = await createCategorySpecField(req.params.id, req.body.fieldName, req.body.fieldType, req.body.options, req.body.isRequired);
    res.status(201).json(field);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});
