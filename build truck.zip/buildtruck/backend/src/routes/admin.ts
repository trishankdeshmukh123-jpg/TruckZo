// Admin-only routes for the configurable pricing/commission system.
// Everything here writes to admin_settings — never to code.

import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import { updateSetting, getPricingSettings, getCommissionSettings } from '../config/settingsRepository';
import { verifyTenderMaterial, verifyTenderTruck, listAllTenderMaterials, listAllTenderTrucks } from '../services/tenderService';
import { getAdvancedPricingFactors } from '../config/settingsRepository';
import { expireOldRfqs } from '../services/rfqService';
import { expireDocumentsAndNotify } from '../services/verificationService';
import { db } from '../config/db';

export const adminRouter = Router();

adminRouter.get('/settings/pricing', requireAuth, requireRole('admin'), async (_req, res: Response) => {
  res.json(await getPricingSettings());
});

adminRouter.get('/settings/commission', requireAuth, requireRole('admin'), async (_req, res: Response) => {
  res.json(await getCommissionSettings());
});

// Body: { key: "commission_percent", value: 6 }
adminRouter.post('/settings', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  try {
    await updateSetting(req.body.key, req.body.value, req.user!.id);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---- Trucks (read-only admin listing across all suppliers) ----
adminRouter.get('/trucks', requireAuth, requireRole('admin'), async (_req, res: Response) => {
  const result = await db.query(
    `SELECT t.*, sp.business_name AS supplier_name FROM trucks t
     JOIN supplier_profiles sp ON sp.id = t.supplier_id ORDER BY t.created_at DESC`
  );
  res.json({ results: result.rows });
});

// ---- Government Tender: admin verify + list ----
adminRouter.get('/tender/materials', requireAuth, requireRole('admin'), async (_req, res: Response) => {
  res.json({ results: await listAllTenderMaterials() });
});
adminRouter.post('/tender/materials/:id/verify', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  await verifyTenderMaterial(req.params.id, req.body.status);
  res.json({ ok: true });
});
adminRouter.get('/tender/trucks', requireAuth, requireRole('admin'), async (_req, res: Response) => {
  res.json({ results: await listAllTenderTrucks() });
});
adminRouter.post('/tender/trucks/:id/verify', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  await verifyTenderTruck(req.params.id, req.body.status);
  res.json({ ok: true });
});

// ---- Advanced delivery pricing: factors + per-vehicle-category multipliers ----
adminRouter.get('/settings/advanced-pricing', requireAuth, requireRole('admin'), async (_req, res: Response) => {
  const factors = await getAdvancedPricingFactors();
  const multipliers = await db.query('SELECT vehicle_category, multiplier FROM vehicle_rate_multipliers ORDER BY vehicle_category');
  res.json({ factors, multipliers: multipliers.rows });
});
adminRouter.post('/settings/vehicle-multiplier', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  await db.query(
    `INSERT INTO vehicle_rate_multipliers (vehicle_category, multiplier) VALUES ($1,$2)
     ON CONFLICT (vehicle_category) DO UPDATE SET multiplier = $2`,
    [req.body.vehicleCategory, req.body.multiplier]
  );
  res.json({ ok: true });
});

// ---- Maintenance jobs (no scheduler infra yet — trigger manually or via
// an external cron hitting these endpoints; see README "Scheduled jobs") ----
adminRouter.post('/maintenance/expire-rfqs', requireAuth, requireRole('admin'), async (_req, res: Response) => {
  await expireOldRfqs();
  res.json({ ok: true });
});
adminRouter.post('/maintenance/expire-documents', requireAuth, requireRole('admin'), async (_req, res: Response) => {
  await expireDocumentsAndNotify();
  res.json({ ok: true });
});

// ---- Admin list views for the new modules (read-only; actions live on the
// module's own routes: disputes status, verification decide, etc.) ----
const ADMIN_LISTS: Record<string, string> = {
  rfqs: `SELECT r.*, u.full_name AS customer_name FROM rfqs r JOIN users u ON u.id = r.customer_id ORDER BY r.created_at DESC LIMIT 200`,
  quotes: `SELECT q.*, sp.business_name, r.material_name FROM rfq_quotes q JOIN supplier_profiles sp ON sp.id = q.supplier_id JOIN rfqs r ON r.id = q.rfq_id ORDER BY q.created_at DESC LIMIT 200`,
  businesses: `SELECT b.*, u.full_name AS owner_name FROM businesses b JOIN users u ON u.id = b.owner_user_id ORDER BY b.created_at DESC LIMIT 200`,
  projects: `SELECT p.*, b.name AS business_name FROM projects p JOIN businesses b ON b.id = p.business_id ORDER BY p.created_at DESC LIMIT 200`,
  trips: `SELECT t.*, o.order_number FROM order_trips t JOIN orders o ON o.id = t.order_id ORDER BY t.created_at DESC LIMIT 200`,
  pods: `SELECT p.*, o.order_number FROM proof_of_deliveries p JOIN orders o ON o.id = p.order_id ORDER BY p.delivered_at DESC LIMIT 200`,
  invoices: `SELECT i.*, o.order_number FROM invoices i JOIN orders o ON o.id = i.order_id ORDER BY i.generated_at DESC LIMIT 200`,
  inventory: `SELECT sm.id, sm.available_quantity, sm.reserved_quantity, sm.sold_quantity, sm.low_stock_threshold, m.name AS material_name, sp.business_name FROM supplier_materials sm JOIN materials m ON m.id = sm.material_id JOIN supplier_profiles sp ON sp.id = sm.supplier_id ORDER BY sp.business_name LIMIT 500`,
  notifications: `SELECT n.*, u.full_name FROM notifications n JOIN users u ON u.id = n.user_id ORDER BY n.created_at DESC LIMIT 200`,
  orders: `SELECT o.*, sp.business_name AS supplier_name, u.full_name AS customer_name FROM orders o JOIN supplier_profiles sp ON sp.id = o.supplier_id JOIN users u ON u.id = o.customer_id ORDER BY o.created_at DESC LIMIT 200`,
};
adminRouter.get('/list/:name', requireAuth, requireRole('admin'), async (req, res: Response) => {
  const sql = ADMIN_LISTS[req.params.name];
  if (!sql) return res.status(404).json({ error: 'Unknown list' });
  const result = await db.query(sql);
  res.json({ results: result.rows });
});
