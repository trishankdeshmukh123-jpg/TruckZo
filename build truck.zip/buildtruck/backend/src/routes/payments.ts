// Razorpay (or any provider) webhook endpoint. This is how PENDING UPI
// payments become SUCCESS/FAILED server-side — never trust the client's
// word that a payment succeeded, only a verified webhook or a server-side
// status fetch from the provider.

import { Router, Request, Response } from 'express';
import { db } from '../config/db';
import { paymentProvider } from '../services/paymentService';
import { notify } from '../services/notificationService';

export const paymentsRouter = Router();

// IMPORTANT: this route needs the raw request body (not JSON-parsed) to
// verify the HMAC signature — mount it with express.raw({ type: 'application/json' })
// ahead of express.json() in index.ts for this specific path.
paymentsRouter.post('/webhook', async (req: Request, res: Response) => {
  const signature = req.headers['x-razorpay-signature'] as string;
  const rawBody = req.body.toString();

  if (!paymentProvider.verifyWebhook(rawBody, signature)) {
    return res.status(400).json({ error: 'Invalid webhook signature' });
  }

  const event = JSON.parse(rawBody);
  const providerPaymentId = event.payload?.payment?.entity?.id;
  const status = event.event === 'payment.captured' ? 'SUCCESS' : 'FAILED';

  if (providerPaymentId) {
    const updated = await db.query(
      `UPDATE payments SET status = $1, provider_payload = $2, updated_at = now()
       WHERE provider_payment_id = $3 RETURNING order_id`,
      [status, JSON.stringify(event), providerPaymentId]
    );
    if (updated.rows.length) {
      const order = await db.query('SELECT customer_id FROM orders WHERE id = $1', [updated.rows[0].order_id]);
      if (order.rows.length) {
        await notify(
          order.rows[0].customer_id,
          status === 'SUCCESS' ? 'payment_received' : 'payment_failed',
          status === 'SUCCESS' ? 'Payment received' : 'Payment failed',
          status === 'SUCCESS' ? 'Your payment was received successfully.' : 'Your payment could not be processed — please retry.',
          { orderId: updated.rows[0].order_id }
        );
      }
    }
  }

  res.json({ ok: true });
});
