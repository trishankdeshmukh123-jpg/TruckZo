import { Router, Response } from 'express';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { listAddresses, createAddress } from '../services/addressService';

export const addressesRouter = Router();

addressesRouter.get('/', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listAddresses(req.user!.id) });
});

addressesRouter.post('/', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const address = await createAddress(req.user!.id, req.body);
    res.status(201).json(address);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});
