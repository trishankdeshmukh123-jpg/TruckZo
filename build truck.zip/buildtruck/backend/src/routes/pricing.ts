import { Router, Response } from 'express';
import { requireAuth } from '../middleware/auth';
import { calculateAdvancedDeliveryCharge } from '../services/pricingService';

export const pricingRouter = Router();

// Used by supplier RFQ-quote and multi-truck screens to preview a delivery
// charge with the full configurable factor set — still just a preview;
// whatever the supplier actually submits as their quote/trip cost is what's stored.
pricingRouter.post('/advanced-quote', requireAuth, async (req, res: Response) => {
  try {
    const result = await calculateAdvancedDeliveryCharge(req.body);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});
