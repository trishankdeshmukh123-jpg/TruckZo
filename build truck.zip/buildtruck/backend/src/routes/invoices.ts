import { Router, Response } from 'express';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { getInvoiceForOrder, listInvoicesForBusiness } from '../services/invoiceService';

export const invoicesRouter = Router();

invoicesRouter.get('/order/:orderId', requireAuth, async (req: AuthedRequest, res: Response) => {
  const invoice = await getInvoiceForOrder(req.params.orderId);
  if (!invoice) return res.status(404).json({ error: 'Invoice not yet generated — order may not be completed.' });
  res.json(invoice);
});

invoicesRouter.get('/business/:businessId', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listInvoicesForBusiness(req.params.businessId) });
});
