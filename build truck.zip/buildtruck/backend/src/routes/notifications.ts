import { Router, Response } from 'express';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { listForUser, markRead, markAllRead } from '../services/notificationService';

export const notificationsRouter = Router();

notificationsRouter.get('/', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listForUser(req.user!.id, req.query.unreadOnly === 'true') });
});
notificationsRouter.post('/:id/read', requireAuth, async (req: AuthedRequest, res: Response) => {
  await markRead(req.user!.id, req.params.id);
  res.json({ ok: true });
});
notificationsRouter.post('/read-all', requireAuth, async (req: AuthedRequest, res: Response) => {
  await markAllRead(req.user!.id);
  res.json({ ok: true });
});
