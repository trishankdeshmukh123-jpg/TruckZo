// Government Tender module routes. Every response here should be paired,
// on the client, with the disclaimer that BuildTruck is a coordination
// platform only — not a government portal, and it does not award tenders.

import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import {
  createTenderMaterial, searchTenderMaterials,
  createTenderTruck, searchTenderTrucks,
} from '../services/tenderService';
import { createServiceRequest } from '../services/serviceRequestService';

export const tenderRouter = Router();

// Materials
tenderRouter.post('/materials', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  try {
    const result = await createTenderMaterial(req.body.supplierId, req.body);
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

tenderRouter.get('/materials/search', requireAuth, async (req: AuthedRequest, res: Response) => {
  const results = await searchTenderMaterials({
    categoryId: req.query.categoryId as string | undefined,
    location: req.query.location as string | undefined,
    onlyAvailable: req.query.onlyAvailable === 'true',
  });
  res.json({ results });
});

tenderRouter.post('/materials/:id/requests', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const request = await createServiceRequest({
      requestType: 'TENDER_MATERIAL', requesterId: req.user!.id, targetId: req.params.id,
      quantity: req.body.quantity, message: req.body.message, contactPhone: req.body.contactPhone,
    });
    res.status(201).json(request);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// Trucks
tenderRouter.post('/trucks', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  try {
    const result = await createTenderTruck(req.body.supplierId, req.body);
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

tenderRouter.get('/trucks/search', requireAuth, async (req: AuthedRequest, res: Response) => {
  const results = await searchTenderTrucks({
    vehicleCategory: req.query.category as any,
    capacityBracket: req.query.capacity as any,
    onlyAvailable: req.query.onlyAvailable === 'true',
  });
  res.json({ results });
});

tenderRouter.post('/trucks/:id/requests', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const request = await createServiceRequest({
      requestType: 'TENDER_TRUCK', requesterId: req.user!.id, targetId: req.params.id,
      quantity: req.body.quantity, message: req.body.message, contactPhone: req.body.contactPhone,
    });
    res.status(201).json(request);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});
