// Signup/login endpoints. Customer signup is just "verify OTP" (a phone
// number becomes an account automatically — see authService.verifyOtpAndLogin).
// Supplier signup is a second step for an already-authenticated user: it
// attaches a supplier_profiles row and starts PENDING verification.

import { Router, Response } from 'express';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { requestOtp, verifyOtpAndLogin, loginWithPassword } from '../services/authService';
import { registerSupplier } from '../services/supplierService';
import { SmsNotConfiguredError } from '../services/smsAdapter';

export const authRouter = Router();

// Step 1: customer enters phone -> receives OTP (via SMS once
// SMS_PROVIDER_API_KEY is set; logged server-side in non-production dev
// only — see smsAdapter.ts). In production with no SMS provider configured,
// this returns 503, not a fake "OTP sent" success.
authRouter.post('/otp/request', async (req, res: Response) => {
  try {
    await requestOtp(req.body.phone);
    res.json({ ok: true, message: 'OTP sent' });
  } catch (err) {
    if (err instanceof SmsNotConfiguredError) {
      return res.status(503).json({ error: err.message });
    }
    res.status(400).json({ error: (err as Error).message });
  }
});

// Step 2: customer submits the OTP -> gets a JWT. Creates the user row on
// first login, so this doubles as signup.
authRouter.post('/otp/verify', async (req, res: Response) => {
  try {
    const { phone, otp, fullName } = req.body;
    const result = await verifyOtpAndLogin(phone, otp, fullName);
    res.json(result);
  } catch (err) {
    res.status(401).json({ error: (err as Error).message });
  }
});

// Admin/web dashboard login (email + password).
authRouter.post('/login', async (req, res: Response) => {
  try {
    const { email, password } = req.body;
    const result = await loginWithPassword(email, password);
    res.json(result);
  } catch (err) {
    res.status(401).json({ error: (err as Error).message });
  }
});

// Step 3 (optional): an already-logged-in customer registers as a
// supplier — this is the "one app, Supplier Mode" upgrade path, not a
// separate signup flow. Starts PENDING verification (see supplierService).
authRouter.post('/register-supplier', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const supplier = await registerSupplier(req.user!.id, req.body);
    res.status(201).json(supplier);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});
