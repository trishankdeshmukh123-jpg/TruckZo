import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import { listInventoryForSupplier, updateInventorySettings } from '../services/inventoryService';

export const inventoryRouter = Router();

inventoryRouter.get('/:supplierId', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listInventoryForSupplier(req.params.supplierId) });
});

inventoryRouter.post('/:supplierMaterialId/settings', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  try {
    await updateInventorySettings(req.params.supplierMaterialId, req.body.lowStockThreshold, req.body.expectedRestockDate);
    res.json({ ok: true });
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});
