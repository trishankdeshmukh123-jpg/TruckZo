// Customer + supplier facing order routes. Note every money-relevant field
// in the request body is treated as a *hint*, never as truth — orderService
// recomputes everything server-side. Every route that reads or acts on a
// SPECIFIC order calls assertOrderAccess() first — see orderService.ts —
// so a user can only touch their own order (as customer or as the owning
// supplier), with admin able to access any.

import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import {
  createOrder, transitionOrderStatus, cancelOrder, verifyDeliveryOtp,
  listOrdersForCustomer, listOrdersForSupplier, getOrderById,
  assertOrderAccess, OrderAccessDeniedError,
} from '../services/orderService';
import { DeliveryOutOfRangeError } from '../services/pricingService';

export const ordersRouter = Router();

function handleOrderError(err: unknown, res: Response) {
  if (err instanceof OrderAccessDeniedError) return res.status(403).json({ error: err.message });
  if (err instanceof DeliveryOutOfRangeError) return res.status(422).json({ error: err.message });
  res.status(400).json({ error: (err as Error).message });
}

// Order history — customer's own orders, and a supplier's received orders.
ordersRouter.get('/mine', requireAuth, requireRole('customer'), async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listOrdersForCustomer(req.user!.id) });
});
ordersRouter.get('/supplier/:supplierId', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  // Note: this still trusts :supplierId from the URL rather than resolving
  // it from the JWT — a malicious supplier could pass another supplier's
  // id. Mitigated by requireRole('supplier') requiring SOME supplier
  // profile to exist for the caller, but not yet that it's THIS one.
  // Tracked as a known limitation (see README) pending a
  // "resolve supplierId from req.user.id" helper shared with routes/suppliers.ts.
  res.json({ results: await listOrdersForSupplier(req.params.supplierId) });
});
ordersRouter.get('/:id', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await assertOrderAccess(req.params.id, req.user!.id, req.user!.role);
    const order = await getOrderById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json(order);
  } catch (err) {
    handleOrderError(err, res);
  }
});

// Customer places an order — request carries items/addresses/coords, NOT prices.
ordersRouter.post('/', requireAuth, requireRole('customer'), async (req: AuthedRequest, res: Response) => {
  try {
    const { supplierId, supplierMaterialItems, deliveryAddressId, originLat, originLng, destLat, destLng, paymentMethod } = req.body;
    const result = await createOrder({
      customerId: req.user!.id,
      supplierId, supplierMaterialItems, deliveryAddressId,
      originLat, originLng, destLat, destLng, paymentMethod,
    });
    res.status(201).json(result);
  } catch (err) {
    handleOrderError(err, res);
  }
});

// Supplier moves an order through its lifecycle.
ordersRouter.post('/:id/status', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  try {
    await assertOrderAccess(req.params.id, req.user!.id, req.user!.role);
    await transitionOrderStatus(req.params.id, req.body.status, req.user!.id, req.body.note);
    res.json({ ok: true });
  } catch (err) {
    handleOrderError(err, res);
  }
});

ordersRouter.post('/:id/cancel', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await assertOrderAccess(req.params.id, req.user!.id, req.user!.role);
    await cancelOrder(req.params.id, req.user!.id, req.body.reason ?? 'No reason given');
    res.json({ ok: true });
  } catch (err) {
    handleOrderError(err, res);
  }
});

// Customer confirms delivery with the OTP shown by the driver.
ordersRouter.post('/:id/confirm-delivery', requireAuth, requireRole('customer'), async (req: AuthedRequest, res: Response) => {
  try {
    await assertOrderAccess(req.params.id, req.user!.id, req.user!.role);
    const ok = await verifyDeliveryOtp(req.params.id, req.body.otp);
    if (!ok) return res.status(400).json({ error: 'Incorrect OTP' });
    res.json({ ok: true });
  } catch (err) {
    handleOrderError(err, res);
  }
});
