import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import {
  createDispute, listDisputesForUser, listAllDisputes, getDispute,
  updateDisputeStatus, getDisputeHistory, assertDisputeAccess, DisputeAccessDeniedError,
} from '../services/disputeService';
import { OrderAccessDeniedError } from '../services/orderService';

export const disputesRouter = Router();

function handleError(err: unknown, res: Response) {
  if (err instanceof DisputeAccessDeniedError || err instanceof OrderAccessDeniedError) {
    return res.status(403).json({ error: err.message });
  }
  res.status(400).json({ error: (err as Error).message });
}

disputesRouter.post('/', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const dispute = await createDispute(req.user!.id, req.user!.role, req.body);
    res.status(201).json(dispute);
  } catch (err) { handleError(err, res); }
});

disputesRouter.get('/mine', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listDisputesForUser(req.user!.id) });
});

disputesRouter.get('/', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listAllDisputes(req.query.status as any) });
});

disputesRouter.get('/:id', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await assertDisputeAccess(req.params.id, req.user!.id, req.user!.role);
    const dispute = await getDispute(req.params.id);
    if (!dispute) return res.status(404).json({ error: 'Dispute not found' });
    res.json(dispute);
  } catch (err) { handleError(err, res); }
});

disputesRouter.get('/:id/history', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  res.json({ results: await getDisputeHistory(req.params.id) });
});

disputesRouter.post('/:id/status', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  try {
    await updateDisputeStatus(req.params.id, req.body.status, req.user!.id, req.body.note, req.body.resolution);
    res.json({ ok: true });
  } catch (err) { handleError(err, res); }
});
