// Mounted at /orders/:orderId/trips and /orders/:orderId/pod — kept in the
// same file since both operate on an existing order and share auth checks.

import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import { createTrip, assignTruckToTrip, updateTripStatus, getOrderProgress, markOrderMultiTruck } from '../services/tripService';
import { createPod, getPodsForOrder } from '../services/podService';

export const tripsRouter = Router({ mergeParams: true });

tripsRouter.post('/orders/:orderId/multi-truck', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  try {
    await markOrderMultiTruck(req.params.orderId, req.body.totalQuantity);
    res.json({ ok: true });
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});

tripsRouter.post('/orders/:orderId/trips', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  try {
    const trip = await createTrip(req.params.orderId, req.body.tripNumber, req.body.loadQuantity);
    res.status(201).json(trip);
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});

tripsRouter.post('/trips/:tripId/assign', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  try {
    await assignTruckToTrip(req.params.tripId, req.body.truckId, req.body.driverName, req.body.driverPhone);
    res.json({ ok: true });
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});

tripsRouter.post('/trips/:tripId/status', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  try {
    await updateTripStatus(req.params.tripId, req.body.status);
    res.json({ ok: true });
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});

tripsRouter.get('/orders/:orderId/progress', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json(await getOrderProgress(req.params.orderId));
});

tripsRouter.post('/orders/:orderId/pod', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  try {
    const pod = await createPod({ orderId: req.params.orderId, ...req.body });
    res.status(201).json(pod);
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});

tripsRouter.get('/orders/:orderId/pod', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await getPodsForOrder(req.params.orderId) });
});
