import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import { createTruck, listSupplierTrucks, searchTrucks } from '../services/truckService';
import { createServiceRequest, listRequestsForTarget } from '../services/serviceRequestService';

export const trucksRouter = Router();

// Customer-facing search/filter.
trucksRouter.get('/search', requireAuth, async (req: AuthedRequest, res: Response) => {
  const q = req.query;
  const results = await searchTrucks({
    vehicleCategory: q.category as any,
    capacityBracket: q.capacity as any,
    lat: q.lat ? Number(q.lat) : undefined,
    lng: q.lng ? Number(q.lng) : undefined,
    maxDistanceKm: q.maxDistanceKm ? Number(q.maxDistanceKm) : undefined,
    onlyAvailable: q.onlyAvailable === 'true',
    maxRatePerTrip: q.maxRatePerTrip ? Number(q.maxRatePerTrip) : undefined,
    maxRatePerKm: q.maxRatePerKm ? Number(q.maxRatePerKm) : undefined,
  });
  res.json({ results });
});

// Supplier: create a truck listing.
trucksRouter.post('/', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  try {
    // req.user!.id is the user id — resolving to supplier_profiles.id is
    // done by the caller in a real deployment (join on user_id); simplified
    // here to accept supplierId directly in body until a
    // "get my supplier profile" endpoint exists.
    const truck = await createTruck(req.body.supplierId, req.body);
    res.status(201).json(truck);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

trucksRouter.get('/mine/:supplierId', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listSupplierTrucks(req.params.supplierId) });
});

// Customer sends a hire request for a specific truck.
trucksRouter.post('/:id/requests', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const request = await createServiceRequest({
      requestType: 'TRUCK_HIRE', requesterId: req.user!.id, targetId: req.params.id,
      quantity: req.body.quantity, message: req.body.message, contactPhone: req.body.contactPhone,
    });
    res.status(201).json(request);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

trucksRouter.get('/:id/requests', requireAuth, requireRole('supplier', 'admin'), async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listRequestsForTarget('TRUCK_HIRE', req.params.id) });
});
