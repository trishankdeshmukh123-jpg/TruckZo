import { Router, Response } from 'express';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import {
  createBusiness, listMyBusinesses, addMember, listMembers,
  createProject, listProjects, getProjectDashboard, getProjectBusinessId,
  assertBusinessAccess, BusinessAccessDeniedError,
} from '../services/businessService';

export const businessRouter = Router();

function handleError(err: unknown, res: Response) {
  if (err instanceof BusinessAccessDeniedError) return res.status(403).json({ error: err.message });
  res.status(400).json({ error: (err as Error).message });
}

businessRouter.post('/', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const business = await createBusiness(req.user!.id, req.body.name, req.body.gstin, req.body.address);
    res.status(201).json(business);
  } catch (err) { handleError(err, res); }
});

businessRouter.get('/mine', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listMyBusinesses(req.user!.id) });
});

// Adding a member requires OWNER/ADMIN/MANAGER on the business (not just
// any member) — previously any logged-in user could add themselves or
// anyone else to any business.
businessRouter.post('/:id/members', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await assertBusinessAccess(req.params.id, req.user!.id, req.user!.role, 'MANAGER');
    await addMember(req.params.id, req.body.userId, req.body.role);
    res.json({ ok: true });
  } catch (err) { handleError(err, res); }
});

businessRouter.get('/:id/members', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await assertBusinessAccess(req.params.id, req.user!.id, req.user!.role);
    res.json({ results: await listMembers(req.params.id) });
  } catch (err) { handleError(err, res); }
});

businessRouter.post('/:id/projects', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await assertBusinessAccess(req.params.id, req.user!.id, req.user!.role, 'MANAGER');
    const project = await createProject(req.params.id, req.body);
    res.status(201).json(project);
  } catch (err) { handleError(err, res); }
});

businessRouter.get('/:id/projects', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    await assertBusinessAccess(req.params.id, req.user!.id, req.user!.role);
    res.json({ results: await listProjects(req.params.id) });
  } catch (err) { handleError(err, res); }
});

businessRouter.get('/projects/:projectId/dashboard', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const businessId = await getProjectBusinessId(req.params.projectId);
    if (!businessId) return res.status(404).json({ error: 'Project not found' });
    await assertBusinessAccess(businessId, req.user!.id, req.user!.role);
    res.json(await getProjectDashboard(req.params.projectId));
  } catch (err) { handleError(err, res); }
});
