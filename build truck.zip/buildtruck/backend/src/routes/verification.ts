import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import { uploadDocument, listDocumentsForOwner, listAllDocuments, decideDocument } from '../services/verificationService';

export const verificationRouter = Router();

verificationRouter.post('/documents', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const doc = await uploadDocument(req.body.ownerType, req.body.ownerId, req.body.docType, req.body.fileUrl, req.body.expiryDate);
    res.status(201).json(doc);
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});

verificationRouter.get('/documents/:ownerType/:ownerId', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listDocumentsForOwner(req.params.ownerType as any, req.params.ownerId) });
});

verificationRouter.get('/documents', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listAllDocuments(req.query.status as any) });
});

verificationRouter.post('/documents/:id/decide', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  try {
    const result = await decideDocument(req.params.id, req.body.status, req.user!.id);
    res.json(result);
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});
