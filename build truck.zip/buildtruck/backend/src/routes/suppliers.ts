// Public-ish supplier discovery route (requires auth, any role) + the
// nearby-search the mobile Supplier Selection screen needs.

import { Router, Response } from 'express';
import { AuthedRequest, requireAuth, requireRole } from '../middleware/auth';
import { findNearbySuppliersForMaterial, setVerificationStatus, getMySupplierProfile,
  createSupplierMaterial, listSupplierOwnMaterials, updateSupplierMaterial } from '../services/supplierService';

export const suppliersRouter = Router();

// The logged-in user's own supplier profile — resolves the real supplierId
// for every "add material/truck/tender listing" screen (no hardcoded id).
suppliersRouter.get('/mine', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  const profile = await getMySupplierProfile(req.user!.id);
  if (!profile) return res.status(404).json({ error: 'No supplier profile for this account yet — register as a supplier first.' });
  res.json(profile);
});

// Supplier's own material listings — the endpoint SupplierMaterialEditScreen
// was previously missing (it only showed a local "Saved" alert).
suppliersRouter.post('/materials', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  try {
    const result = await createSupplierMaterial(req.body.supplierId, req.body);
    res.status(201).json(result);
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});
suppliersRouter.get('/:supplierId/materials', requireAuth, async (req: AuthedRequest, res: Response) => {
  res.json({ results: await listSupplierOwnMaterials(req.params.supplierId) });
});
suppliersRouter.put('/materials/:id', requireAuth, requireRole('supplier'), async (req: AuthedRequest, res: Response) => {
  try {
    await updateSupplierMaterial(req.params.id, req.body);
    res.json({ ok: true });
  } catch (err) { res.status(400).json({ error: (err as Error).message }); }
});

// GET /suppliers/near?materialId=...&lat=...&lng=...
suppliersRouter.get('/near', requireAuth, async (req: AuthedRequest, res: Response) => {
  try {
    const { materialId, lat, lng } = req.query;
    if (!materialId || !lat || !lng) {
      return res.status(400).json({ error: 'materialId, lat and lng are required' });
    }
    const results = await findNearbySuppliersForMaterial(
      String(materialId), Number(lat), Number(lng)
    );
    res.json({ results });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// Admin-only: approve/reject/suspend a supplier's verification.
suppliersRouter.post('/:id/verify', requireAuth, requireRole('admin'), async (req: AuthedRequest, res: Response) => {
  try {
    await setVerificationStatus(req.params.id, req.body.status, req.body.notes);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});
