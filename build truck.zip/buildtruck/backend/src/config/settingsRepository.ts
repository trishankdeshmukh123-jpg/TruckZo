// Reads admin-configurable values from the `admin_settings` table.
// NOTHING in pricingService/commissionService is allowed to hard-code a
// number — everything financial comes through here, so the admin panel
// can change behavior without a code deploy.
//
// This file is a thin repository over Postgres. Swap `db` for your actual
// query client (pg, Prisma, Drizzle...) — the interface below is what the
// rest of the app depends on.

import { db } from './db'; // your Postgres client — see db.ts stub below

export interface PricingSettings {
  baseDeliveryCharge: number;
  perKmCharge: number;
  minDeliveryCharge: number;
  maxDeliveryDistanceKm: number;
  platformFlatCharge: number;
}

export interface CommissionSettings {
  commissionPercent: number;
  commissionableComponents: ('material_cost' | 'delivery_charge' | 'platform_charges')[];
}

export async function getSetting<T>(key: string): Promise<T> {
  const row = await db.query('SELECT value FROM admin_settings WHERE key = $1', [key]);
  if (!row.rows.length) {
    throw new Error(`Missing required admin_settings row: ${key}`);
  }
  return row.rows[0].value as T;
}

export async function getPricingSettings(): Promise<PricingSettings> {
  const [base, perKm, min, maxDist, flat] = await Promise.all([
    getSetting<number>('base_delivery_charge'),
    getSetting<number>('per_km_charge'),
    getSetting<number>('min_delivery_charge'),
    getSetting<number>('max_delivery_distance_km'),
    getSetting<number>('platform_flat_charge'),
  ]);
  return {
    baseDeliveryCharge: base,
    perKmCharge: perKm,
    minDeliveryCharge: min,
    maxDeliveryDistanceKm: maxDist,
    platformFlatCharge: flat,
  };
}

// ---- Advanced delivery pricing factors (migration 002) ----
// Kept as a separate getter (rather than folding into PricingSettings)
// so the original calculatePriceQuote() used by the normal single-truck
// order flow is completely unaffected — these are opt-in, used by
// calculateAdvancedDeliveryCharge() below for multi-truck/RFQ-driven quotes.
export interface AdvancedPricingFactors {
  loadingCharge: number; unloadingCharge: number; waitingChargePerHour: number;
  defaultTollCharge: number; remoteAreaCharge: number; remoteAreaDistanceKm: number;
}

export async function getAdvancedPricingFactors(): Promise<AdvancedPricingFactors> {
  const [loading, unloading, waiting, toll, remote, remoteDist] = await Promise.all([
    getSetting<number>('loading_charge'),
    getSetting<number>('unloading_charge'),
    getSetting<number>('waiting_charge_per_hour'),
    getSetting<number>('default_toll_charge'),
    getSetting<number>('remote_area_charge'),
    getSetting<number>('remote_area_distance_km'),
  ]);
  return {
    loadingCharge: loading, unloadingCharge: unloading, waitingChargePerHour: waiting,
    defaultTollCharge: toll, remoteAreaCharge: remote, remoteAreaDistanceKm: remoteDist,
  };
}

export async function getVehicleRateMultiplier(vehicleCategory: string): Promise<number> {
  const row = await db.query('SELECT multiplier FROM vehicle_rate_multipliers WHERE vehicle_category = $1', [vehicleCategory]);
  return row.rows.length ? Number(row.rows[0].multiplier) : 1.0;
}

export async function getCommissionSettings(): Promise<CommissionSettings> {
  const [percent, components] = await Promise.all([
    getSetting<number>('commission_percent'),
    getSetting<('material_cost' | 'delivery_charge' | 'platform_charges')[]>('commissionable_components'),
  ]);
  return { commissionPercent: percent, commissionableComponents: components };
}

// Admin panel write path — every write is audited (updated_by/updated_at
// are set by the DB layer / caller), and each key is validated before saving.
export async function updateSetting(key: string, value: unknown, updatedBy: string): Promise<void> {
  const validators: Record<string, (v: unknown) => boolean> = {
    commission_percent: (v) => typeof v === 'number' && v >= 0 && v <= 100,
    base_delivery_charge: (v) => typeof v === 'number' && v >= 0,
    per_km_charge: (v) => typeof v === 'number' && v >= 0,
    min_delivery_charge: (v) => typeof v === 'number' && v >= 0,
    max_delivery_distance_km: (v) => typeof v === 'number' && v > 0,
    platform_flat_charge: (v) => typeof v === 'number' && v >= 0,
    loading_charge: (v) => typeof v === 'number' && v >= 0,
    unloading_charge: (v) => typeof v === 'number' && v >= 0,
    waiting_charge_per_hour: (v) => typeof v === 'number' && v >= 0,
    default_toll_charge: (v) => typeof v === 'number' && v >= 0,
    remote_area_charge: (v) => typeof v === 'number' && v >= 0,
    remote_area_distance_km: (v) => typeof v === 'number' && v > 0,
    gst_rate_percent: (v) => typeof v === 'number' && v >= 0 && v <= 100,
  };
  const validator = validators[key];
  if (validator && !validator(value)) {
    throw new Error(`Invalid value for admin_settings.${key}`);
  }
  await db.query(
    `INSERT INTO admin_settings (key, value, updated_by, updated_at)
     VALUES ($1, $2, $3, now())
     ON CONFLICT (key) DO UPDATE SET value = $2, updated_by = $3, updated_at = now()`,
    [key, JSON.stringify(value), updatedBy]
  );
}
