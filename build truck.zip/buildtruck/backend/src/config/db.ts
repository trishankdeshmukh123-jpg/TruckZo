// Postgres client + a withTransaction() helper used by every multi-step
// write (order creation, inventory reservation/fulfillment, cancellation)
// so a failure partway through rolls back everything instead of leaving
// orphaned rows or double-counted stock. This is the ONLY database layer —
// services call db.query() for single statements and withTransaction() for
// anything that must be atomic; nothing duplicates this.
//
// ENVIRONMENT VARIABLE REQUIRED: DATABASE_URL

import { Pool, PoolClient } from 'pg';

if (!process.env.DATABASE_URL) {
  // eslint-disable-next-line no-console
  console.warn('[buildtruck] DATABASE_URL is not set — set it in your .env file.');
}

export const db = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// A transactional "handle" with the same .query() shape as `db`, so
// existing service code that does `await db.query(...)` can be changed to
// `await tx.query(...)` inside a withTransaction() callback with no other
// change. All statements inside one callback run on the SAME client, which
// is required for BEGIN/COMMIT/ROLLBACK to apply to all of them together.
export interface TxHandle {
  query: PoolClient['query'];
}

export async function withTransaction<T>(fn: (tx: TxHandle) => Promise<T>): Promise<T> {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const result = await fn({ query: client.query.bind(client) });
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {
      // Rollback failing too (e.g. connection already dropped) — the
      // original error is what matters; don't mask it.
    });
    throw err;
  } finally {
    client.release();
  }
}
