# BuildTruck — construction-materials marketplace (MVP)

Marketplace connecting customers/builders with verified suppliers and truck
owners in India. Platform earns a configurable commission (default 5%).
BuildTruck is a marketplace/coordination platform only. The Government
Project / Tender section is a separate material & truck marketplace — it is
**not** an official government portal and does **not** award tenders.

```
backend/          Node + TypeScript + Express + PostgreSQL API
mobile/           React Native (Expo) app — Customer, Supplier and Business features, one app
admin-dashboard/  Next.js admin dashboard
db/               schema.sql, migrations/002_advanced_features.sql, seed.sql
docs/             ARCHITECTURE.md
```

## Setup

### 1. Database
```bash
createdb buildtruck
psql buildtruck -f db/schema.sql
psql buildtruck -f db/migrations/002_advanced_features.sql
psql buildtruck -f db/seed.sql          # categories + sample catalog materials
```
Create an admin user (there is no public admin signup):
```sql
INSERT INTO users (email, full_name, role, password_hash)
VALUES ('admin@example.com','Admin','admin', '<bcrypt hash>');
-- e.g. node -e "console.log(require('bcryptjs').hashSync('yourpassword',10))"
```

### 2. Backend
```bash
cd backend && cp .env.example .env && npm install && npm run dev   # :4000
```
### 3. Admin dashboard
```bash
cd admin-dashboard && npm install
NEXT_PUBLIC_API_BASE_URL=http://localhost:4000 npm run dev
```
Sign in at `/login` with the admin account. Admin pages read live data and show
an error (not invented rows) if the backend is unreachable. Legacy pages
(customers, suppliers, coupons, complaints, payments, settlements, commission,
materials) still show bundled sample rows — see "Known limitations".

### 4. Mobile app
```bash
cd mobile && npm install && npx expo start
```
Set `expo.extra.apiBaseUrl` in `mobile/app.json` to your backend URL (use your
machine's LAN IP on a real device, not `localhost`).

## Environment variables (backend/.env)

| Variable | Needed for | Notes |
|---|---|---|
| `DATABASE_URL` | everything | **required** |
| `JWT_SECRET` | auth | **required** — long random string |
| `PAYMENT_PROVIDER=razorpay`, `PAYMENT_PROVIDER_KEY_ID`, `PAYMENT_PROVIDER_KEY_SECRET`, `PAYMENT_WEBHOOK_SECRET` | real UPI | default is a **mock provider that auto-succeeds — no real money moves**. Webhook URL: `POST /payments/webhook` |
| `MAPS_PROVIDER=google`, `MAPS_PROVIDER_API_KEY` | road distance/ETA/geocoding | default is straight-line haversine. Enable Distance Matrix + Geocoding APIs. Mobile map tiles on Android also need a Google Maps key in app config |
| `SMS_PROVIDER_API_KEY` | real OTP SMS | **the actual send call is not implemented**; without it OTPs are printed to the server console |
| `FCM_SERVER_KEY` | push notifications | **push sending is not implemented** (device-token storage not built). In-app notification center works without it |
| `PORT` | — | default 4000 |

None of the external services above are configured in this package; nothing
should be described as "live" until you set them and test.

## What is implemented (backend + UI)

| Module | Backend | Customer/Business UI | Supplier UI | Admin UI |
|---|---|---|---|---|
| Material marketplace, supplier search, cart, order, Cash/UPI, 5% commission ledger, distance delivery pricing, delivery OTP, tracking | ✔ | ✔ | ✔ (orders, status, materials, trucks, earnings screen*) | orders (live), settings |
| Vehicle categories + tonnage, truck search | ✔ | ✔ | ✔ | trucks* |
| Government Tender module (separate) | ✔ | ✔ | ✔ | tenders* (verify) |
| RFQ / quotations (statuses, compare, award) | ✔ | create/list/compare/award | discover + quote | RFQs, Quotations |
| Multi-truck orders / trips | ✔ | progress on tracking screen | enable, add trips, assign truck, trip status | Trips |
| Proof of delivery (qty, shortage, photo URL, timestamp) | ✔ | shown on tracking | submit POD | PODs |
| Category-configurable material specs | ✔ (`category_spec_fields`) | — | spec fields shown when adding a material | — (create via `POST /categories/:id/spec-fields`) |
| Business accounts, roles, projects, dashboards | ✔ | business + projects + dashboard | — | Businesses, Projects |
| Disputes with audit history | ✔ | report/list/detail | — | Disputes (status/notes) |
| Supplier/truck document verification + expiry | ✔ | — | upload/status | Verification (+ expiry job) |
| Inventory (reserve/release/fulfil hooked into order lifecycle) | ✔ | — | inventory screen | Inventory |
| Invoices (auto-generated on completion) | ✔ | invoice screen | — | Invoices |
| Notifications (in-app, DB-backed) | ✔ | center | center | log |
| Advanced delivery pricing (base, per-km, vehicle multiplier, loading, unloading, waiting, toll, remote) | ✔ | — | — | Advanced pricing |

`*` = still reads bundled sample rows (see below).

## Known limitations (be aware before launch)

- **Verified end-to-end only by static review.** No `npm install`, database, or
  device was available in the build environment: nothing was compiled, no
  migrations were executed, no API test was run. Type-checking showed no
  cross-file reference errors, but expect to fix runtime issues on first run.
- Order creation / stock reservation / inventory updates are **not wrapped in a
  DB transaction** — wrap `createOrder` in a transaction before production.
- The customer’s **checkout still prices and searches suppliers against a fixed
  demo delivery point** on the supplier-selection screen (`sampleAddresses[0]`);
  the real chosen address is used from the Address step onward.
- Advanced delivery pricing is available at `POST /pricing/advanced-quote` and
  configurable in admin, but the normal single-truck checkout still uses the
  simpler base + per-km formula (unchanged on purpose). It is not yet applied
  automatically to multi-truck orders.
- Supplier dashboard stat cards, supplier Materials/Trucks/Earnings/Profile
  list screens, and several legacy admin pages still display sample data.
- Customer signature capture, photo upload and file storage are not
  implemented: photo/document fields accept URLs only. Configure cloud storage
  and add upload endpoints.
- Push notifications, real SMS OTP, and geocoding of free-text addresses need
  the keys above plus implementation of the send calls.
- Home “nearby suppliers” cards and popular-material fallbacks show sample data
  when the backend is unreachable (labelled on screen).
- Scheduled jobs (RFQ expiry, document expiry): trigger via
  `POST /admin/maintenance/expire-rfqs` and `/expire-documents` from cron.
- Legal: T&Cs, privacy policy, agreements, GST/invoice tax logic (invoice tax is
  currently 0), and RBI/GST treatment of commission need lawyer/CA review.

## Deployment notes
Backend: any Node host + managed Postgres; run migrations manually in order;
set env vars; put behind HTTPS; add rate limiting (not included). Admin: `next build`
and host on Vercel/any Node host. Mobile: build with EAS (`eas build`).
