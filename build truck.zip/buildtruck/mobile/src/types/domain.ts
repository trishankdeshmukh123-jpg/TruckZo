// Shared shapes used across sample data AND live API responses, so
// screens/contexts don't care which source they came from. Live API
// responses are mapped into these shapes at the fetch boundary (see each
// screen's useEffect) rather than propagating separate live/sample types.

export interface Category { id: string; name: string; slug: string; icon: string; }

export interface Material { id: string; categoryId: string; name: string; unit: string; description: string; }

export interface Supplier {
  id: string; businessName: string; rating: number; ratingCount: number;
  distanceKm: number; lat: number; lng: number; verified: boolean;
}

export interface Offer {
  id: string; supplierId: string; materialId: string;
  pricePerUnit: number; availableQuantity: number; minOrderQuantity: number;
}

export interface Address {
  id: string; label: string; line1: string; city: string; state: string; pincode: string;
  lat: number; lng: number;
}
