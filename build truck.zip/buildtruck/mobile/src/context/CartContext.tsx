// Cart holds ONE supplier's items at a time (you can't split a delivery
// across suppliers in the MVP — matches the order flow: pick a supplier,
// then build a cart from what they sell).

import React, { createContext, useContext, useMemo, useState } from 'react';
import { Supplier, Offer, Material } from '../types/domain';

export interface CartItem {
  offer: Offer;
  material: Material;
  quantity: number;
}

interface CartState {
  supplier: Supplier | null;
  items: CartItem[];
  setSupplier: (s: Supplier) => void;
  addOrUpdateItem: (offer: Offer, material: Material, quantity: number) => void;
  removeItem: (offerId: string) => void;
  clear: () => void;
  materialCost: number;
}

const CartContext = createContext<CartState | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [supplier, setSupplierState] = useState<Supplier | null>(null);
  const [items, setItems] = useState<CartItem[]>([]);

  function setSupplier(s: Supplier) {
    // switching supplier clears the cart — items belong to one supplier
    if (supplier?.id !== s.id) setItems([]);
    setSupplierState(s);
  }

  function addOrUpdateItem(offer: Offer, material: Material, quantity: number) {
    setItems((prev) => {
      const existing = prev.find((i) => i.offer.id === offer.id);
      if (existing) {
        return prev.map((i) => (i.offer.id === offer.id ? { ...i, quantity } : i));
      }
      return [...prev, { offer, material, quantity }];
    });
  }

  function removeItem(offerId: string) {
    setItems((prev) => prev.filter((i) => i.offer.id !== offerId));
  }

  function clear() {
    setItems([]);
    setSupplierState(null);
  }

  const materialCost = useMemo(
    () => items.reduce((sum, i) => sum + i.offer.pricePerUnit * i.quantity, 0),
    [items]
  );

  return (
    <CartContext.Provider value={{ supplier, items, setSupplier, addOrUpdateItem, removeItem, clear, materialCost }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart(): CartState {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
