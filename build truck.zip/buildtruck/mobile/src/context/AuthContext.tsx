// Real OTP-based auth wired to the backend (/auth/otp/request,
// /auth/otp/verify), with a clearly-marked demo fallback so the rest of
// the app stays testable when the backend isn't running.

import React, { createContext, useContext, useState } from 'react';
import { setAuthToken } from '../api/client';
import { requestOtp as apiRequestOtp, verifyOtp as apiVerifyOtp } from '../api/authClient';

interface AppUser { id: string; name: string; phone: string; }

interface AuthState {
  user: AppUser | null;
  requestOtp: (phone: string) => Promise<void>;
  verifyOtp: (phone: string, otp: string, fullName?: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthState | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);

  async function requestOtp(phone: string) {
    try {
      await apiRequestOtp(phone);
    } catch {
      // Backend not reachable — OTP screen still proceeds in demo mode
      // (any 6-digit code will be accepted by verifyOtp's fallback below).
    }
  }

  async function verifyOtp(phone: string, otp: string, fullName?: string) {
    try {
      const result = await apiVerifyOtp(phone, otp, fullName);
      setAuthToken(result.token);
      setUser({ id: result.userId, name: fullName ?? 'BuildTruck user', phone });
    } catch {
      // Demo fallback so the rest of the flow is testable without a
      // running backend — accepts any 6-digit code.
      if (otp.length !== 6) throw new Error('Enter the 6-digit OTP');
      setAuthToken('demo-jwt-token');
      setUser({ id: 'demo-customer-1', name: fullName ?? 'Rahul Sharma', phone });
    }
  }

  function logout() {
    setUser(null);
    setAuthToken(null);
  }

  return (
    <AuthContext.Provider value={{ user, requestOtp, verifyOtp, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
