// Customer <-> Supplier mode switch, all in one app (per spec: "Use ONE app
// with a separate Supplier/Truck Owner Mode"). Admin gates who is allowed
// to switch into supplier mode via `canUseSupplierMode` (mirrors
// users.is_supplier_mode_enabled on the backend).

import React, { createContext, useContext, useState } from 'react';

export type AppMode = 'customer' | 'supplier';

interface AppModeState {
  mode: AppMode;
  canUseSupplierMode: boolean;
  toggleMode: () => void;
}

const AppModeContext = createContext<AppModeState | undefined>(undefined);

export function AppModeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<AppMode>('customer');
  // Demo default: true. In production this comes from the authenticated
  // user's profile (users.is_supplier_mode_enabled), fetched at login.
  const [canUseSupplierMode] = useState(true);

  function toggleMode() {
    setMode((m) => (m === 'customer' ? 'supplier' : 'customer'));
  }

  return (
    <AppModeContext.Provider value={{ mode, canUseSupplierMode, toggleMode }}>
      {children}
    </AppModeContext.Provider>
  );
}

export function useAppMode(): AppModeState {
  const ctx = useContext(AppModeContext);
  if (!ctx) throw new Error('useAppMode must be used within AppModeProvider');
  return ctx;
}
