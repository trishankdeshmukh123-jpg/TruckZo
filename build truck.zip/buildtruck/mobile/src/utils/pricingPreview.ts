// Client-side PREVIEW of the delivery charge, using the exact same formula
// as backend/src/services/pricingService.ts, so the cart/summary screens
// can show a live number as the user picks quantities/addresses without a
// network round-trip on every keystroke.
//
// This is a preview only — createOrder() on the backend recalculates the
// authoritative total from scratch and that's what actually gets charged.
// If backend admin settings are reachable we fetch and use them; otherwise
// we fall back to the same defaults seeded in db/schema.sql.

import { getPricingSettings } from '../api/client';

export interface PricingSettingsPreview {
  baseDeliveryCharge: number;
  perKmCharge: number;
  minDeliveryCharge: number;
  maxDeliveryDistanceKm: number;
}

const DEFAULT_SETTINGS: PricingSettingsPreview = {
  baseDeliveryCharge: 100,
  perKmCharge: 15,
  minDeliveryCharge: 100,
  maxDeliveryDistanceKm: 150,
};

export async function loadPricingSettings(): Promise<PricingSettingsPreview> {
  try {
    return await getPricingSettings();
  } catch {
    // Backend not reachable in this dev/demo session — use the same
    // defaults the DB is seeded with, clearly marked as a fallback.
    return DEFAULT_SETTINGS;
  }
}

export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

export function previewDeliveryCharge(distanceKm: number, settings: PricingSettingsPreview): number {
  const raw = settings.baseDeliveryCharge + settings.perKmCharge * distanceKm;
  return Math.round(Math.max(settings.minDeliveryCharge, raw) * 100) / 100;
}
