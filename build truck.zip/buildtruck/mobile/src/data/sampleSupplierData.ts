// Sample data for Supplier/Truck Owner Mode — mirrors what the backend
// tables (orders, supplier_materials, trucks, commission_ledger) hold once
// the supplier-facing endpoints exist (see backend README, "What's NOT yet
// built": supplier CRUD endpoints). Used as fallback demo state.

export interface SupplierOrder {
  id: string; orderNumber: string; customerName: string; materialSummary: string;
  status: string; total: number; deliveryCharge: number; distanceKm: number;
  paymentMethod: 'UPI' | 'CASH'; createdAt: string;
}

export const sampleSupplierOrders: SupplierOrder[] = [
  { id: 'so-1', orderNumber: 'BT-2026-005011', customerName: 'Rahul Sharma', materialSummary: '5 ton River Sand', status: 'PENDING', total: 7570, deliveryCharge: 220, distanceKm: 8.0, paymentMethod: 'UPI', createdAt: '10 min ago' },
  { id: 'so-2', orderNumber: 'BT-2026-005002', customerName: 'Priya Nair', materialSummary: '200 bags OPC 53 Cement', status: 'ACCEPTED', total: 77400, deliveryCharge: 400, distanceKm: 20.0, paymentMethod: 'CASH', createdAt: '1 hr ago' },
  { id: 'so-3', orderNumber: 'BT-2026-004981', customerName: 'Mohd. Imran', materialSummary: '3000 Red Clay Bricks', status: 'OUT_FOR_DELIVERY', total: 25850, deliveryCharge: 350, distanceKm: 16.7, paymentMethod: 'CASH', createdAt: '3 hr ago' },
  { id: 'so-4', orderNumber: 'BT-2026-004900', customerName: 'Anjali Deshmukh', materialSummary: '8 ton 20mm Aggregate', status: 'COMPLETED', total: 9800, deliveryCharge: 200, distanceKm: 6.7, paymentMethod: 'UPI', createdAt: 'Yesterday' },
];

export interface SupplierMaterialRow {
  id: string; name: string; category: string; price: number; unit: string; availableQuantity: number; isActive: boolean;
}

export const sampleSupplierMaterials: SupplierMaterialRow[] = [
  { id: 'sm-1', name: 'River Sand (Fine)', category: 'Sand', price: 1450, unit: 'ton', availableQuantity: 120, isActive: true },
  { id: 'sm-2', name: 'OPC 53 Grade Cement', category: 'Cement', price: 385, unit: 'bag', availableQuantity: 500, isActive: true },
  { id: 'sm-3', name: '20mm Aggregate', category: 'Gitti / Aggregate', price: 1200, unit: 'ton', availableQuantity: 90, isActive: false },
];

export interface SupplierTruckRow {
  id: string; registrationNumber: string; vehicleCategory: string; capacityBracket: string;
  capacityTons: number; ratePerTrip: number; ratePerKm: number;
  driverName: string; driverPhone: string; vehicleDetails: string; isAvailable: boolean;
}

export const sampleSupplierTrucks: SupplierTruckRow[] = [
  { id: 'tr-1', registrationNumber: 'MH12AB1234', vehicleCategory: '10_wheeler', capacityBracket: '15_ton', capacityTons: 16, ratePerTrip: 4500, ratePerKm: 55, driverName: 'Suresh Patil', driverPhone: '+919812345670', vehicleDetails: '2021 model, good condition', isAvailable: true },
  { id: 'tr-2', registrationNumber: 'MH04CD5678', vehicleCategory: '6_wheeler', capacityBracket: '10_ton', capacityTons: 9, ratePerTrip: 3200, ratePerKm: 40, driverName: 'Ramesh Yadav', driverPhone: '+919812345671', vehicleDetails: '2019 model', isAvailable: false },
];

export const supplierEarningsSummary = {
  todayOrders: 3,
  pendingOrders: 1,
  activeDeliveries: 1,
  totalEarningsThisMonth: 214600,
  pendingCommission: 3170,
  verificationStatus: 'APPROVED' as const,
};
