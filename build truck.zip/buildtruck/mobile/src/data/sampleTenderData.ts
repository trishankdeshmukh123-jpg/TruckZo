// Sample data for a supplier's own Government Tender listings (demo state
// when the backend isn't reachable).

export interface TenderMaterialRow {
  id: string; materialName: string; quantity: number; unit: string; rate: number;
  supplyLocation: string; serviceArea: string; isAvailable: boolean; verificationStatus: string;
}
export const sampleTenderMaterials: TenderMaterialRow[] = [
  { id: 'stm-1', materialName: 'River Sand', quantity: 5000, unit: 'ton', rate: 1350, supplyLocation: 'Nashik, Maharashtra', serviceArea: 'Nashik district', isAvailable: true, verificationStatus: 'APPROVED' },
];

export interface TenderTruckRow {
  id: string; vehicleCategory: string; capacityBracket: string; registrationNumber: string;
  ratePerTrip: number; ratePerKm: number; isAvailable: boolean; verificationStatus: string;
}
export const sampleTenderTrucks: TenderTruckRow[] = [
  { id: 'stt-1', vehicleCategory: '12_wheeler', capacityBracket: '20_ton', registrationNumber: 'MH20GH3456', ratePerTrip: 6000, ratePerKm: 65, isAvailable: true, verificationStatus: 'PENDING' },
];
