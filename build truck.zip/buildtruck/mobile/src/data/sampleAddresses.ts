// Sample saved addresses (would come from GET /addresses once that backend
// endpoint exists — see backend README "What's NOT yet built"). Includes
// lat/lng because delivery-charge calculation needs real coordinates, not
// just a text address — geocoding free text requires MAPS_PROVIDER_API_KEY.

export interface Address {
  id: string; label: string; line1: string; city: string; state: string; pincode: string;
  lat: number; lng: number;
}

export const sampleAddresses: Address[] = [
  { id: 'addr-1', label: 'Site', line1: 'Plot 42, Sai Nagar, Andheri East', city: 'Mumbai', state: 'Maharashtra', pincode: '400069', lat: 19.117, lng: 72.869 },
  { id: 'addr-2', label: 'Home', line1: 'B-304, Sunrise Apartments, Powai', city: 'Mumbai', state: 'Maharashtra', pincode: '400076', lat: 19.119, lng: 72.906 },
];

export function addressById(id: string): Address | undefined {
  return sampleAddresses.find((a) => a.id === id);
}
