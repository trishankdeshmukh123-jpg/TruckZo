// Realistic sample data used whenever the live backend/API isn't reachable
// (e.g. running the app standalone during development, or a network call
// fails). Every screen tries the real API first via src/api/client.ts and
// falls back to this data — search for "falls back to sample data" to see
// where. Replace/remove once the backend is deployed and seeded for real.

export interface Category {
  id: string; name: string; slug: string; icon: string;
}

export const sampleCategories: Category[] = [
  { id: 'cat-sand', name: 'Sand', slug: 'sand', icon: '🏖️' },
  { id: 'cat-gitti', name: 'Gitti / Aggregate', slug: 'gitti-aggregate', icon: '🪨' },
  { id: 'cat-stone', name: 'Stone', slug: 'stone', icon: '🧱' },
  { id: 'cat-gravel', name: 'Gravel', slug: 'gravel', icon: '⛰️' },
  { id: 'cat-soil', name: 'Soil / Mitti', slug: 'soil-mitti', icon: '🟫' },
  { id: 'cat-flyash', name: 'Fly Ash', slug: 'fly-ash', icon: '💨' },
  { id: 'cat-bricks', name: 'Bricks', slug: 'bricks', icon: '🧱' },
  { id: 'cat-cement', name: 'Cement', slug: 'cement', icon: '🏗️' },
  { id: 'cat-blocks', name: 'Construction Blocks', slug: 'construction-blocks', icon: '⬜' },
  { id: 'cat-other', name: 'Other', slug: 'other', icon: '📦' },
];

export interface Material {
  id: string; categoryId: string; name: string; unit: string; description: string;
}

export const sampleMaterials: Material[] = [
  { id: 'mat-river-sand', categoryId: 'cat-sand', name: 'River Sand (Fine)', unit: 'ton', description: 'Fine river sand for plastering and masonry work.' },
  { id: 'mat-msand', categoryId: 'cat-sand', name: 'M-Sand (Manufactured)', unit: 'ton', description: 'Manufactured sand, consistent grading, good for concrete.' },
  { id: 'mat-20mm-agg', categoryId: 'cat-gitti', name: '20mm Aggregate', unit: 'ton', description: 'Crushed stone aggregate for RCC work.' },
  { id: 'mat-12mm-agg', categoryId: 'cat-gitti', name: '12mm Aggregate', unit: 'ton', description: 'Finer aggregate for slabs and finishing.' },
  { id: 'mat-red-bricks', categoryId: 'cat-bricks', name: 'Red Clay Bricks', unit: 'brick', description: 'Standard 9x4x3 inch clay bricks.' },
  { id: 'mat-fly-ash-bricks', categoryId: 'cat-bricks', name: 'Fly Ash Bricks', unit: 'brick', description: 'Lightweight, eco-friendly fly ash bricks.' },
  { id: 'mat-opc53', categoryId: 'cat-cement', name: 'OPC 53 Grade Cement', unit: 'bag', description: '50kg bag, Ordinary Portland Cement Grade 53.' },
  { id: 'mat-ppc', categoryId: 'cat-cement', name: 'PPC Cement', unit: 'bag', description: '50kg bag, Portland Pozzolana Cement.' },
];

export interface Supplier {
  id: string; businessName: string; rating: number; ratingCount: number;
  distanceKm: number; lat: number; lng: number; verified: boolean;
}

// A given material may be sold by several suppliers at different prices —
// this is the "compare suppliers" list.
export interface SupplierMaterialOffer {
  id: string; supplierId: string; materialId: string;
  pricePerUnit: number; availableQuantity: number; minOrderQuantity: number;
}

export const sampleSuppliers: Supplier[] = [
  { id: 'sup-1', businessName: 'Shree Balaji Sand & Aggregates', rating: 4.6, ratingCount: 212, distanceKm: 6.2, lat: 19.076, lng: 72.877, verified: true },
  { id: 'sup-2', businessName: 'RK Construction Materials', rating: 4.3, ratingCount: 98, distanceKm: 9.8, lat: 19.10, lng: 72.90, verified: true },
  { id: 'sup-3', businessName: 'Ganesh Brick & Cement Depot', rating: 4.8, ratingCount: 340, distanceKm: 3.4, lat: 19.06, lng: 72.86, verified: true },
  { id: 'sup-4', businessName: 'New India Building Supplies', rating: 3.9, ratingCount: 41, distanceKm: 14.1, lat: 19.12, lng: 72.93, verified: false },
];

export const sampleOffers: SupplierMaterialOffer[] = [
  { id: 'off-1', supplierId: 'sup-1', materialId: 'mat-river-sand', pricePerUnit: 1450, availableQuantity: 120, minOrderQuantity: 1 },
  { id: 'off-2', supplierId: 'sup-2', materialId: 'mat-river-sand', pricePerUnit: 1380, availableQuantity: 60, minOrderQuantity: 2 },
  { id: 'off-3', supplierId: 'sup-3', materialId: 'mat-river-sand', pricePerUnit: 1500, availableQuantity: 200, minOrderQuantity: 1 },
  { id: 'off-4', supplierId: 'sup-1', materialId: 'mat-opc53', pricePerUnit: 385, availableQuantity: 500, minOrderQuantity: 10 },
  { id: 'off-5', supplierId: 'sup-3', materialId: 'mat-red-bricks', pricePerUnit: 8.5, availableQuantity: 20000, minOrderQuantity: 500 },
  { id: 'off-6', supplierId: 'sup-2', materialId: 'mat-20mm-agg', pricePerUnit: 1200, availableQuantity: 90, minOrderQuantity: 1 },
];

export function offersForMaterial(materialId: string): SupplierMaterialOffer[] {
  return sampleOffers.filter((o) => o.materialId === materialId);
}

export function supplierById(id: string): Supplier | undefined {
  return sampleSuppliers.find((s) => s.id === id);
}

export function materialById(id: string): Material | undefined {
  return sampleMaterials.find((m) => m.id === id);
}
