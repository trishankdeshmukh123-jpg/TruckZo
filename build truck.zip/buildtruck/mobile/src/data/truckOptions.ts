// Fixed option sets for vehicle category + capacity bracket — must match
// the CHECK constraints in db/schema.sql exactly (trucks + tender_trucks
// tables) and backend/src/types/enums.ts's VEHICLE_CATEGORIES/CAPACITY_BRACKETS.

export interface Option { value: string; label: string; }

export const VEHICLE_CATEGORIES: Option[] = [
  { value: '6_wheeler', label: '6 Wheeler' },
  { value: '10_wheeler', label: '10 Wheeler' },
  { value: '12_wheeler', label: '12 Wheeler' },
  { value: '16_wheeler', label: '16 Wheeler' },
  { value: '18_wheeler', label: '18 Wheeler' },
  { value: 'tractor', label: 'Tractor' },
  { value: 'tractor_trolley', label: 'Tractor + Trolley' },
  { value: 'pickup', label: 'Pickup' },
  { value: 'mini_truck', label: 'Mini Truck' },
  { value: 'other', label: 'Other' },
];

export const CAPACITY_BRACKETS: Option[] = [
  { value: '1_ton', label: '1 Ton' },
  { value: '2_ton', label: '2 Ton' },
  { value: '3_ton', label: '3 Ton' },
  { value: '5_ton', label: '5 Ton' },
  { value: '7_ton', label: '7 Ton' },
  { value: '10_ton', label: '10 Ton' },
  { value: '15_ton', label: '15 Ton' },
  { value: '20_ton', label: '20 Ton' },
  { value: '25_ton_plus', label: '25 Ton+' },
];

export function labelFor(options: Option[], value: string | null | undefined): string {
  return options.find((o) => o.value === value)?.label ?? (value || '—');
}
