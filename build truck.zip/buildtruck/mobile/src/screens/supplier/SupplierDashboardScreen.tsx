// Supplier dashboard: today's orders, pending, active deliveries, earnings,
// pending commission, verification status — matches spec §10.

import React from 'react';
import { ScrollView, Text, View, TouchableOpacity } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { supplierEarningsSummary } from '../../data/sampleSupplierData';
import { useAppMode } from '../../context/AppModeContext';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierDashboard'>;

export default function SupplierDashboardScreen({ navigation }: Props) {
  const s = supplierEarningsSummary;
  const { toggleMode } = useAppMode();

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={type.h1}>Supplier mode</Text>
          <TouchableOpacity onPress={toggleMode}>
            <Chip label="Switch to Customer" />
          </TouchableOpacity>
        </View>
        <Chip
          label={`Verification: ${s.verificationStatus}`}
          tone={s.verificationStatus === 'APPROVED' ? 'success' : 'warning'}
        />

        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: spacing.md, gap: spacing.sm }}>
          <StatCard label="Today's orders" value={String(s.todayOrders)} />
          <StatCard label="Pending" value={String(s.pendingOrders)} onPress={() => navigation.navigate('SupplierOrders')} />
          <StatCard label="Active deliveries" value={String(s.activeDeliveries)} />
          <StatCard label="This month's earnings" value={formatINR(s.totalEarningsThisMonth)} wide />
          <StatCard
            label="Pending commission owed"
            value={formatINR(s.pendingCommission)}
            wide
            tone="warning"
            onPress={() => navigation.navigate('SupplierEarnings')}
          />
        </View>

        <Text style={[type.h2, { marginTop: spacing.lg, marginBottom: spacing.sm }]}>Manage</Text>
        <MenuRow label="Orders" onPress={() => navigation.navigate('SupplierOrders')} />
        <MenuRow label="Materials" onPress={() => navigation.navigate('SupplierMaterials')} />
        <MenuRow label="Trucks" onPress={() => navigation.navigate('SupplierTrucks')} />
        <MenuRow label="Government Tender listings" onPress={() => navigation.navigate('SupplierTenderListings')} />
        <MenuRow label="RFQs & quotes" onPress={() => navigation.navigate('SupplierRfqList')} />
        <MenuRow label="Inventory" onPress={() => navigation.navigate('SupplierInventory')} />
        <MenuRow label="Verification & documents" onPress={() => navigation.navigate('SupplierVerification')} />
        <MenuRow label="Notifications" onPress={() => navigation.navigate('SupplierNotifications')} />
        <MenuRow label="Earnings & settlements" onPress={() => navigation.navigate('SupplierEarnings')} />
        <MenuRow label="Business profile & documents" onPress={() => navigation.navigate('SupplierProfile')} />
      </ScrollView>
    </ScreenContainer>
  );
}

function StatCard({ label, value, wide, tone, onPress }: { label: string; value: string; wide?: boolean; tone?: 'warning'; onPress?: () => void }) {
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper onPress={onPress} style={{ width: wide ? '100%' : '47%' }}>
      <Card style={{ marginBottom: 0, borderColor: tone === 'warning' ? colors.warning : colors.border }}>
        <Text style={type.caption}>{label}</Text>
        <Text style={[type.price, { marginTop: 4 }]}>{value}</Text>
      </Card>
    </Wrapper>
  );
}

function MenuRow({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <TouchableOpacity onPress={onPress}>
      <Card>
        <Text style={type.h3}>{label} ›</Text>
      </Card>
    </TouchableOpacity>
  );
}
