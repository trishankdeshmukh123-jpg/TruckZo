import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { ScreenContainer, Card, Chip, SecondaryButton } from '../../components/Primitives';
import { type, spacing } from '../../theme/theme';
import { useAppMode } from '../../context/AppModeContext';

export default function SupplierProfileScreen() {
  const { toggleMode } = useAppMode();
  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>Business profile</Text>
        <Card>
          <Text style={type.h3}>Shree Balaji Sand & Aggregates</Text>
          <Text style={type.caption}>Andheri East, Mumbai · GST: 27ABCDE1234F1Z5</Text>
          <Chip label="Verification: APPROVED" tone="success" />
        </Card>
        <Card>
          <Text style={type.h3}>Verification documents</Text>
          <Text style={type.caption}>GST certificate · ID proof · Address proof — all approved.</Text>
          <Text style={[type.caption, { marginTop: spacing.xs }]}>
            Document files are stored privately (signed URLs) per backend security architecture §8 —
            never public.
          </Text>
        </Card>
        <SecondaryButton title="Switch to Customer mode" onPress={toggleMode} />
      </ScrollView>
    </ScreenContainer>
  );
}
