// Add/edit a material listing. Now calls the real backend
// (POST /suppliers/materials, added this pass) instead of only confirming
// locally — this was a genuine gap: there was previously no endpoint for a
// supplier to actually create a supplier_materials row.

import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, ScrollView, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { sampleSupplierMaterials } from '../../data/sampleSupplierData';
import { sampleCategories } from '../../data/sampleData';
import { getMySupplierProfile, createSupplierMaterialListing, getMaterials, getCategorySpecFields, CategorySpecField } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierMaterialEdit'>;

export default function SupplierMaterialEditScreen({ route, navigation }: Props) {
  const existing = route.params?.materialId
    ? sampleSupplierMaterials.find((m) => m.id === route.params.materialId)
    : undefined;

  const [categoryId, setCategoryId] = useState('');
  const [materialId, setMaterialId] = useState('');
  const [materials, setMaterials] = useState<{ id: string; name: string; category_id: string }[]>([]);
  const [specFields, setSpecFields] = useState<CategorySpecField[]>([]);
  const [specValues, setSpecValues] = useState<Record<string, string>>({});

  const [price, setPrice] = useState(existing ? String(existing.price) : '');
  const [unit, setUnit] = useState(existing?.unit ?? 'ton');
  const [quantity, setQuantity] = useState(existing ? String(existing.availableQuantity) : '');
  const [minOrder, setMinOrder] = useState('1');
  const [lowStockThreshold, setLowStockThreshold] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const { results } = await getMaterials();
        setMaterials(results.map((m) => ({ id: m.id, name: m.name, category_id: m.category_id })));
      } catch { /* material picker will just be empty until backend is reachable */ }
    })();
  }, []);

  useEffect(() => {
    if (!categoryId) { setSpecFields([]); return; }
    (async () => {
      try {
        const { results } = await getCategorySpecFields(categoryId);
        setSpecFields(results);
      } catch { setSpecFields([]); }
    })();
  }, [categoryId]);

  async function save() {
    if (!materialId || !price || !quantity) {
      Alert.alert('Missing fields', 'Pick a material and enter price and available quantity.');
      return;
    }
    setSaving(true);
    try {
      const profile = await getMySupplierProfile();
      await createSupplierMaterialListing({
        supplierId: profile.id, materialId, pricePerUnit: Number(price), unit,
        availableQuantity: Number(quantity), minOrderQuantity: Number(minOrder) || 1,
        specs: specValues, lowStockThreshold: lowStockThreshold ? Number(lowStockThreshold) : undefined,
      });
      Alert.alert('Saved', `Listing has been ${existing ? 'updated' : 'added'}.`);
      navigation.goBack();
    } catch (err) {
      Alert.alert('Could not save', (err as Error).message || 'Make sure you are registered as a supplier and the backend is reachable.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>{existing ? 'Edit material' : 'Add material'}</Text>

        <Card>
          <Text style={type.caption}>Category</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginTop: spacing.xs }}>
            {sampleCategories.map((c) => (
              <Text
                key={c.id}
                onPress={() => setCategoryId(c.id)}
                style={{
                  paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, fontSize: 13,
                  borderWidth: 1, borderColor: categoryId === c.id ? colors.primary : colors.border,
                  backgroundColor: categoryId === c.id ? colors.primary : colors.surface,
                  color: categoryId === c.id ? '#fff' : colors.textPrimary,
                }}
              >
                {c.icon} {c.name}
              </Text>
            ))}
          </View>
        </Card>

        <Card>
          <Text style={type.caption}>Material</Text>
          <View style={{ marginTop: spacing.xs }}>
            {materials.filter((m) => !categoryId || m.category_id === categoryId).map((m) => (
              <Text
                key={m.id}
                onPress={() => setMaterialId(m.id)}
                style={{ paddingVertical: 8, fontSize: 15, fontWeight: materialId === m.id ? '700' : '400', color: materialId === m.id ? colors.primary : colors.textPrimary }}
              >
                {materialId === m.id ? '● ' : '○ '}{m.name}
              </Text>
            ))}
            {materials.length === 0 && <Text style={type.caption}>Materials list loads once the backend is reachable.</Text>}
          </View>
        </Card>

        {specFields.map((f) => (
          <Card key={f.id}>
            <Text style={type.caption}>{f.field_name}{f.is_required ? ' *' : ''}</Text>
            {f.field_type === 'select' ? (
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginTop: spacing.xs }}>
                {f.options.map((opt) => (
                  <Text
                    key={opt}
                    onPress={() => setSpecValues((prev) => ({ ...prev, [f.field_name]: opt }))}
                    style={{
                      paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, fontSize: 13,
                      borderWidth: 1, borderColor: specValues[f.field_name] === opt ? colors.primary : colors.border,
                      backgroundColor: specValues[f.field_name] === opt ? colors.primary : colors.surface,
                      color: specValues[f.field_name] === opt ? '#fff' : colors.textPrimary,
                    }}
                  >
                    {opt}
                  </Text>
                ))}
              </View>
            ) : (
              <TextInput
                value={specValues[f.field_name] ?? ''}
                onChangeText={(v) => setSpecValues((prev) => ({ ...prev, [f.field_name]: v }))}
                keyboardType={f.field_type === 'number' ? 'numeric' : 'default'}
                style={{ fontSize: 15, paddingVertical: 8 }}
              />
            )}
          </Card>
        ))}

        <Card>
          <Text style={type.caption}>Price per unit (₹)</Text>
          <TextInput value={price} onChangeText={setPrice} keyboardType="numeric" placeholder="1450" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Unit</Text>
          <TextInput value={unit} onChangeText={setUnit} placeholder="ton / bag / brick / cft" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Available quantity</Text>
          <TextInput value={quantity} onChangeText={setQuantity} keyboardType="numeric" placeholder="120" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Minimum order quantity</Text>
          <TextInput value={minOrder} onChangeText={setMinOrder} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Low-stock alert threshold (optional)</Text>
          <TextInput value={lowStockThreshold} onChangeText={setLowStockThreshold} keyboardType="numeric" placeholder="e.g. 10" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <PrimaryButton title="Save material" onPress={save} loading={saving} />
      </ScrollView>
    </ScreenContainer>
  );
}
