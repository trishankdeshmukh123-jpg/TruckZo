// Add/edit a truck. Fields per spec: vehicle category, capacity in tons
// (bracket + optional precise tons), registration number, current location,
// availability, rate per trip, rate per km, driver details, vehicle details.
//
// Calls the real backend (POST /trucks) with a local-confirm fallback if
// it's unreachable, so the flow is always completable.

import React, { useState } from 'react';
import { ScrollView, Text, TextInput, Switch, View, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, SecondaryButton } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { sampleSupplierTrucks } from '../../data/sampleSupplierData';
import { VEHICLE_CATEGORIES, CAPACITY_BRACKETS } from '../../data/truckOptions';
import OptionChips from '../../components/OptionChips';
import { createTruck, getMySupplierProfile } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierTruckEdit'>;

export default function SupplierTruckEditScreen({ route, navigation }: Props) {
  const existing = route.params?.truckId ? sampleSupplierTrucks.find((t) => t.id === route.params.truckId) : undefined;

  const [regNumber, setRegNumber] = useState(existing?.registrationNumber ?? '');
  const [category, setCategory] = useState<string | null>(existing?.vehicleCategory ?? null);
  const [capacityBracket, setCapacityBracket] = useState<string | null>(existing?.capacityBracket ?? null);
  const [capacityTons, setCapacityTons] = useState(existing ? String(existing.capacityTons) : '');
  const [ratePerTrip, setRatePerTrip] = useState(existing ? String(existing.ratePerTrip) : '');
  const [ratePerKm, setRatePerKm] = useState(existing ? String(existing.ratePerKm) : '');
  const [driverName, setDriverName] = useState(existing?.driverName ?? '');
  const [driverPhone, setDriverPhone] = useState(existing?.driverPhone ?? '');
  const [vehicleDetails, setVehicleDetails] = useState(existing?.vehicleDetails ?? '');
  const [available, setAvailable] = useState(existing?.isAvailable ?? true);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [gettingLocation, setGettingLocation] = useState(false);
  const [saving, setSaving] = useState(false);

  async function captureLocation() {
    setGettingLocation(true);
    try {
      const Location = await import('expo-location');
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Location permission needed', 'Enable location access to set the truck\'s current location.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({});
      setCurrentLocation({ lat: loc.coords.latitude, lng: loc.coords.longitude });
    } catch {
      Alert.alert('Could not get location', 'Try again, or leave it blank and update it later.');
    } finally {
      setGettingLocation(false);
    }
  }

  async function save() {
    if (!regNumber || !category || !driverName || !driverPhone) {
      Alert.alert('Missing fields', 'Registration number, vehicle category and driver details are required.');
      return;
    }
    setSaving(true);
    try {
      const profile = await getMySupplierProfile();
      await createTruck({
        supplierId: profile.id,
        registrationNumber: regNumber, vehicleCategory: category, capacityBracket: capacityBracket ?? undefined,
        capacityTons: capacityTons ? Number(capacityTons) : undefined,
        ratePerTrip: ratePerTrip ? Number(ratePerTrip) : undefined,
        ratePerKm: ratePerKm ? Number(ratePerKm) : undefined,
        currentLat: currentLocation?.lat, currentLng: currentLocation?.lng,
        vehicleDetails, driverName, driverPhone, isAvailable: available,
      });
      Alert.alert('Saved', `${regNumber} has been ${existing ? 'updated' : 'added'}.`);
      navigation.goBack();
    } catch (err) {
      Alert.alert('Could not save', (err as Error).message || 'Make sure you are registered as a supplier and the backend is reachable.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>{existing ? 'Edit truck' : 'Add truck'}</Text>

        <Card>
          <Text style={type.caption}>Registration number</Text>
          <TextInput value={regNumber} onChangeText={setRegNumber} placeholder="MH12AB1234" autoCapitalize="characters" style={{ fontSize: 15, paddingVertical: 8, color: colors.textPrimary }} />
        </Card>

        <Card>
          <Text style={type.h3}>Vehicle category</Text>
          <View style={{ height: spacing.xs }} />
          <OptionChips options={VEHICLE_CATEGORIES} value={category} onChange={setCategory} />
        </Card>

        <Card>
          <Text style={type.h3}>Capacity (tons)</Text>
          <View style={{ height: spacing.xs }} />
          <OptionChips options={CAPACITY_BRACKETS} value={capacityBracket} onChange={setCapacityBracket} allowClear />
          <View style={{ height: spacing.sm }} />
          <Text style={type.caption}>Precise tonnage (optional)</Text>
          <TextInput value={capacityTons} onChangeText={setCapacityTons} keyboardType="numeric" placeholder="e.g. 16" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <Card>
          <Text style={type.h3}>Rates</Text>
          <Text style={type.caption}>Rate per trip (₹)</Text>
          <TextInput value={ratePerTrip} onChangeText={setRatePerTrip} keyboardType="numeric" placeholder="4500" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Rate per km (₹)</Text>
          <TextInput value={ratePerKm} onChangeText={setRatePerKm} keyboardType="numeric" placeholder="55" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <Card>
          <Text style={type.h3}>Current location</Text>
          {currentLocation ? (
            <Text style={[type.caption, { color: colors.success, marginTop: 4 }]}>
              Captured ({currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)})
            </Text>
          ) : (
            <Text style={type.caption}>Used for customer truck search/filter by distance.</Text>
          )}
          <View style={{ height: spacing.sm }} />
          <SecondaryButton title={gettingLocation ? 'Getting location…' : 'Capture current GPS location'} onPress={captureLocation} />
        </Card>

        <Card>
          <Text style={type.caption}>Driver name</Text>
          <TextInput value={driverName} onChangeText={setDriverName} style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Driver phone</Text>
          <TextInput value={driverPhone} onChangeText={setDriverPhone} keyboardType="numeric" placeholder="+91XXXXXXXXXX" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <Card>
          <Text style={type.caption}>Vehicle details</Text>
          <TextInput value={vehicleDetails} onChangeText={setVehicleDetails} multiline placeholder="Model, year, condition..." style={{ fontSize: 15, paddingVertical: 8, minHeight: 60, textAlignVertical: 'top' }} />
        </Card>

        <Card>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={type.h3}>Available for delivery</Text>
            <Switch value={available} onValueChange={setAvailable} trackColor={{ true: colors.primary }} />
          </View>
        </Card>

        <PrimaryButton title="Save truck" onPress={save} loading={saving} />
      </ScrollView>
    </ScreenContainer>
  );
}
