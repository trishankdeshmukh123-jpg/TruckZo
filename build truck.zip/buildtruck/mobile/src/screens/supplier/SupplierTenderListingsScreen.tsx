// Supplier's own Government Tender listings (materials + trucks). Separate
// from the normal marketplace materials/trucks screens — see task spec:
// tender listings are an additional section, not a replacement.

import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, PrimaryButton, formatINR } from '../../components/Primitives';
import TenderDisclaimer from '../../components/TenderDisclaimer';
import { type, spacing } from '../../theme/theme';
import { sampleTenderMaterials, sampleTenderTrucks } from '../../data/sampleTenderData';
import { VEHICLE_CATEGORIES, CAPACITY_BRACKETS, labelFor } from '../../data/truckOptions';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierTenderListings'>;

export default function SupplierTenderListingsScreen({ navigation }: Props) {
  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.sm }]}>Government Tender listings</Text>
        <TenderDisclaimer />

        <Text style={[type.h2, { marginBottom: spacing.sm }]}>Materials</Text>
        {sampleTenderMaterials.map((m) => (
          <Card key={m.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.h3}>{m.materialName}</Text>
              <Chip label={m.verificationStatus} tone={m.verificationStatus === 'APPROVED' ? 'success' : 'warning'} />
            </View>
            <Text style={type.caption}>{m.quantity} {m.unit} · {formatINR(m.rate)}/{m.unit} · {m.supplyLocation}</Text>
          </Card>
        ))}
        <PrimaryButton title="+ Add tender material" onPress={() => navigation.navigate('SupplierTenderMaterialEdit')} />

        <Text style={[type.h2, { marginTop: spacing.lg, marginBottom: spacing.sm }]}>Trucks</Text>
        {sampleTenderTrucks.map((t) => (
          <Card key={t.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.h3}>{labelFor(VEHICLE_CATEGORIES, t.vehicleCategory)}</Text>
              <Chip label={t.verificationStatus} tone={t.verificationStatus === 'APPROVED' ? 'success' : 'warning'} />
            </View>
            <Text style={type.caption}>{t.registrationNumber} · {labelFor(CAPACITY_BRACKETS, t.capacityBracket)}</Text>
            <Text style={type.caption}>{formatINR(t.ratePerTrip)}/trip · {formatINR(t.ratePerKm)}/km</Text>
          </Card>
        ))}
        <PrimaryButton title="+ Add tender truck" onPress={() => navigation.navigate('SupplierTenderTruckEdit')} />
      </ScrollView>
    </ScreenContainer>
  );
}
