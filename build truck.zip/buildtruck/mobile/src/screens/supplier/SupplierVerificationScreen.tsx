import React, { useCallback, useState } from 'react';
import { ScrollView, Text, TextInput, View, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { ScreenContainer, Card, Chip, PrimaryButton, EmptyState } from '../../components/Primitives';
import { type, spacing } from '../../theme/theme';
import { getMySupplierProfile, getVerificationDocuments, uploadVerificationDocument, VerificationDocument } from '../../api/client';

const TONE: Record<string, 'success' | 'warning' | 'danger' | 'default'> = { VERIFIED: 'success', PENDING: 'warning', REJECTED: 'danger', EXPIRED: 'danger' };

export default function SupplierVerificationScreen() {
  const [supplierId, setSupplierId] = useState<string | null>(null);
  const [docs, setDocs] = useState<VerificationDocument[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [docType, setDocType] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [expiry, setExpiry] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      const profile = await getMySupplierProfile();
      setSupplierId(profile.id);
      const { results } = await getVerificationDocuments('SUPPLIER', profile.id);
      setDocs(results); setError(null);
    } catch (err) { setError((err as Error).message || 'Could not load documents — backend not reachable.'); }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function upload() {
    if (!supplierId || !docType || !fileUrl) { Alert.alert('Missing fields', 'Document type and file URL are required.'); return; }
    setSaving(true);
    try {
      await uploadVerificationDocument('SUPPLIER', supplierId, docType, fileUrl, expiry || undefined);
      setDocType(''); setFileUrl(''); setExpiry('');
      await load();
    } catch (err) { Alert.alert('Could not upload', (err as Error).message); }
    finally { setSaving(false); }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>Verification</Text>
        <Text style={[type.caption, { marginBottom: spacing.md }]}>A Verified badge is shown to customers only after an admin approves your documents.</Text>
        <Card>
          <Text style={type.h3}>Add a document</Text>
          <TextInput value={docType} onChangeText={setDocType} placeholder="Type (pan, gstin, bank_details...)" autoCapitalize="none" style={{ fontSize: 15, paddingVertical: 8 }} />
          <TextInput value={fileUrl} onChangeText={setFileUrl} placeholder="File URL (needs cloud storage config)" autoCapitalize="none" style={{ fontSize: 15, paddingVertical: 8 }} />
          <TextInput value={expiry} onChangeText={setExpiry} placeholder="Expiry date YYYY-MM-DD (optional)" style={{ fontSize: 15, paddingVertical: 8 }} />
          <PrimaryButton title="Upload" onPress={upload} loading={saving} />
        </Card>
        {error ? <EmptyState message={error} /> : docs.map((d) => (
          <Card key={d.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.h3}>{d.doc_type}</Text>
              <Chip label={d.status} tone={TONE[d.status] ?? 'default'} />
            </View>
            {!!d.expiry_date && <Text style={type.caption}>Expires {d.expiry_date}</Text>}
          </Card>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
