// Earnings, completed orders, pending commission, settlement history —
// mirrors the commission_ledger / settlements tables. Real implementation:
// GET /supplier/ledger (not yet built — see backend README), which reads
// commission_ledger + settlements. "Settle now" would call a future
// POST /supplier/settlements endpoint that hands off to the payment
// gateway for a UPI payment to the platform.

import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { ScreenContainer, Card, PriceRow, PrimaryButton, Chip, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { supplierEarningsSummary, sampleSupplierOrders } from '../../data/sampleSupplierData';

const completedOrders = sampleSupplierOrders.filter((o) => o.status === 'COMPLETED');

export default function SupplierEarningsScreen() {
  const s = supplierEarningsSummary;
  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>Earnings & settlements</Text>

        <Card>
          <PriceRow label="Total earnings this month" value={formatINR(s.totalEarningsThisMonth)} bold />
          <PriceRow label="Pending platform commission" value={formatINR(s.pendingCommission)} muted />
        </Card>

        <Card style={{ borderColor: colors.warning }}>
          <Text style={type.h3}>About your pending commission</Text>
          <Text style={type.caption}>
            This is commission owed to BuildTruck on completed Cash orders, where the customer paid
            you directly. It is NOT money the platform is holding — it's a balance you settle
            periodically via UPI, or an admin records it as settled manually.
          </Text>
          <View style={{ height: spacing.sm }} />
          <PrimaryButton title={`Settle ${formatINR(s.pendingCommission)} now`} onPress={() => {}} />
        </Card>

        <Text style={[type.h2, { marginTop: spacing.md, marginBottom: spacing.sm }]}>Completed orders</Text>
        {completedOrders.map((o) => (
          <Card key={o.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.h3}>#{o.orderNumber}</Text>
              <Chip label={o.paymentMethod} />
            </View>
            <Text style={type.caption}>{o.materialSummary}</Text>
            <PriceRow label="Order total" value={formatINR(o.total)} />
            <PriceRow label="Commission (5%)" value={formatINR(Math.round(o.total * 0.05))} muted />
          </Card>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
