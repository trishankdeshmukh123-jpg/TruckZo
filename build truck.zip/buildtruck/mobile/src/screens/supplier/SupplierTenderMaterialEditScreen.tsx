import React, { useState } from 'react';
import { ScrollView, Text, TextInput, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import TenderDisclaimer from '../../components/TenderDisclaimer';
import { type, spacing } from '../../theme/theme';
import { createTenderMaterial, getMySupplierProfile } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierTenderMaterialEdit'>;

export default function SupplierTenderMaterialEditScreen({ navigation }: Props) {
  const [materialName, setMaterialName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState('ton');
  const [rate, setRate] = useState('');
  const [supplyLocation, setSupplyLocation] = useState('');
  const [serviceArea, setServiceArea] = useState('');
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!materialName || !quantity || !rate || !supplyLocation) {
      Alert.alert('Missing fields', 'Material name, quantity, rate and supply location are required.');
      return;
    }
    setSaving(true);
    try {
      const profile = await getMySupplierProfile();
      await createTenderMaterial({
        supplierId: profile.id, materialName, quantity: Number(quantity), unit, rate: Number(rate),
        supplyLocation, serviceArea: serviceArea || undefined,
      });
      Alert.alert('Submitted', 'Listed for admin verification before it appears in tender search.');
      navigation.goBack();
    } catch (err) {
      Alert.alert('Could not submit', (err as Error).message || 'Make sure you are registered as a supplier and the backend is reachable.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.sm }]}>Add tender material</Text>
        <TenderDisclaimer />

        <Card>
          <Text style={type.caption}>Material name / category</Text>
          <TextInput value={materialName} onChangeText={setMaterialName} placeholder="e.g. River Sand" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Quantity</Text>
          <TextInput value={quantity} onChangeText={setQuantity} keyboardType="numeric" placeholder="5000" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Unit</Text>
          <TextInput value={unit} onChangeText={setUnit} placeholder="ton / bag / brick" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Rate (₹ per unit)</Text>
          <TextInput value={rate} onChangeText={setRate} keyboardType="numeric" placeholder="1350" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Supply location</Text>
          <TextInput value={supplyLocation} onChangeText={setSupplyLocation} placeholder="Nashik, Maharashtra" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Service area</Text>
          <TextInput value={serviceArea} onChangeText={setServiceArea} placeholder="Nashik district" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <PrimaryButton title="Submit for verification" onPress={save} loading={saving} />
      </ScrollView>
    </ScreenContainer>
  );
}
