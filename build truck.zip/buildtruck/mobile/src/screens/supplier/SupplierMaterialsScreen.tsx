import React, { useState } from 'react';
import { FlatList, Text, TouchableOpacity, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, PrimaryButton, formatINR } from '../../components/Primitives';
import { type, spacing } from '../../theme/theme';
import { sampleSupplierMaterials } from '../../data/sampleSupplierData';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierMaterials'>;

export default function SupplierMaterialsScreen({ navigation }: Props) {
  const [materials] = useState(sampleSupplierMaterials);
  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>My materials</Text>
      <FlatList
        data={materials}
        keyExtractor={(m) => m.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('SupplierMaterialEdit', { materialId: item.id })}>
            <Card>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={type.h3}>{item.name}</Text>
                <Chip label={item.isActive ? 'Active' : 'Inactive'} tone={item.isActive ? 'success' : 'warning'} />
              </View>
              <Text style={type.caption}>{item.category}</Text>
              <Text style={[type.price, { marginTop: 4 }]}>{formatINR(item.price)} / {item.unit}</Text>
              <Text style={type.caption}>{item.availableQuantity} {item.unit} available</Text>
            </Card>
          </TouchableOpacity>
        )}
      />
      <PrimaryButton title="+ Add material" onPress={() => navigation.navigate('SupplierMaterialEdit', {})} />
    </ScreenContainer>
  );
}
