import React, { useEffect, useState } from 'react';
import { ScrollView, Text, TextInput, Alert, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, EmptyState } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getRfq, submitRfqQuote, getMySupplierProfile, RfqRecord } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierRfqQuote'>;

export default function SupplierRfqQuoteScreen({ route, navigation }: Props) {
  const { rfqId } = route.params;
  const [rfq, setRfq] = useState<RfqRecord | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [price, setPrice] = useState('');
  const [qty, setQty] = useState('');
  const [days, setDays] = useState('');
  const [transport, setTransport] = useState('');
  const [tax, setTax] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try { setRfq(await getRfq(rfqId)); } catch (err) { setError((err as Error).message || 'Could not load RFQ.'); }
    })();
  }, [rfqId]);

  async function submit() {
    if (!price || !qty) { Alert.alert('Missing fields', 'Rate and available quantity are required.'); return; }
    setSaving(true);
    try {
      const profile = await getMySupplierProfile();
      await submitRfqQuote(rfqId, {
        supplierId: profile.id, pricePerUnit: Number(price), availableQuantity: Number(qty),
        deliveryTimeDays: days ? Number(days) : undefined, transportCost: transport ? Number(transport) : undefined,
        taxPercent: tax ? Number(tax) : undefined, notes: notes || undefined,
      });
      Alert.alert('Quote submitted', 'The customer has been notified.');
      navigation.goBack();
    } catch (err) {
      Alert.alert('Could not submit quote', (err as Error).message);
    } finally { setSaving(false); }
  }

  if (error) return <ScreenContainer><EmptyState message={error} /></ScreenContainer>;
  if (!rfq) return <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.primary} /></ScreenContainer>;

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>{rfq.material_name}</Text>
        <Text style={[type.caption, { marginBottom: spacing.md }]}>{rfq.quantity} {rfq.unit} · {rfq.delivery_location}</Text>
        <Card>
          <Text style={type.caption}>Rate per unit (₹)</Text>
          <TextInput value={price} onChangeText={setPrice} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Available quantity</Text>
          <TextInput value={qty} onChangeText={setQty} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Delivery time (days)</Text>
          <TextInput value={days} onChangeText={setDays} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Transport cost (₹)</Text>
          <TextInput value={transport} onChangeText={setTransport} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>GST / tax (%)</Text>
          <TextInput value={tax} onChangeText={setTax} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Notes</Text>
          <TextInput value={notes} onChangeText={setNotes} multiline style={{ fontSize: 15, paddingVertical: 8, minHeight: 60, textAlignVertical: 'top' }} />
        </Card>
        <PrimaryButton title="Submit quote" onPress={submit} loading={saving} />
      </ScrollView>
    </ScreenContainer>
  );
}
