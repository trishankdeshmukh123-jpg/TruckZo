import React, { useState } from 'react';
import { ScrollView, Text, TextInput, View, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import TenderDisclaimer from '../../components/TenderDisclaimer';
import { type, spacing } from '../../theme/theme';
import { VEHICLE_CATEGORIES, CAPACITY_BRACKETS } from '../../data/truckOptions';
import OptionChips from '../../components/OptionChips';
import { createTenderTruck, getMySupplierProfile } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierTenderTruckEdit'>;

export default function SupplierTenderTruckEditScreen({ navigation }: Props) {
  const [regNumber, setRegNumber] = useState('');
  const [category, setCategory] = useState<string | null>(null);
  const [capacityBracket, setCapacityBracket] = useState<string | null>(null);
  const [ratePerTrip, setRatePerTrip] = useState('');
  const [ratePerKm, setRatePerKm] = useState('');
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [vehicleDetails, setVehicleDetails] = useState('');
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!regNumber || !category) {
      Alert.alert('Missing fields', 'Registration number and vehicle category are required.');
      return;
    }
    setSaving(true);
    try {
      const profile = await getMySupplierProfile();
      await createTenderTruck({
        supplierId: profile.id, vehicleCategory: category, capacityBracket: capacityBracket ?? undefined,
        registrationNumber: regNumber, ratePerTrip: ratePerTrip ? Number(ratePerTrip) : undefined,
        ratePerKm: ratePerKm ? Number(ratePerKm) : undefined, driverName, driverPhone, vehicleDetails,
      });
      Alert.alert('Submitted', 'Listed for admin verification before it appears in tender search.');
      navigation.goBack();
    } catch (err) {
      Alert.alert('Could not submit', (err as Error).message || 'Make sure you are registered as a supplier and the backend is reachable.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.sm }]}>Add tender truck</Text>
        <TenderDisclaimer />

        <Card>
          <Text style={type.caption}>Registration number</Text>
          <TextInput value={regNumber} onChangeText={setRegNumber} placeholder="MH20GH3456" autoCapitalize="characters" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>
        <Card>
          <Text style={type.h3}>Vehicle category</Text>
          <View style={{ height: spacing.xs }} />
          <OptionChips options={VEHICLE_CATEGORIES} value={category} onChange={setCategory} />
        </Card>
        <Card>
          <Text style={type.h3}>Capacity</Text>
          <View style={{ height: spacing.xs }} />
          <OptionChips options={CAPACITY_BRACKETS} value={capacityBracket} onChange={setCapacityBracket} allowClear />
        </Card>
        <Card>
          <Text style={type.caption}>Rate per trip (₹)</Text>
          <TextInput value={ratePerTrip} onChangeText={setRatePerTrip} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Rate per km (₹)</Text>
          <TextInput value={ratePerKm} onChangeText={setRatePerKm} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>
        <Card>
          <Text style={type.caption}>Driver name</Text>
          <TextInput value={driverName} onChangeText={setDriverName} style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Driver phone</Text>
          <TextInput value={driverPhone} onChangeText={setDriverPhone} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>
        <Card>
          <Text style={type.caption}>Vehicle details</Text>
          <TextInput value={vehicleDetails} onChangeText={setVehicleDetails} multiline style={{ fontSize: 15, paddingVertical: 8, minHeight: 60, textAlignVertical: 'top' }} />
        </Card>

        <PrimaryButton title="Submit for verification" onPress={save} loading={saving} />
      </ScrollView>
    </ScreenContainer>
  );
}
