import React, { useState } from 'react';
import { ScrollView, Text, TextInput, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import { type, spacing } from '../../theme/theme';
import { submitPod } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierPod'>;

export default function SupplierPodScreen({ route, navigation }: Props) {
  const { orderId, orderNumber, tripId } = route.params;
  const [qty, setQty] = useState('');
  const [shortage, setShortage] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!qty) { Alert.alert('Missing quantity', 'Enter the quantity actually delivered.'); return; }
    setSaving(true);
    try {
      await submitPod(orderId, {
        tripId, deliveredQuantity: Number(qty), shortageNotes: shortage || undefined,
        photoUrls: photoUrl ? [photoUrl] : [],
      });
      Alert.alert('POD recorded', 'The customer has been notified.');
      navigation.goBack();
    } catch (err) {
      Alert.alert('Could not record POD', (err as Error).message);
    } finally { setSaving(false); }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md }}>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>Proof of delivery — #{orderNumber}</Text>
        <Card>
          <Text style={type.caption}>Delivered quantity</Text>
          <TextInput value={qty} onChangeText={setQty} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Shortage / partial-delivery notes</Text>
          <TextInput value={shortage} onChangeText={setShortage} multiline style={{ fontSize: 15, paddingVertical: 8, minHeight: 60, textAlignVertical: 'top' }} />
          <Text style={type.caption}>Photo URL (upload storage requires cloud storage config)</Text>
          <TextInput value={photoUrl} onChangeText={setPhotoUrl} autoCapitalize="none" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>
        <PrimaryButton title="Record delivery" onPress={submit} loading={saving} />
      </ScrollView>
    </ScreenContainer>
  );
}
