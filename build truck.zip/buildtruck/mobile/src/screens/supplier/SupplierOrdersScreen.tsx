import React, { useCallback, useState } from 'react';
import { FlatList, Text, TouchableOpacity, ActivityIndicator, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getMySupplierProfile, getSupplierOrders, OrderHistoryRecord } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierOrders'>;

const toneFor = (status: string) =>
  status === 'COMPLETED' ? 'success' : status === 'CANCELLED' ? 'danger' : status === 'PENDING' ? 'warning' : 'default';

export default function SupplierOrdersScreen({ navigation }: Props) {
  const [orders, setOrders] = useState<OrderHistoryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(useCallback(() => {
    (async () => {
      setLoading(true);
      try {
        const profile = await getMySupplierProfile();
        const { results } = await getSupplierOrders(profile.id);
        setOrders(results);
        setError(null);
      } catch (err) {
        setError((err as Error).message || 'Could not load orders — make sure you are registered as a supplier and the backend is reachable.');
      } finally {
        setLoading(false);
      }
    })();
  }, []));

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>Orders</Text>
      {loading ? <ActivityIndicator color={colors.primary} /> : error ? <EmptyState message={error} /> : (
        <FlatList
          data={orders}
          keyExtractor={(o) => o.id}
          ListEmptyComponent={<EmptyState message="No orders yet." />}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => navigation.navigate('SupplierOrderDetail', { orderId: item.id })}>
              <Card>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text style={type.h3}>#{item.order_number}</Text>
                  <Chip label={item.status} tone={toneFor(item.status) as any} />
                </View>
                <Text style={type.caption}>{item.customer_name}</Text>
                <Text style={[type.price, { marginTop: 4 }]}>{formatINR(item.total_amount)}</Text>
                <Text style={type.caption}>{item.payment_method} · {new Date(item.created_at).toLocaleDateString()}</Text>
              </Card>
            </TouchableOpacity>
          )}
        />
      )}
    </ScreenContainer>
  );
}
