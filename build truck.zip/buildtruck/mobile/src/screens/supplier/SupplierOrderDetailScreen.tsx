// Accept/reject, update status through the delivery lifecycle, and jump
// into multi-truck trip management / POD submission. Calls the real
// backend for every action — a failed call is shown as a real error, the
// screen never advances local state as if it had succeeded.

import React, { useCallback, useState } from 'react';
import { View, Text, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, SecondaryButton, Chip, EmptyState, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getOrderById, updateOrderStatus, cancelOrder, markOrderMultiTruck } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierOrderDetail'>;

const NEXT_STATUS: Record<string, string | null> = {
  PENDING: 'ACCEPTED', ACCEPTED: 'TRUCK_ASSIGNED', TRUCK_ASSIGNED: 'PICKUP_STARTED',
  PICKUP_STARTED: 'OUT_FOR_DELIVERY', OUT_FOR_DELIVERY: 'ARRIVING',
  ARRIVING: null, // delivery is confirmed by the customer's OTP, or via Submit POD below
  DELIVERED: 'COMPLETED', COMPLETED: null, CANCELLED: null,
};
const ACTION_LABEL: Record<string, string> = {
  ACCEPTED: 'Accept order', TRUCK_ASSIGNED: 'Confirm truck assigned', PICKUP_STARTED: 'Mark pickup started',
  OUT_FOR_DELIVERY: 'Start delivery', COMPLETED: 'Mark completed',
};

export default function SupplierOrderDetailScreen({ route, navigation }: Props) {
  const { orderId } = route.params;
  const [order, setOrder] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [multiTruckQty, setMultiTruckQty] = useState('');

  const load = useCallback(async () => {
    try {
      setOrder(await getOrderById(orderId));
      setError(null);
    } catch (err) {
      setError((err as Error).message || 'Could not load this order — backend not reachable.');
    }
  }, [orderId]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const nextStatus = order ? NEXT_STATUS[order.status] : null;

  async function advance() {
    if (!nextStatus) return;
    setBusy(true);
    try {
      await updateOrderStatus(orderId, nextStatus);
      await load();
    } catch (err) {
      Alert.alert('Could not update order', (err as Error).message || 'Backend not reachable — please try again.');
    } finally {
      setBusy(false);
    }
  }

  async function reject() {
    setBusy(true);
    try {
      await cancelOrder(orderId, 'Rejected by supplier');
      await load();
    } catch (err) {
      Alert.alert('Could not reject order', (err as Error).message || 'Backend not reachable — please try again.');
    } finally {
      setBusy(false);
    }
  }

  async function enableMultiTruck() {
    if (!multiTruckQty) { Alert.alert('Enter total quantity', 'Total quantity across all trips.'); return; }
    setBusy(true);
    try {
      await markOrderMultiTruck(orderId, Number(multiTruckQty));
      await load();
    } catch (err) {
      Alert.alert('Could not enable multi-truck', (err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  if (error) return <ScreenContainer><EmptyState message={error} /></ScreenContainer>;
  if (!order) return <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.primary} /></ScreenContainer>;

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>#{order.order_number}</Text>
        <Chip label={order.status} />

        <Card style={{ marginTop: spacing.md }}>
          <Text style={type.h3}>Order</Text>
          {order.items?.map((it: any) => (
            <Text key={it.id} style={type.body}>{it.quantity} × {it.material_name}</Text>
          ))}
          <Text style={type.caption}>Delivery distance: {order.delivery_distance_km} km</Text>
        </Card>

        <Card>
          <Text style={type.h3}>Payment</Text>
          <Text style={type.body}>{formatINR(Number(order.total_amount))} total · {order.payment_method}</Text>
          {order.payment_method === 'CASH' && (
            <Text style={[type.caption, { color: colors.warning, marginTop: 4 }]}>
              Customer pays you directly. Platform commission on this order will show as a pending
              payable balance in Earnings once completed.
            </Text>
          )}
        </Card>

        {order.status === 'ACCEPTED' && !order.requires_multi_truck && (
          <Card>
            <Text style={type.h3}>Large order? Split into multiple trips</Text>
            <Text style={type.caption}>Enter the total quantity to enable multi-truck tracking for this order.</Text>
            <SecondaryButton title="Enable multi-truck for this order" onPress={enableMultiTruck} />
          </Card>
        )}

        {(order.requires_multi_truck || ['TRUCK_ASSIGNED', 'PICKUP_STARTED', 'OUT_FOR_DELIVERY', 'ARRIVING'].includes(order.status)) && (
          <Card>
            <Text style={type.h3}>Trips & delivery</Text>
            <Text style={type.caption}>Assign trucks, update trip status, and submit proof of delivery.</Text>
            <SecondaryButton title="Manage trips" onPress={() => navigation.navigate('SupplierTrips', { orderId, orderNumber: order.order_number })} />
          </Card>
        )}

        {['ARRIVING', 'DELIVERED'].includes(order.status) && (
          <Card>
            <Text style={type.h3}>Proof of delivery</Text>
            <SecondaryButton title="Submit POD" onPress={() => navigation.navigate('SupplierPod', { orderId, orderNumber: order.order_number })} />
          </Card>
        )}

        {nextStatus && <PrimaryButton title={ACTION_LABEL[nextStatus]} onPress={advance} loading={busy} />}
        {order.status === 'PENDING' && (
          <>
            <View style={{ height: spacing.sm }} />
            <SecondaryButton title="Reject order" onPress={reject} />
          </>
        )}
        {order.status === 'COMPLETED' && (
          <Card>
            <Text style={type.h3}>✅ Order complete</Text>
            <Text style={type.caption}>Commission recorded in your ledger.</Text>
          </Card>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
