import React from 'react';
import { FlatList, Text, TouchableOpacity, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, PrimaryButton, formatINR } from '../../components/Primitives';
import { type, spacing } from '../../theme/theme';
import { sampleSupplierTrucks } from '../../data/sampleSupplierData';
import { VEHICLE_CATEGORIES, CAPACITY_BRACKETS, labelFor } from '../../data/truckOptions';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierTrucks'>;

export default function SupplierTrucksScreen({ navigation }: Props) {
  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>My trucks</Text>
      <FlatList
        data={sampleSupplierTrucks}
        keyExtractor={(t) => t.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('SupplierTruckEdit', { truckId: item.id })}>
            <Card>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={type.h3}>{item.registrationNumber}</Text>
                <Chip label={item.isAvailable ? 'Available' : 'On delivery'} tone={item.isAvailable ? 'success' : 'default'} />
              </View>
              <Text style={type.caption}>
                {labelFor(VEHICLE_CATEGORIES, item.vehicleCategory)} · {labelFor(CAPACITY_BRACKETS, item.capacityBracket)} ({item.capacityTons} ton)
              </Text>
              <Text style={type.caption}>₹{item.ratePerTrip}/trip · ₹{item.ratePerKm}/km</Text>
              <Text style={type.caption}>Driver: {item.driverName} · {item.driverPhone}</Text>
            </Card>
          </TouchableOpacity>
        )}
      />
      <PrimaryButton title="+ Add truck" onPress={() => navigation.navigate('SupplierTruckEdit', {})} />
    </ScreenContainer>
  );
}
