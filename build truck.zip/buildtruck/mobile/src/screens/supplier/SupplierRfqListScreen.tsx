import React, { useCallback, useState } from 'react';
import { FlatList, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getOpenRfqs, RfqRecord } from '../../api/client';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierRfqList'>;

export default function SupplierRfqListScreen({ navigation }: Props) {
  const [rfqs, setRfqs] = useState<RfqRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(useCallback(() => {
    (async () => {
      setLoading(true);
      try {
        const { results } = await getOpenRfqs();
        setRfqs(results); setError(null);
      } catch (err) {
        setError((err as Error).message || 'Could not load RFQs — backend not reachable.');
      } finally { setLoading(false); }
    })();
  }, []));

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>Open requirements (RFQs)</Text>
      {loading ? <ActivityIndicator color={colors.primary} /> : error ? <EmptyState message={error} /> : (
        <FlatList
          data={rfqs}
          keyExtractor={(r) => r.id}
          ListEmptyComponent={<EmptyState message="No open RFQs right now." />}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => navigation.navigate('SupplierRfqQuote', { rfqId: item.id })}>
              <Card>
                <Text style={type.h3}>{item.material_name} · {item.quantity} {item.unit}</Text>
                <Text style={type.caption}>{item.delivery_location}{item.required_delivery_date ? ` · by ${item.required_delivery_date}` : ''}</Text>
                <Chip label={item.status} />
              </Card>
            </TouchableOpacity>
          )}
        />
      )}
    </ScreenContainer>
  );
}
