import React, { useCallback, useState } from 'react';
import { FlatList, Text, View, TextInput, Alert, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { ScreenContainer, Card, Chip, EmptyState, SecondaryButton } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getMySupplierProfile, getInventory, updateInventorySettings, InventoryRow } from '../../api/client';

export default function SupplierInventoryScreen() {
  const [rows, setRows] = useState<InventoryRow[]>([]);
  const [thresholds, setThresholds] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const profile = await getMySupplierProfile();
      const { results } = await getInventory(profile.id);
      setRows(results); setError(null);
    } catch (err) {
      setError((err as Error).message || 'Could not load inventory — backend not reachable.');
    } finally { setLoading(false); }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function saveThreshold(id: string) {
    try {
      await updateInventorySettings(id, thresholds[id] ? Number(thresholds[id]) : undefined);
      await load();
    } catch (err) { Alert.alert('Could not save', (err as Error).message); }
  }

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>Inventory</Text>
      {loading ? <ActivityIndicator color={colors.primary} /> : error ? <EmptyState message={error} /> : (
        <FlatList
          data={rows}
          keyExtractor={(r) => r.id}
          ListEmptyComponent={<EmptyState message="No materials listed yet." />}
          renderItem={({ item }) => (
            <Card>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={type.h3}>{item.material_name}</Text>
                {item.is_low_stock && <Chip label="Low stock" tone="danger" />}
              </View>
              <Text style={type.caption}>
                Available {item.available_quantity} · Reserved {item.reserved_quantity} · Sold {item.sold_quantity} {item.default_unit}
              </Text>
              <TextInput
                value={thresholds[item.id] ?? (item.low_stock_threshold != null ? String(item.low_stock_threshold) : '')}
                onChangeText={(v) => setThresholds((p) => ({ ...p, [item.id]: v }))}
                keyboardType="numeric" placeholder="Low-stock threshold" style={{ fontSize: 15, paddingVertical: 8 }}
              />
              <SecondaryButton title="Save threshold" onPress={() => saveThreshold(item.id)} />
            </Card>
          )}
        />
      )}
    </ScreenContainer>
  );
}
