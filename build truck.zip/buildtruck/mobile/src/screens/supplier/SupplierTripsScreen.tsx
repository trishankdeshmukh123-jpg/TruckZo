// Multi-truck / multi-load order management: create trips, assign a truck +
// driver, and advance each trip's status independently. Real backend calls
// throughout — see routes/trips.ts.

import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View, TextInput, Alert, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SupplierStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, PrimaryButton, SecondaryButton, EmptyState } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getOrderProgress, createOrderTrip, assignTrip, updateTripStatus, TripRecord } from '../../api/client';
import { sampleSupplierTrucks } from '../../data/sampleSupplierData';

type Props = NativeStackScreenProps<SupplierStackParamList, 'SupplierTrips'>;

const NEXT_TRIP_STATUS: Record<string, string | null> = {
  PENDING: 'ASSIGNED', ASSIGNED: 'PICKED_UP', PICKED_UP: 'OUT_FOR_DELIVERY', OUT_FOR_DELIVERY: 'DELIVERED', DELIVERED: null, CANCELLED: null,
};

export default function SupplierTripsScreen({ route }: Props) {
  const { orderId, orderNumber } = route.params;
  const [trips, setTrips] = useState<TripRecord[]>([]);
  const [totalQuantity, setTotalQuantity] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [newTripQty, setNewTripQty] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [assigningTrip, setAssigningTrip] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const progress = await getOrderProgress(orderId);
      setTrips(progress.trips);
      setTotalQuantity(progress.totalQuantity);
      setError(null);
    } catch (err) {
      setError((err as Error).message || 'Could not load trips — backend not reachable.');
    }
  }, [orderId]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function addTrip() {
    if (!newTripQty) { Alert.alert('Enter load quantity', 'How much this trip will carry.'); return; }
    setBusy('add');
    try {
      await createOrderTrip(orderId, trips.length + 1, Number(newTripQty));
      setNewTripQty('');
      await load();
    } catch (err) {
      Alert.alert('Could not add trip', (err as Error).message);
    } finally {
      setBusy(null);
    }
  }

  async function assign(tripId: string, truckId: string, driverName: string, driverPhone: string) {
    setBusy(tripId);
    try {
      await assignTrip(tripId, truckId, driverName, driverPhone);
      setAssigningTrip(null);
      await load();
    } catch (err) {
      Alert.alert('Could not assign truck', (err as Error).message);
    } finally {
      setBusy(null);
    }
  }

  async function advance(tripId: string, status: string) {
    setBusy(tripId);
    try {
      await updateTripStatus(tripId, status);
      await load();
    } catch (err) {
      Alert.alert('Could not update trip', (err as Error).message);
    } finally {
      setBusy(null);
    }
  }

  const delivered = trips.filter((t) => t.status === 'DELIVERED').reduce((s, t) => s + Number(t.load_quantity), 0);

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>Trips — #{orderNumber}</Text>
        {totalQuantity != null && <Text style={[type.caption, { marginBottom: spacing.md }]}>{delivered} / {totalQuantity} delivered · {trips.filter((t) => t.status === 'DELIVERED').length} / {trips.length} trips completed</Text>}

        {error ? <EmptyState message={error} /> : (
          <>
            <Card>
              <Text style={type.h3}>Add a trip</Text>
              <TextInput value={newTripQty} onChangeText={setNewTripQty} keyboardType="numeric" placeholder="Load quantity for this trip" style={{ fontSize: 15, paddingVertical: 8 }} />
              <PrimaryButton title="+ Add trip" onPress={addTrip} loading={busy === 'add'} />
            </Card>

            {trips.map((t) => (
              <Card key={t.id}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text style={type.h3}>Trip #{t.trip_number}</Text>
                  <Chip label={t.status} tone={t.status === 'DELIVERED' ? 'success' : 'default'} />
                </View>
                <Text style={type.caption}>{t.load_quantity} units{t.driver_name ? ` · ${t.driver_name}` : ''}</Text>

                {t.status === 'PENDING' && (
                  assigningTrip === t.id ? (
                    <View>
                      {sampleSupplierTrucks.map((truck) => (
                        <Text
                          key={truck.id}
                          onPress={() => assign(t.id, truck.id, truck.driverName, truck.driverPhone)}
                          style={{ paddingVertical: 8, fontSize: 14, color: colors.secondary }}
                        >
                          {truck.registrationNumber} — {truck.driverName}
                        </Text>
                      ))}
                    </View>
                  ) : (
                    <SecondaryButton title="Assign truck" onPress={() => setAssigningTrip(t.id)} />
                  )
                )}

                {NEXT_TRIP_STATUS[t.status] && t.status !== 'PENDING' && (
                  <PrimaryButton
                    title={`Mark ${NEXT_TRIP_STATUS[t.status]!.replace(/_/g, ' ').toLowerCase()}`}
                    onPress={() => advance(t.id, NEXT_TRIP_STATUS[t.status]!)}
                    loading={busy === t.id}
                  />
                )}
              </Card>
            ))}
            {trips.length === 0 && <EmptyState message="No trips added yet." />}
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
