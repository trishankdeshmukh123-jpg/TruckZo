import React, { useState } from 'react';
import { View, Text, TextInput, Alert } from 'react-native';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import { type, spacing, colors, radius } from '../../theme/theme';
import { useAuth } from '../../context/AuthContext';

export default function LoginScreen({ onOtpSent }: { onOtpSent: (phone: string) => void }) {
  const { requestOtp } = useAuth();
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (phone.replace(/\D/g, '').length !== 10) {
      Alert.alert('Enter a valid number', 'Please enter your 10-digit mobile number.');
      return;
    }
    setLoading(true);
    try {
      await requestOtp(phone);
      onOtpSent(phone);
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScreenContainer style={{ justifyContent: 'center' }}>
      <Text style={{ fontSize: 40, textAlign: 'center', marginBottom: spacing.sm }}>🏗️</Text>
      <Text style={[type.h1, { textAlign: 'center' }]}>BuildTruck</Text>
      <Text style={[type.body, { textAlign: 'center', color: colors.textSecondary, marginBottom: spacing.lg }]}>
        Construction materials, delivered.
      </Text>

      <Card>
        <Text style={type.h3}>Enter your mobile number</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm }}>
          <Text style={{ paddingLeft: 12, fontSize: 15, color: colors.textSecondary }}>+91</Text>
          <TextInput
            value={phone} onChangeText={setPhone} keyboardType="number-pad" maxLength={10}
            placeholder="98765 43210" style={{ flex: 1, padding: 12, fontSize: 15 }}
          />
        </View>
      </Card>
      <PrimaryButton title="Send OTP" onPress={submit} loading={loading} />
    </ScreenContainer>
  );
}
