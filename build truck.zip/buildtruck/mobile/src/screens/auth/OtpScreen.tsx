import React, { useState } from 'react';
import { Text, TextInput, Alert, TouchableOpacity } from 'react-native';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { useAuth } from '../../context/AuthContext';

export default function OtpScreen({ phone, onBack }: { phone: string; onBack: () => void }) {
  const { verifyOtp } = useAuth();
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit() {
    setLoading(true);
    try {
      await verifyOtp(phone, otp, name || undefined);
    } catch (err) {
      Alert.alert('Could not verify', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScreenContainer style={{ justifyContent: 'center' }}>
      <Text style={[type.h1, { textAlign: 'center' }]}>Verify your number</Text>
      <Text style={[type.body, { textAlign: 'center', color: colors.textSecondary, marginBottom: spacing.lg }]}>
        We sent a 6-digit code to +91 {phone}
      </Text>

      <Card>
        <Text style={type.caption}>OTP</Text>
        <TextInput
          value={otp} onChangeText={setOtp} keyboardType="number-pad" maxLength={6}
          placeholder="••••••" style={{ fontSize: 20, letterSpacing: 8, paddingVertical: 8, textAlign: 'center' }}
        />
      </Card>
      <Card>
        <Text style={type.caption}>Your name (first time only)</Text>
        <TextInput value={name} onChangeText={setName} placeholder="Full name" style={{ fontSize: 15, paddingVertical: 8 }} />
      </Card>

      <PrimaryButton title="Verify & continue" onPress={submit} loading={loading} />
      <TouchableOpacity onPress={onBack} style={{ marginTop: spacing.md, alignSelf: 'center' }}>
        <Text style={{ color: colors.secondary, fontWeight: '600' }}>Change number</Text>
      </TouchableOpacity>
    </ScreenContainer>
  );
}
