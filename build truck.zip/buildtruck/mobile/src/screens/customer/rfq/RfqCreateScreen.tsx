// Create an RFQ / bulk requirement. Calls the real POST /rfq — no local
// "saved" fallback: if the backend isn't reachable, the person sees a
// clear error, since a fabricated RFQ id would never actually reach a
// supplier and would be a fake success.

import React, { useState } from 'react';
import { ScrollView, Text, TextInput, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../../navigation/types';
import { ScreenContainer, Card, PrimaryButton } from '../../../components/Primitives';
import { type, spacing } from '../../../theme/theme';
import { createRfq } from '../../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'RfqCreate'>;

export default function RfqCreateScreen({ route, navigation }: Props) {
  const { projectId, projectName } = route.params ?? {};
  const [materialName, setMaterialName] = useState('');
  const [specification, setSpecification] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState('ton');
  const [requiredDate, setRequiredDate] = useState('');
  const [deliveryLocation, setDeliveryLocation] = useState('');
  const [additionalRequirements, setAdditionalRequirements] = useState('');
  const [targetPrice, setTargetPrice] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!materialName || !quantity || !deliveryLocation) {
      Alert.alert('Missing fields', 'Material, quantity and delivery location are required.');
      return;
    }
    setSaving(true);
    try {
      await createRfq({
        materialName, specification: specification || undefined, quantity: Number(quantity), unit,
        requiredDeliveryDate: requiredDate || undefined, deliveryLocation,
        additionalRequirements: additionalRequirements || undefined,
        targetPrice: targetPrice ? Number(targetPrice) : undefined, projectId, projectName,
      });
      Alert.alert('RFQ posted', 'Suppliers can now discover and quote on your requirement.');
      navigation.replace('RfqList');
    } catch (err) {
      Alert.alert('Could not post RFQ', (err as Error).message || 'Backend not reachable — please try again.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.sm }]}>Post a requirement</Text>
        {!!projectName && <Text style={[type.caption, { marginBottom: spacing.sm }]}>Linked to project: {projectName}</Text>}

        <Card>
          <Text style={type.caption}>Material</Text>
          <TextInput value={materialName} onChangeText={setMaterialName} placeholder="e.g. Gitti / Aggregate" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Specification (grade/size)</Text>
          <TextInput value={specification} onChangeText={setSpecification} placeholder="e.g. 20mm size" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Quantity</Text>
          <TextInput value={quantity} onChangeText={setQuantity} keyboardType="numeric" placeholder="500" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Unit</Text>
          <TextInput value={unit} onChangeText={setUnit} placeholder="ton / bag / brick" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <Card>
          <Text style={type.caption}>Required delivery date (YYYY-MM-DD)</Text>
          <TextInput value={requiredDate} onChangeText={setRequiredDate} placeholder="2026-10-15" style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={type.caption}>Delivery location</Text>
          <TextInput value={deliveryLocation} onChangeText={setDeliveryLocation} placeholder="Nagpur, Maharashtra" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <Card>
          <Text style={type.caption}>Additional requirements</Text>
          <TextInput value={additionalRequirements} onChangeText={setAdditionalRequirements} multiline placeholder="Anything else suppliers should know" style={{ fontSize: 15, paddingVertical: 8, minHeight: 70, textAlignVertical: 'top' }} />
          <Text style={type.caption}>Target price (optional, ₹ per unit)</Text>
          <TextInput value={targetPrice} onChangeText={setTargetPrice} keyboardType="numeric" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <PrimaryButton title="Post requirement" onPress={submit} loading={saving} />
      </ScrollView>
    </ScreenContainer>
  );
}
