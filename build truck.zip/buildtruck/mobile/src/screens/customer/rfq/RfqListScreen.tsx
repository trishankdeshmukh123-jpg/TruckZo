import React, { useEffect, useState, useCallback } from 'react';
import { FlatList, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState, PrimaryButton } from '../../../components/Primitives';
import { type, spacing, colors } from '../../../theme/theme';
import { getMyRfqs, RfqRecord } from '../../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'RfqList'>;

const TONE: Record<string, 'success' | 'warning' | 'danger' | 'default'> = {
  AWARDED: 'success', COMPLETED: 'success', CANCELLED: 'danger', EXPIRED: 'danger',
  OPEN: 'warning', QUOTED: 'warning', SHORTLISTED: 'default', DRAFT: 'default',
};

export default function RfqListScreen({ navigation }: Props) {
  const [rfqs, setRfqs] = useState<RfqRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { results } = await getMyRfqs();
      setRfqs(results);
      setError(null);
    } catch (err) {
      setError((err as Error).message || 'Could not load your RFQs — backend not reachable.');
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>My requirements</Text>
      <PrimaryButton title="+ Post a new requirement" onPress={() => navigation.navigate('RfqCreate')} />
      {loading ? (
        <ActivityIndicator color={colors.primary} style={{ marginTop: spacing.md }} />
      ) : error ? (
        <EmptyState message={error} />
      ) : (
        <FlatList
          data={rfqs}
          keyExtractor={(r) => r.id}
          ListEmptyComponent={<EmptyState message="You haven't posted any requirements yet." />}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => navigation.navigate('RfqDetail', { rfqId: item.id })}>
              <Card>
                <Text style={type.h3}>{item.material_name} · {item.quantity} {item.unit}</Text>
                <Text style={type.caption}>{item.delivery_location}</Text>
                <Chip label={`${item.status}${item.quote_count ? ` · ${item.quote_count} quotes` : ''}`} tone={TONE[item.status] ?? 'default'} />
              </Card>
            </TouchableOpacity>
          )}
        />
      )}
    </ScreenContainer>
  );
}
