// Compare supplier quotations transparently — price, rating, verification,
// distance, delivery time — and award one. No hidden ranking/winner logic:
// every quote is shown, sorted only by price, per the task's "transparent
// comparison" requirement.

import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View, ActivityIndicator, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../../navigation/types';
import { ScreenContainer, Card, Chip, PrimaryButton, EmptyState, formatINR } from '../../../components/Primitives';
import { type, spacing, colors } from '../../../theme/theme';
import { getRfq, getRfqQuotes, awardRfqQuote, RfqRecord, RfqQuoteRecord } from '../../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'RfqDetail'>;

export default function RfqDetailScreen({ route }: Props) {
  const { rfqId } = route.params;
  const [rfq, setRfq] = useState<RfqRecord | null>(null);
  const [quotes, setQuotes] = useState<RfqQuoteRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [awarding, setAwarding] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [rfqData, quotesData] = await Promise.all([getRfq(rfqId), getRfqQuotes(rfqId)]);
      setRfq(rfqData);
      setQuotes(quotesData.results.sort((a, b) => a.price_per_unit - b.price_per_unit));
      setError(null);
    } catch (err) {
      setError((err as Error).message || 'Could not load this RFQ — backend not reachable.');
    } finally {
      setLoading(false);
    }
  }, [rfqId]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function award(quoteId: string) {
    setAwarding(quoteId);
    try {
      await awardRfqQuote(rfqId, quoteId);
      Alert.alert('Quote awarded', 'The supplier has been notified. Place your order with them to proceed.');
      load();
    } catch (err) {
      Alert.alert('Could not award', (err as Error).message);
    } finally {
      setAwarding(null);
    }
  }

  if (loading) return <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.primary} /></ScreenContainer>;
  if (error || !rfq) return <ScreenContainer><EmptyState message={error ?? 'RFQ not found.'} /></ScreenContainer>;

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>{rfq.material_name}</Text>
        <Chip label={rfq.status} />
        <Card style={{ marginTop: spacing.md }}>
          <Text style={type.body}>{rfq.quantity} {rfq.unit} · {rfq.specification || 'No specification given'}</Text>
          <Text style={type.caption}>Delivery to {rfq.delivery_location}</Text>
          {!!rfq.required_delivery_date && <Text style={type.caption}>Required by {rfq.required_delivery_date}</Text>}
          {rfq.target_price != null && <Text style={type.caption}>Target price: {formatINR(rfq.target_price)}</Text>}
        </Card>

        <Text style={[type.h2, { marginTop: spacing.md, marginBottom: spacing.sm }]}>
          {quotes.length} quote{quotes.length !== 1 ? 's' : ''}
        </Text>
        {quotes.length === 0 ? (
          <EmptyState message="No quotes yet — suppliers are notified when they discover this RFQ." />
        ) : quotes.map((q) => (
          <Card key={q.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.h3}>{q.business_name}</Text>
              <Chip label={q.status} tone={q.status === 'AWARDED' ? 'success' : q.status === 'REJECTED' ? 'danger' : 'default'} />
            </View>
            <Text style={type.caption}>
              ⭐ {q.rating_avg} ({q.rating_count}) · {q.verification_status === 'APPROVED' ? 'Verified' : 'Unverified'}
            </Text>
            <Text style={[type.price, { marginTop: spacing.xs }]}>{formatINR(q.price_per_unit)}/unit</Text>
            <Text style={type.caption}>
              {q.available_quantity} available
              {q.delivery_time_days != null ? ` · ${q.delivery_time_days} day delivery` : ''}
              {q.transport_cost ? ` · +${formatINR(q.transport_cost)} transport` : ''}
            </Text>
            {!!q.notes && <Text style={type.caption}>"{q.notes}"</Text>}
            {rfq.status !== 'AWARDED' && q.status === 'SUBMITTED' && (
              <PrimaryButton title="Award this quote" onPress={() => award(q.id)} loading={awarding === q.id} />
            )}
          </Card>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
