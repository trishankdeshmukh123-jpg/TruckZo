import React, { useCallback, useState } from 'react';
import { FlatList, Text, TouchableOpacity, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getMyOrders, OrderHistoryRecord } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'OrderHistory'>;

const TONE: Record<string, 'success' | 'warning' | 'danger' | 'default'> = {
  COMPLETED: 'success', CANCELLED: 'danger', REFUNDED: 'danger', PENDING: 'warning',
};

export default function OrderHistoryScreen({ navigation }: Props) {
  const [orders, setOrders] = useState<OrderHistoryRecord[]>([]);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(useCallback(() => {
    (async () => {
      try {
        const { results } = await getMyOrders();
        setOrders(results);
        setError(null);
      } catch (err) {
        setError((err as Error).message || 'Could not load order history — backend not reachable.');
      }
    })();
  }, []));

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>Order history</Text>
      {error ? <EmptyState message={error} /> : (
        <FlatList
          data={orders}
          keyExtractor={(o) => o.id}
          ListEmptyComponent={<EmptyState message="No past orders yet." />}
          renderItem={({ item }) => (
            <Card>
              <TouchableOpacity onPress={() => navigation.navigate('OrderTracking', { orderId: item.id, orderNumber: item.order_number })}>
                <Text style={type.h3}>#{item.order_number}</Text>
                <Text style={type.caption}>{item.supplier_name}</Text>
                <Text style={[type.price, { marginTop: 4 }]}>{formatINR(item.total_amount)}</Text>
                <Chip label={item.status} tone={TONE[item.status] ?? 'default'} />
              </TouchableOpacity>
              <View style={{ flexDirection: 'row', gap: spacing.md, marginTop: spacing.sm }}>
                {item.status === 'COMPLETED' && (
                  <Text onPress={() => navigation.navigate('Invoice', { orderId: item.id })} style={{ color: colors.secondary, fontWeight: '600', fontSize: 13 }}>
                    View invoice
                  </Text>
                )}
                <Text onPress={() => navigation.navigate('DisputeCreate', { orderId: item.id, orderNumber: item.order_number })} style={{ color: colors.danger, fontWeight: '600', fontSize: 13 }}>
                  Report an issue
                </Text>
              </View>
            </Card>
          )}
        />
      )}
    </ScreenContainer>
  );
}
