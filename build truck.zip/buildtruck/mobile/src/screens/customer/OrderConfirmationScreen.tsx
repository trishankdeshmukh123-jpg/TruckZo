import React from 'react';
import { View, Text } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';

type Props = NativeStackScreenProps<CustomerStackParamList, 'OrderConfirmation'>;

export default function OrderConfirmationScreen({ route, navigation }: Props) {
  const { orderNumber, orderId, totalAmount, paymentMethod, originLat, originLng, destLat, destLng } = route.params;

  return (
    <ScreenContainer style={{ justifyContent: 'center' }}>
      <View style={{ alignItems: 'center', marginBottom: spacing.lg }}>
        <Text style={{ fontSize: 56 }}>✅</Text>
        <Text style={[type.h1, { marginTop: spacing.sm }]}>Order placed!</Text>
        <Text style={type.caption}>Order #{orderNumber}</Text>
      </View>

      <Card>
        <Text style={type.h3}>Total amount</Text>
        <Text style={[type.price, { fontSize: 24, marginTop: 4 }]}>{formatINR(totalAmount)}</Text>
        <Text style={type.caption}>
          {paymentMethod === 'UPI' ? 'Paid via UPI' : 'To be paid in cash on delivery'}
        </Text>
      </Card>

      <Text style={[type.body, { color: colors.textSecondary, marginBottom: spacing.md }]}>
        The supplier has been notified and will confirm your order shortly. You'll get a delivery
        OTP once the truck is arriving — keep it ready to confirm delivery.
      </Text>

      <PrimaryButton
        title="Track my order"
        onPress={() => navigation.replace('OrderTracking', { orderId, orderNumber, originLat, originLng, destLat, destLng })}
      />
    </ScreenContainer>
  );
}
