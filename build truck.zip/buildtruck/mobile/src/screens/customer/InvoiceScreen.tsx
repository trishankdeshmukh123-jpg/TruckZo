import React, { useCallback, useState } from 'react';
import { ScrollView, Text, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PriceRow, EmptyState, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getInvoiceForOrder, InvoiceRecord } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'Invoice'>;

export default function InvoiceScreen({ route }: Props) {
  const [invoice, setInvoice] = useState<InvoiceRecord | null>(null);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(useCallback(() => {
    (async () => {
      try {
        setInvoice(await getInvoiceForOrder(route.params.orderId));
        setError(null);
      } catch (err) {
        setError((err as Error).message || 'Invoice not available yet — it is generated once the order is completed.');
      }
    })();
  }, [route.params.orderId]));

  if (error) return <ScreenContainer><EmptyState message={error} /></ScreenContainer>;
  if (!invoice) return <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.primary} /></ScreenContainer>;

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>Invoice</Text>
        <Text style={[type.caption, { marginBottom: spacing.md }]}>{invoice.invoice_number} · {new Date(invoice.generated_at).toLocaleDateString()}</Text>

        <Card>
          <PriceRow label="Material charges" value={formatINR(invoice.material_charges)} />
          <PriceRow label="Delivery charges" value={formatINR(invoice.delivery_charges)} />
          <PriceRow label="Platform charges" value={formatINR(invoice.platform_charges)} />
          {invoice.discount_amount > 0 && <PriceRow label="Discount" value={`-${formatINR(invoice.discount_amount)}`} />}
          {invoice.tax_amount > 0 && <PriceRow label="Tax" value={formatINR(invoice.tax_amount)} />}
          <PriceRow label="Total" value={formatINR(invoice.total_amount)} bold />
        </Card>

        {invoice.gst_number && (
          <Card><Text style={type.caption}>Supplier GSTIN: {invoice.gst_number}</Text></Card>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
