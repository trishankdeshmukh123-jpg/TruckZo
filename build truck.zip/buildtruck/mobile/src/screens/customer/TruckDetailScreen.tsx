import React, { useState } from 'react';
import { ScrollView, Text, View, TextInput, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, PrimaryButton } from '../../components/Primitives';
import { type, spacing } from '../../theme/theme';
import { VEHICLE_CATEGORIES, CAPACITY_BRACKETS, labelFor } from '../../data/truckOptions';
import { requestTruckHire } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'TruckDetail'>;

export default function TruckDetailScreen({ route }: Props) {
  const { truck } = route.params;
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  async function sendRequest() {
    setSending(true);
    try {
      await requestTruckHire(truck.id, message || 'Interested in hiring this truck.');
      setSent(true);
    } catch (err) {
      Alert.alert('Could not send request', (err as Error).message || 'Backend not reachable — please try again.');
    } finally {
      setSending(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>{labelFor(VEHICLE_CATEGORIES, truck.vehicleCategory)}</Text>
        <Chip label={truck.isAvailable ? 'Available' : 'Busy'} tone={truck.isAvailable ? 'success' : 'warning'} />

        <Card style={{ marginTop: spacing.md }}>
          <Text style={type.h3}>Vehicle</Text>
          <Text style={type.body}>{truck.registrationNumber}</Text>
          <Text style={type.caption}>{labelFor(CAPACITY_BRACKETS, truck.capacityBracket)}{truck.capacityTons ? ` (${truck.capacityTons} ton)` : ''}</Text>
          {!!truck.vehicleDetails && <Text style={type.caption}>{truck.vehicleDetails}</Text>}
        </Card>

        <Card>
          <Text style={type.h3}>Owner</Text>
          <Text style={type.body}>{truck.supplierName}</Text>
          <Text style={type.caption}>⭐ {truck.rating} ({truck.ratingCount}){truck.distanceKm != null ? ` · ${truck.distanceKm} km away` : ''}</Text>
        </Card>

        <Card>
          <Text style={type.h3}>Rates</Text>
          {truck.ratePerTrip != null && <Text style={type.price}>₹{truck.ratePerTrip} / trip</Text>}
          {truck.ratePerKm != null && <Text style={type.body}>₹{truck.ratePerKm} / km</Text>}
        </Card>

        {truck.driverName && (
          <Card>
            <Text style={type.h3}>Driver</Text>
            <Text style={type.body}>{truck.driverName} · {truck.driverPhone}</Text>
          </Card>
        )}

        <Card>
          <Text style={type.h3}>Send a request</Text>
          <Text style={type.caption}>Describe what you need — the supplier will contact you to confirm.</Text>
          <TextInput
            value={message} onChangeText={setMessage} multiline placeholder="e.g. Need this truck for 3 trips next Tuesday from Andheri to Thane"
            style={{ fontSize: 15, paddingVertical: 8, minHeight: 70, textAlignVertical: 'top' }}
          />
          {sent ? (
            <Text style={{ color: '#2E7D4F', fontWeight: '600', marginTop: spacing.sm }}>✅ Request sent — the supplier will contact you.</Text>
          ) : (
            <PrimaryButton title="Send request" onPress={sendRequest} loading={sending} />
          )}
        </Card>
      </ScrollView>
    </ScreenContainer>
  );
}
