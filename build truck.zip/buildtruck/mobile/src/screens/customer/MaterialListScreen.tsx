// Materials within a chosen category, live from GET /materials?categoryId=
// with sample fallback. Tapping a material moves to Supplier Selection.

import React, { useEffect, useState } from 'react';
import { FlatList, TouchableOpacity, Text, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState } from '../../components/Primitives';
import { sampleMaterials } from '../../data/sampleData';
import { Material } from '../../types/domain';
import { type, spacing, colors } from '../../theme/theme';
import { getMaterials } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'MaterialList'>;

export default function MaterialListScreen({ route, navigation }: Props) {
  const { categoryId, categoryName } = route.params;
  const [materials, setMaterials] = useState<Material[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { results } = await getMaterials(categoryId);
        setMaterials(results.map((m) => ({ id: m.id, categoryId: m.category_id, name: m.name, unit: m.default_unit, description: m.description ?? '' })));
      } catch {
        setMaterials(sampleMaterials.filter((m) => m.categoryId === categoryId));
      } finally {
        setLoading(false);
      }
    })();
  }, [categoryId]);

  if (loading) {
    return <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.primary} /></ScreenContainer>;
  }

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.xs }]}>{categoryName}</Text>
      <Text style={[type.caption, { marginBottom: spacing.md }]}>{materials.length} materials available</Text>
      <FlatList
        data={materials}
        keyExtractor={(m) => m.id}
        ListEmptyComponent={<EmptyState message="No materials listed in this category yet." />}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('SupplierSelection', { materialId: item.id, materialName: item.name })}>
            <Card>
              <Text style={type.h3}>{item.name}</Text>
              <Text style={[type.caption, { marginVertical: 4 }]}>{item.description}</Text>
              <Chip label={`per ${item.unit}`} />
            </Card>
          </TouchableOpacity>
        )}
      />
    </ScreenContainer>
  );
}
