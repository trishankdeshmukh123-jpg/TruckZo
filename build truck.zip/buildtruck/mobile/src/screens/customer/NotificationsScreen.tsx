import React, { useCallback, useState } from 'react';
import { FlatList, Text, TouchableOpacity, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { ScreenContainer, Card, EmptyState, SecondaryButton } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getNotifications, markNotificationRead, markAllNotificationsRead, NotificationRecord } from '../../api/client';

export default function NotificationsScreen() {
  const [items, setItems] = useState<NotificationRecord[]>([]);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const { results } = await getNotifications();
      setItems(results);
      setError(null);
    } catch (err) {
      setError((err as Error).message || 'Could not load notifications — backend not reachable.');
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function onRead(id: string) {
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
    try { await markNotificationRead(id); } catch { /* will re-sync next load */ }
  }

  async function onReadAll() {
    setItems((prev) => prev.map((n) => ({ ...n, is_read: true })));
    try { await markAllNotificationsRead(); } catch { /* will re-sync next load */ }
  }

  return (
    <ScreenContainer>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md }}>
        <Text style={type.h1}>Notifications</Text>
        {items.some((n) => !n.is_read) && <SecondaryButton title="Mark all read" onPress={onReadAll} />}
      </View>
      {error ? <EmptyState message={error} /> : (
        <FlatList
          data={items}
          keyExtractor={(n) => n.id}
          ListEmptyComponent={<EmptyState message="No notifications yet." />}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => !item.is_read && onRead(item.id)}>
              <Card style={{ borderColor: item.is_read ? colors.border : colors.primary }}>
                <Text style={type.h3}>{item.title}</Text>
                <Text style={type.caption}>{item.body}</Text>
                <Text style={[type.caption, { color: colors.textSecondary, marginTop: 4 }]}>{new Date(item.created_at).toLocaleString()}</Text>
              </Card>
            </TouchableOpacity>
          )}
        />
      )}
    </ScreenContainer>
  );
}
