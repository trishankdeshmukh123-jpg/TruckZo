import React, { useState } from 'react';
import { Text, TextInput, Alert } from 'react-native';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import { type, spacing } from '../../theme/theme';

export default function SupportScreen() {
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');

  function submit() {
    // Real implementation: POST /support-tickets (not yet built — see
    // backend README). For now, confirms locally so the flow is complete.
    Alert.alert('Ticket submitted', 'Our support team will get back to you within 24 hours.');
    setSubject(''); setDescription('');
  }

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>Raise a complaint</Text>
      <Card>
        <TextInput placeholder="Subject" value={subject} onChangeText={setSubject} style={{ fontSize: 15, paddingVertical: 8 }} />
      </Card>
      <Card>
        <TextInput
          placeholder="Describe the issue"
          value={description} onChangeText={setDescription}
          multiline numberOfLines={5} style={{ fontSize: 15, minHeight: 100, textAlignVertical: 'top' }}
        />
      </Card>
      <PrimaryButton title="Submit" onPress={submit} disabled={!subject || !description} />
    </ScreenContainer>
  );
}
