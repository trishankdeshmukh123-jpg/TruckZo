import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, PriceRow, EmptyState, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { useCart } from '../../context/CartContext';

type Props = NativeStackScreenProps<CustomerStackParamList, 'Cart'>;

export default function CartScreen({ navigation }: Props) {
  const { supplier, items, removeItem, materialCost } = useCart();

  if (!supplier || items.length === 0) {
    return (
      <ScreenContainer>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>Your cart</Text>
        <EmptyState message="Your cart is empty. Browse materials to add items." />
        <PrimaryButton title="Browse materials" onPress={() => navigation.navigate('Home')} />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: 140 }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>Your cart</Text>
        <Text style={[type.caption, { marginBottom: spacing.md }]}>Ordering from {supplier.businessName}</Text>

        {items.map((item) => (
          <Card key={item.offer.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.h3}>{item.material.name}</Text>
              <TouchableOpacity onPress={() => removeItem(item.offer.id)}>
                <Text style={{ color: colors.danger, fontWeight: '600' }}>Remove</Text>
              </TouchableOpacity>
            </View>
            <Text style={type.caption}>{item.quantity} {item.material.unit} × {formatINR(item.offer.pricePerUnit)}</Text>
            <Text style={[type.price, { marginTop: 4 }]}>{formatINR(item.quantity * item.offer.pricePerUnit)}</Text>
          </Card>
        ))}

        <Card>
          <PriceRow label="Material cost" value={formatINR(materialCost)} />
          <Text style={[type.caption, { marginTop: spacing.xs }]}>
            Delivery charge is calculated after you confirm your delivery address.
          </Text>
        </Card>
      </ScrollView>

      <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: spacing.md, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border }}>
        <PrimaryButton title="Proceed to delivery address" onPress={() => navigation.navigate('Address')} />
      </View>
    </ScreenContainer>
  );
}
