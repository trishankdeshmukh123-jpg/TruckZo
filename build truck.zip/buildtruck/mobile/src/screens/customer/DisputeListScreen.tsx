import React, { useCallback, useState } from 'react';
import { FlatList, Text, TouchableOpacity } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState } from '../../components/Primitives';
import { type, spacing } from '../../theme/theme';
import { getMyDisputes, DisputeRecord } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'DisputeList'>;

const TONE: Record<string, 'success' | 'warning' | 'danger' | 'default'> = {
  RESOLVED: 'success', REJECTED: 'danger', CLOSED: 'default', OPEN: 'warning', UNDER_REVIEW: 'warning', WAITING_FOR_INFORMATION: 'warning',
};

export default function DisputeListScreen({ navigation }: Props) {
  const [disputes, setDisputes] = useState<DisputeRecord[]>([]);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(useCallback(() => {
    (async () => {
      try {
        const { results } = await getMyDisputes();
        setDisputes(results);
        setError(null);
      } catch (err) {
        setError((err as Error).message || 'Could not load disputes — backend not reachable.');
      }
    })();
  }, []));

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>My reported issues</Text>
      {error ? <EmptyState message={error} /> : (
        <FlatList
          data={disputes}
          keyExtractor={(d) => d.id}
          ListEmptyComponent={<EmptyState message="No issues reported." />}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => navigation.navigate('DisputeDetail', { disputeId: item.id })}>
              <Card>
                <Text style={type.h3}>{item.issue_type.replace(/_/g, ' ')}</Text>
                <Text style={type.caption} numberOfLines={2}>{item.description}</Text>
                <Chip label={item.status.replace(/_/g, ' ')} tone={TONE[item.status] ?? 'default'} />
              </Card>
            </TouchableOpacity>
          )}
        />
      )}
    </ScreenContainer>
  );
}
