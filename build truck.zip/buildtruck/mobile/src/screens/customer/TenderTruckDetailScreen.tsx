import React, { useState } from 'react';
import { ScrollView, Text, TextInput, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import TenderDisclaimer from '../../components/TenderDisclaimer';
import { type, spacing } from '../../theme/theme';
import { VEHICLE_CATEGORIES, CAPACITY_BRACKETS, labelFor } from '../../data/truckOptions';
import { requestTenderTruck } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'TenderTruckDetail'>;

export default function TenderTruckDetailScreen({ route }: Props) {
  const { truck } = route.params;
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  async function send() {
    setSending(true);
    try {
      await requestTenderTruck(truck.id, message || 'Requirement enquiry');
      setSent(true);
    } catch (err) {
      Alert.alert('Could not send request', (err as Error).message || 'Backend not reachable — please try again.');
    } finally {
      setSending(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.sm }]}>{labelFor(VEHICLE_CATEGORIES, truck.vehicle_category)}</Text>
        <TenderDisclaimer />

        <Card>
          <Text style={type.h3}>Vehicle</Text>
          <Text style={type.body}>{truck.registration_number}</Text>
          <Text style={type.caption}>{labelFor(CAPACITY_BRACKETS, truck.capacity_bracket)}{truck.capacity_tons ? ` (${truck.capacity_tons} ton)` : ''}</Text>
          {!!truck.vehicle_details && <Text style={type.caption}>{truck.vehicle_details}</Text>}
        </Card>

        <Card>
          <Text style={type.h3}>Owner</Text>
          <Text style={type.body}>{truck.supplier_name}</Text>
          {truck.driver_name && <Text style={type.caption}>Driver: {truck.driver_name} · {truck.driver_phone}</Text>}
        </Card>

        <Card>
          <Text style={type.h3}>Rates</Text>
          {truck.rate_per_trip != null && <Text style={type.price}>₹{truck.rate_per_trip} / trip</Text>}
          {truck.rate_per_km != null && <Text style={type.body}>₹{truck.rate_per_km} / km</Text>}
        </Card>

        <Card>
          <Text style={type.h3}>Send your requirement</Text>
          <TextInput value={message} onChangeText={setMessage} multiline placeholder="Project name, number of trips, timeline, etc." style={{ fontSize: 15, paddingVertical: 8, minHeight: 70, textAlignVertical: 'top' }} />
          {sent ? (
            <Text style={{ color: '#2E7D4F', fontWeight: '600', marginTop: spacing.sm }}>✅ Requirement sent to the owner.</Text>
          ) : (
            <PrimaryButton title="Send requirement" onPress={send} loading={sending} />
          )}
        </Card>
      </ScrollView>
    </ScreenContainer>
  );
}
