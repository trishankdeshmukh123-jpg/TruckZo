// Customer Home: location, search, categories, popular materials, nearby
// suppliers, recent orders, plus quick links to standalone Truck Search and
// the Government Tender module. Categories/materials load from the live
// backend catalog when reachable, falling back to bundled sample data.

import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip } from '../../components/Primitives';
import { colors, spacing, type, radius } from '../../theme/theme';
import { sampleCategories, sampleMaterials, sampleSuppliers } from '../../data/sampleData';
import { Category, Material } from '../../types/domain';
import { useAuth } from '../../context/AuthContext';
import { useAppMode } from '../../context/AppModeContext';
import { getCategories, getMaterials } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'Home'>;

export default function HomeScreen({ navigation }: Props) {
  const { user } = useAuth();
  const { canUseSupplierMode, toggleMode } = useAppMode();
  const [search, setSearch] = useState('');
  const [categories, setCategories] = useState<Category[]>(sampleCategories);
  const [popularMaterials, setPopularMaterials] = useState<Material[]>(sampleMaterials.slice(0, 4));
  const [isLive, setIsLive] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [catRes, matRes] = await Promise.all([getCategories(), getMaterials()]);
        setCategories(catRes.results.map((c) => ({ id: c.id, name: c.name, slug: c.slug, icon: iconFor(c.slug) })));
        setPopularMaterials(matRes.results.slice(0, 4).map((m) => ({
          id: m.id, categoryId: m.category_id, name: m.name, unit: m.default_unit, description: m.description ?? '',
        })));
        setIsLive(true);
      } catch {
        // Backend not reachable — keep the sample catalog already in state.
      }
    })();
  }, []);

  function goToMaterial(materialId: string, materialName: string) {
    navigation.navigate('SupplierSelection', { materialId, materialName });
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <TouchableOpacity style={styles.locationRow} onPress={() => navigation.navigate('Address')}>
            <Text style={styles.locationLabel}>📍 Delivering to</Text>
            <Text style={styles.locationValue}>Andheri East, Mumbai · 400069  ›</Text>
          </TouchableOpacity>
          {canUseSupplierMode && (
            <TouchableOpacity onPress={toggleMode} style={{ paddingTop: 4 }}>
              <Text style={{ color: colors.secondary, fontWeight: '600', fontSize: 13 }}>Supplier mode →</Text>
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Notifications')} style={{ alignSelf: 'flex-end', marginTop: 4 }}>
          <Text style={{ color: colors.secondary, fontWeight: '600', fontSize: 13 }}>🔔 Notifications</Text>
        </TouchableOpacity>

        <Text style={[type.h1, { marginTop: spacing.sm }]}>Hi {user?.name?.split(' ')[0] ?? 'there'} 👋</Text>
        <Text style={[type.body, { color: colors.textSecondary, marginBottom: spacing.md }]}>
          What are you building today?
        </Text>

        <View style={styles.searchBar}>
          <TextInput
            placeholder="Search sand, cement, bricks..."
            value={search} onChangeText={setSearch}
            style={styles.searchInput} placeholderTextColor={colors.textSecondary}
          />
        </View>

        {/* Quick links: standalone truck hire, Government Tender module, RFQ, business, notifications */}
        <View style={{ flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md, flexWrap: 'wrap' }}>
          <TouchableOpacity style={styles.quickLink} onPress={() => navigation.navigate('TruckSearch')}>
            <Text style={{ fontSize: 20 }}>🚛</Text>
            <Text style={styles.quickLinkText}>Find a truck</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickLink} onPress={() => navigation.navigate('TenderHome')}>
            <Text style={{ fontSize: 20 }}>🏛️</Text>
            <Text style={styles.quickLinkText}>Government Tenders</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickLink} onPress={() => navigation.navigate('RfqList')}>
            <Text style={{ fontSize: 20 }}>📋</Text>
            <Text style={styles.quickLinkText}>Bulk requirement (RFQ)</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickLink} onPress={() => navigation.navigate('BusinessHome')}>
            <Text style={{ fontSize: 20 }}>🏢</Text>
            <Text style={styles.quickLinkText}>Business account</Text>
          </TouchableOpacity>
        </View>

        <Text style={[type.h2, { marginTop: spacing.lg, marginBottom: spacing.sm }]}>Categories</Text>
        <FlatList
          data={categories}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(c) => c.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.categoryPill}
              onPress={() => navigation.navigate('MaterialList', { categoryId: item.id, categoryName: item.name })}
            >
              <Text style={{ fontSize: 26 }}>{item.icon}</Text>
              <Text style={styles.categoryLabel}>{item.name}</Text>
            </TouchableOpacity>
          )}
        />

        <Text style={[type.h2, { marginTop: spacing.lg, marginBottom: spacing.sm }]}>Popular materials</Text>
        {popularMaterials.map((m) => (
          <Card key={m.id}>
            <TouchableOpacity onPress={() => goToMaterial(m.id, m.name)}>
              <Text style={type.h3}>{m.name}</Text>
              <Text style={[type.caption, { marginTop: 2 }]}>{m.description}</Text>
              <Chip label={`per ${m.unit}`} />
            </TouchableOpacity>
          </Card>
        ))}

        <Text style={[type.h2, { marginTop: spacing.lg, marginBottom: spacing.sm }]}>Nearby suppliers</Text>
        {sampleSuppliers.slice(0, 3).map((s) => (
          <Card key={s.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.h3}>{s.businessName}</Text>
              {s.verified && <Chip label="Verified" tone="success" />}
            </View>
            <Text style={type.caption}>⭐ {s.rating} ({s.ratingCount}) · {s.distanceKm} km away</Text>
          </Card>
        ))}

        <TouchableOpacity onPress={() => navigation.navigate('OrderHistory')} style={{ marginTop: spacing.sm }}>
          <Text style={{ color: colors.secondary, fontWeight: '600' }}>View recent orders →</Text>
        </TouchableOpacity>
        {!isLive && (
          <Text style={[type.caption, { marginTop: spacing.sm, textAlign: 'center' }]}>
            Showing sample data — backend not reachable
          </Text>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

function iconFor(slug: string): string {
  const map: Record<string, string> = {
    sand: '🏖️', 'gitti-aggregate': '🪨', stone: '🧱', gravel: '⛰️', 'soil-mitti': '🟫',
    'fly-ash': '💨', bricks: '🧱', cement: '🏗️', 'construction-blocks': '⬜', other: '📦',
  };
  return map[slug] ?? '📦';
}

const styles = StyleSheet.create({
  locationRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  locationLabel: { ...type.caption },
  locationValue: { ...type.h3, color: colors.secondary },
  searchBar: {
    backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
    paddingHorizontal: spacing.md, marginTop: spacing.sm,
  },
  searchInput: { paddingVertical: 12, fontSize: 15, color: colors.textPrimary },
  categoryPill: {
    width: 84, alignItems: 'center', marginRight: spacing.sm, backgroundColor: colors.surface,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, paddingVertical: spacing.sm,
  },
  categoryLabel: { ...type.caption, textAlign: 'center', marginTop: 4 },
  quickLink: {
    width: '47%', backgroundColor: colors.chipBg, borderRadius: radius.md, padding: spacing.sm,
    alignItems: 'center', borderWidth: 1, borderColor: colors.border,
  },
  quickLinkText: { ...type.caption, fontWeight: '600', marginTop: 2, textAlign: 'center' },
});
