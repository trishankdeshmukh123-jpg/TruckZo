// Standalone truck search/filter for customers hiring a truck directly
// (not tied to a material order). Filters: vehicle category, capacity,
// location (GPS), availability, price. Calls GET /trucks/search with
// sample-data fallback.

import React, { useEffect, useState } from 'react';
import { ScrollView, Text, View, ActivityIndicator, TouchableOpacity } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { VEHICLE_CATEGORIES, CAPACITY_BRACKETS, labelFor } from '../../data/truckOptions';
import OptionChips from '../../components/OptionChips';
import { searchTrucks, TruckSearchResult } from '../../api/client';
import { sampleAddresses } from '../../data/sampleAddresses';

type Props = NativeStackScreenProps<CustomerStackParamList, 'TruckSearch'>;

const SAMPLE_TRUCKS: TruckSearchResult[] = [
  { id: 'stk-1', registrationNumber: 'MH12AB1234', vehicleCategory: '10_wheeler', capacityBracket: '15_ton', capacityTons: 16, ratePerTrip: 4500, ratePerKm: 55, currentLat: 19.09, currentLng: 72.88, vehicleDetails: '2021 model', isAvailable: true, driverName: 'Suresh Patil', driverPhone: '+919812345670', supplierName: 'Shree Balaji Sand & Aggregates', rating: 4.6, ratingCount: 212, distanceKm: 5.1 },
  { id: 'stk-2', registrationNumber: 'MH14EF9012', vehicleCategory: 'mini_truck', capacityBracket: '3_ton', capacityTons: 3, ratePerTrip: 1800, ratePerKm: 25, currentLat: 19.10, currentLng: 72.90, vehicleDetails: 'Good for small loads', isAvailable: true, driverName: 'Vikram Singh', driverPhone: '+919812345672', supplierName: 'RK Construction Materials', rating: 4.3, ratingCount: 98, distanceKm: 9.7 },
];

export default function TruckSearchScreen({ navigation }: Props) {
  const [category, setCategory] = useState<string | null>(null);
  const [capacity, setCapacity] = useState<string | null>(null);
  const [onlyAvailable, setOnlyAvailable] = useState(true);
  const [results, setResults] = useState<TruckSearchResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(false);

  useEffect(() => { runSearch(); }, [category, capacity, onlyAvailable]);

  async function runSearch() {
    setLoading(true);
    try {
      const demoPoint = sampleAddresses[0];
      const { results } = await searchTrucks({
        category: category ?? undefined, capacity: capacity ?? undefined,
        onlyAvailable, lat: demoPoint.lat, lng: demoPoint.lng, maxDistanceKm: 200,
      });
      setResults(results);
      setIsLive(true);
    } catch {
      let filtered = SAMPLE_TRUCKS;
      if (category) filtered = filtered.filter((t) => t.vehicleCategory === category);
      if (capacity) filtered = filtered.filter((t) => t.capacityBracket === capacity);
      if (onlyAvailable) filtered = filtered.filter((t) => t.isAvailable);
      setResults(filtered);
      setIsLive(false);
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>Find a truck</Text>

        <Card>
          <Text style={type.h3}>Vehicle category</Text>
          <View style={{ height: spacing.xs }} />
          <OptionChips options={VEHICLE_CATEGORIES} value={category} onChange={setCategory} allowClear />
        </Card>
        <Card>
          <Text style={type.h3}>Capacity</Text>
          <View style={{ height: spacing.xs }} />
          <OptionChips options={CAPACITY_BRACKETS} value={capacity} onChange={setCapacity} allowClear />
        </Card>
        <TouchableOpacity onPress={() => setOnlyAvailable((v) => !v)}>
          <Card>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.h3}>Only show available now</Text>
              <Chip label={onlyAvailable ? 'On' : 'Off'} tone={onlyAvailable ? 'success' : 'default'} />
            </View>
          </Card>
        </TouchableOpacity>

        <Text style={[type.h2, { marginTop: spacing.md, marginBottom: spacing.sm }]}>
          {results.length} truck{results.length !== 1 ? 's' : ''} found
          {!isLive ? ' (sample data — backend not reachable)' : ''}
        </Text>

        {loading ? (
          <ActivityIndicator color={colors.primary} />
        ) : results.length === 0 ? (
          <EmptyState message="No trucks match your filters." />
        ) : (
          results.map((t) => (
            <TouchableOpacity key={t.id} onPress={() => navigation.navigate('TruckDetail', { truck: t })}>
              <Card>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text style={type.h3}>{labelFor(VEHICLE_CATEGORIES, t.vehicleCategory)}</Text>
                  <Chip label={t.isAvailable ? 'Available' : 'Busy'} tone={t.isAvailable ? 'success' : 'warning'} />
                </View>
                <Text style={type.caption}>
                  {labelFor(CAPACITY_BRACKETS, t.capacityBracket)} · {t.supplierName}
                  {t.distanceKm != null ? ` · ${t.distanceKm} km away` : ''}
                </Text>
                <Text style={[type.price, { marginTop: 4 }]}>
                  {t.ratePerTrip ? `₹${t.ratePerTrip}/trip` : ''}{t.ratePerTrip && t.ratePerKm ? ' · ' : ''}{t.ratePerKm ? `₹${t.ratePerKm}/km` : ''}
                </Text>
              </Card>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
