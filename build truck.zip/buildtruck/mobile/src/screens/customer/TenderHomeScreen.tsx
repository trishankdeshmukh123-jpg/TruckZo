import React from 'react';
import { Text, TouchableOpacity } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card } from '../../components/Primitives';
import TenderDisclaimer from '../../components/TenderDisclaimer';
import { type, spacing } from '../../theme/theme';

type Props = NativeStackScreenProps<CustomerStackParamList, 'TenderHome'>;

export default function TenderHomeScreen({ navigation }: Props) {
  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.sm }]}>Government Tenders</Text>
      <TenderDisclaimer />

      <TouchableOpacity onPress={() => navigation.navigate('TenderMaterialSearch')}>
        <Card>
          <Text style={type.h3}>🧱 Find tender materials ›</Text>
          <Text style={type.caption}>Sand, aggregate, bricks, cement and more, listed by suppliers for project requirements.</Text>
        </Card>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('TenderTruckSearch')}>
        <Card>
          <Text style={type.h3}>🚛 Find tender trucks ›</Text>
          <Text style={type.caption}>Vehicles listed by truck owners specifically for government-project requirements.</Text>
        </Card>
      </TouchableOpacity>
    </ScreenContainer>
  );
}
