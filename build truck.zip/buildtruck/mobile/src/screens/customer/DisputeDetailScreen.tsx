import React, { useCallback, useState } from 'react';
import { ScrollView, Text, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { getDispute, DisputeRecord } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'DisputeDetail'>;

export default function DisputeDetailScreen({ route }: Props) {
  const [dispute, setDispute] = useState<DisputeRecord | null>(null);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(useCallback(() => {
    (async () => {
      try {
        setDispute(await getDispute(route.params.disputeId));
        setError(null);
      } catch (err) {
        setError((err as Error).message || 'Could not load this dispute.');
      }
    })();
  }, [route.params.disputeId]));

  if (error) return <ScreenContainer><EmptyState message={error} /></ScreenContainer>;
  if (!dispute) return <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.primary} /></ScreenContainer>;

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>{dispute.issue_type.replace(/_/g, ' ')}</Text>
        <Chip label={dispute.status.replace(/_/g, ' ')} />

        <Card style={{ marginTop: spacing.md }}>
          <Text style={type.h3}>Your report</Text>
          <Text style={type.body}>{dispute.description}</Text>
        </Card>

        {dispute.admin_notes && (
          <Card>
            <Text style={type.h3}>Notes from our team</Text>
            <Text style={type.body}>{dispute.admin_notes}</Text>
          </Card>
        )}

        {dispute.resolution && (
          <Card style={{ borderColor: colors.success }}>
            <Text style={type.h3}>Resolution</Text>
            <Text style={type.body}>{dispute.resolution}</Text>
          </Card>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
