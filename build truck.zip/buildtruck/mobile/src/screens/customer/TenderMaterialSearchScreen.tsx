import React, { useEffect, useState } from 'react';
import { ScrollView, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, EmptyState } from '../../components/Primitives';
import TenderDisclaimer from '../../components/TenderDisclaimer';
import { type, spacing, colors } from '../../theme/theme';
import { searchTenderMaterials, TenderMaterialResult } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'TenderMaterialSearch'>;

const SAMPLE: TenderMaterialResult[] = [
  { id: 'tm-1', material_name: 'River Sand', quantity: 5000, unit: 'ton', rate: 1350, supply_location: 'Nashik, Maharashtra', service_area: 'Nashik district', is_available: true, supplier_name: 'Ganesh Brick & Cement Depot', supplier_phone: '+919812340001' },
  { id: 'tm-2', material_name: '20mm Aggregate', quantity: 3000, unit: 'ton', rate: 1150, supply_location: 'Pune, Maharashtra', service_area: 'Pune district', is_available: true, supplier_name: 'RK Construction Materials', supplier_phone: '+919812340002' },
];

export default function TenderMaterialSearchScreen({ navigation }: Props) {
  const [results, setResults] = useState<TenderMaterialResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const { results } = await searchTenderMaterials({ onlyAvailable: true });
        setResults(results); setIsLive(true);
      } catch {
        setResults(SAMPLE);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.sm }]}>Tender materials</Text>
        <TenderDisclaimer />
        {!isLive && <Text style={[type.caption, { marginBottom: spacing.sm }]}>Showing sample data — backend not reachable</Text>}
        {loading ? <ActivityIndicator color={colors.primary} /> : results.length === 0 ? (
          <EmptyState message="No tender material listings yet." />
        ) : results.map((m) => (
          <TouchableOpacity key={m.id} onPress={() => navigation.navigate('TenderMaterialDetail', { material: m })}>
            <Card>
              <Text style={type.h3}>{m.material_name}</Text>
              <Text style={type.caption}>{m.supplier_name} · {m.supply_location}</Text>
              <Text style={[type.price, { marginTop: 4 }]}>₹{m.rate}/{m.unit} · {m.quantity} {m.unit} available</Text>
            </Card>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
