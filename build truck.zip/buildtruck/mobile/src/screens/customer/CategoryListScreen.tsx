import React, { useEffect, useState } from 'react';
import { FlatList, TouchableOpacity, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card } from '../../components/Primitives';
import { sampleCategories } from '../../data/sampleData';
import { Category } from '../../types/domain';
import { type, spacing } from '../../theme/theme';
import { getCategories } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'Categories'>;

const ICONS: Record<string, string> = {
  sand: '🏖️', 'gitti-aggregate': '🪨', stone: '🧱', gravel: '⛰️', 'soil-mitti': '🟫',
  'fly-ash': '💨', bricks: '🧱', cement: '🏗️', 'construction-blocks': '⬜', other: '📦',
};

export default function CategoryListScreen({ navigation }: Props) {
  const [categories, setCategories] = useState<Category[]>(sampleCategories);

  useEffect(() => {
    (async () => {
      try {
        const { results } = await getCategories();
        setCategories(results.map((c) => ({ id: c.id, name: c.name, slug: c.slug, icon: ICONS[c.slug] ?? '📦' })));
      } catch { /* keep sample fallback already in state */ }
    })();
  }, []);

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>All categories</Text>
      <FlatList
        data={categories}
        keyExtractor={(c) => c.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('MaterialList', { categoryId: item.id, categoryName: item.name })}>
            <Card>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={{ fontSize: 24, marginRight: spacing.sm }}>{item.icon}</Text>
                <Text style={type.h3}>{item.name}</Text>
              </View>
            </Card>
          </TouchableOpacity>
        )}
      />
    </ScreenContainer>
  );
}
