import React, { useCallback, useState } from 'react';
import { FlatList, Text, TouchableOpacity, TextInput, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../../navigation/types';
import { ScreenContainer, Card, Chip, PrimaryButton, EmptyState } from '../../../components/Primitives';
import { type, spacing } from '../../../theme/theme';
import { getMyBusinesses, createBusiness, BusinessRecord } from '../../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'BusinessHome'>;

export default function BusinessHomeScreen({ navigation }: Props) {
  const [businesses, setBusinesses] = useState<BusinessRecord[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [gstin, setGstin] = useState('');
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    try {
      const { results } = await getMyBusinesses();
      setBusinesses(results);
      setError(null);
    } catch (err) {
      setError((err as Error).message || 'Could not load your businesses — backend not reachable.');
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function create() {
    if (!name) { Alert.alert('Missing name', 'Enter a business/company name.'); return; }
    setCreating(true);
    try {
      await createBusiness(name, gstin || undefined);
      setName(''); setGstin('');
      load();
    } catch (err) {
      Alert.alert('Could not create business', (err as Error).message);
    } finally {
      setCreating(false);
    }
  }

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>Business accounts</Text>

      <Card>
        <Text style={type.h3}>Create a business account</Text>
        <TextInput value={name} onChangeText={setName} placeholder="Company name" style={{ fontSize: 15, paddingVertical: 8 }} />
        <TextInput value={gstin} onChangeText={setGstin} placeholder="GSTIN (optional)" style={{ fontSize: 15, paddingVertical: 8 }} />
        <PrimaryButton title="Create business" onPress={create} loading={creating} />
      </Card>

      {error ? <EmptyState message={error} /> : (
        <FlatList
          data={businesses}
          keyExtractor={(b) => b.id}
          ListEmptyComponent={<EmptyState message="No business accounts yet." />}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => navigation.navigate('ProjectList', { businessId: item.id, businessName: item.name })}>
              <Card>
                <Text style={type.h3}>{item.name}</Text>
                {item.gstin && <Text style={type.caption}>GSTIN: {item.gstin}</Text>}
                <Chip label={item.role} />
              </Card>
            </TouchableOpacity>
          )}
        />
      )}
    </ScreenContainer>
  );
}
