import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, EmptyState, formatINR } from '../../../components/Primitives';
import { type, spacing, colors } from '../../../theme/theme';
import { getProjectDashboard, ProjectDashboard } from '../../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'ProjectDetail'>;

export default function ProjectDetailScreen({ route, navigation }: Props) {
  const { projectId, projectName } = route.params;
  const [dashboard, setDashboard] = useState<ProjectDashboard | null>(null);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(useCallback(() => {
    (async () => {
      try {
        setDashboard(await getProjectDashboard(projectId));
        setError(null);
      } catch (err) {
        setError((err as Error).message || 'Could not load project dashboard — backend not reachable.');
      }
    })();
  }, [projectId]));

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>{projectName}</Text>

        {error ? <EmptyState message={error} /> : !dashboard ? (
          <ActivityIndicator color={colors.primary} />
        ) : (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            <StatCard label="Total orders" value={String(dashboard.totalOrders)} />
            <StatCard label="Active orders" value={String(dashboard.activeOrders)} />
            <StatCard label="Completed orders" value={String(dashboard.completedOrders)} />
            <StatCard label="Total spend" value={formatINR(dashboard.totalSpend)} wide />
            <StatCard label="Open RFQs" value={`${dashboard.openRfqs} / ${dashboard.totalRfqs}`} wide />
          </View>
        )}

        <PrimaryButton title="Post a requirement for this project" onPress={() => navigation.navigate('RfqCreate', { projectId, projectName })} />
      </ScrollView>
    </ScreenContainer>
  );
}

function StatCard({ label, value, wide }: { label: string; value: string; wide?: boolean }) {
  return (
    <View style={{ width: wide ? '100%' : '47%' }}>
      <Card style={{ marginBottom: 0 }}>
        <Text style={type.caption}>{label}</Text>
        <Text style={[type.price, { marginTop: 4 }]}>{value}</Text>
      </Card>
    </View>
  );
}
