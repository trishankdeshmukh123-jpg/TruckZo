import React, { useCallback, useState } from 'react';
import { FlatList, Text, TouchableOpacity, TextInput, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, EmptyState } from '../../../components/Primitives';
import { type, spacing } from '../../../theme/theme';
import { getProjects, createProject, ProjectRecord } from '../../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'ProjectList'>;

export default function ProjectListScreen({ route, navigation }: Props) {
  const { businessId, businessName } = route.params;
  const [projects, setProjects] = useState<ProjectRecord[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [siteAddress, setSiteAddress] = useState('');
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    try {
      const { results } = await getProjects(businessId);
      setProjects(results);
      setError(null);
    } catch (err) {
      setError((err as Error).message || 'Could not load projects — backend not reachable.');
    }
  }, [businessId]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function create() {
    if (!name) { Alert.alert('Missing name', 'Enter a project name.'); return; }
    setCreating(true);
    try {
      await createProject(businessId, { name, siteAddress: siteAddress || undefined });
      setName(''); setSiteAddress('');
      load();
    } catch (err) {
      Alert.alert('Could not create project', (err as Error).message);
    } finally {
      setCreating(false);
    }
  }

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.xs }]}>{businessName}</Text>
      <Text style={[type.caption, { marginBottom: spacing.md }]}>Projects</Text>

      <Card>
        <Text style={type.h3}>New project</Text>
        <TextInput value={name} onChangeText={setName} placeholder="Project name" style={{ fontSize: 15, paddingVertical: 8 }} />
        <TextInput value={siteAddress} onChangeText={setSiteAddress} placeholder="Site address" style={{ fontSize: 15, paddingVertical: 8 }} />
        <PrimaryButton title="Create project" onPress={create} loading={creating} />
      </Card>

      {error ? <EmptyState message={error} /> : (
        <FlatList
          data={projects}
          keyExtractor={(p) => p.id}
          ListEmptyComponent={<EmptyState message="No projects yet." />}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => navigation.navigate('ProjectDetail', { projectId: item.id, projectName: item.name })}>
              <Card>
                <Text style={type.h3}>{item.name}</Text>
                {!!item.site_address && <Text style={type.caption}>{item.site_address}</Text>}
              </Card>
            </TouchableOpacity>
          )}
        />
      )}
    </ScreenContainer>
  );
}
