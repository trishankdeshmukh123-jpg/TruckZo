// Material detail for the specific supplier offer selected on the previous
// screen. Uses the OfferParam passed via navigation (live or sample —
// already resolved by SupplierSelectionScreen) rather than re-fetching or
// looking up sample data itself.

import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, PrimaryButton, SecondaryButton, formatINR } from '../../components/Primitives';
import { colors, spacing, type, radius } from '../../theme/theme';
import { useCart } from '../../context/CartContext';

type Props = NativeStackScreenProps<CustomerStackParamList, 'MaterialDetail'>;

export default function MaterialDetailScreen({ route, navigation }: Props) {
  const { materialId, offer } = route.params;
  const { setSupplier, addOrUpdateItem } = useCart();

  const [quantity, setQuantity] = useState(offer.minOrderQuantity);
  const lineTotal = quantity * offer.pricePerUnit;

  function changeQty(delta: number) {
    setQuantity((q) => Math.max(offer.minOrderQuantity, Math.min(offer.availableQuantity, q + delta)));
  }

  function addToCart(goToCart: boolean) {
    setSupplier({
      id: offer.supplierId, businessName: offer.businessName, rating: offer.rating,
      ratingCount: offer.ratingCount, distanceKm: offer.distanceKm, lat: offer.supplierLat,
      lng: offer.supplierLng, verified: offer.verified,
    });
    addOrUpdateItem(
      { id: offer.offerId, supplierId: offer.supplierId, materialId, pricePerUnit: offer.pricePerUnit, availableQuantity: offer.availableQuantity, minOrderQuantity: offer.minOrderQuantity },
      { id: materialId, categoryId: '', name: offer.materialName, unit: offer.materialUnit, description: offer.materialDescription },
      quantity
    );
    if (goToCart) navigation.navigate('Cart');
    else navigation.goBack();
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: 140 }}>
        <View style={styles.imagePlaceholder}>
          <Text style={{ fontSize: 40 }}>🧱</Text>
        </View>

        <Text style={[type.h1, { marginTop: spacing.md }]}>{offer.materialName}</Text>
        <Text style={[type.body, { color: colors.textSecondary, marginTop: 4 }]}>{offer.materialDescription}</Text>

        <Card style={{ marginTop: spacing.md }}>
          <Text style={type.h3}>Sold by</Text>
          <Text style={[type.body, { marginTop: 2 }]}>{offer.businessName}</Text>
          <Text style={type.caption}>⭐ {offer.rating} ({offer.ratingCount}) · {offer.distanceKm} km away</Text>
          {offer.verified ? <Chip label="Verified supplier" tone="success" /> : <Chip label="Unverified" tone="warning" />}
        </Card>

        <Card>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={type.h3}>Price</Text>
            <Text style={type.price}>{formatINR(offer.pricePerUnit)} / {offer.materialUnit}</Text>
          </View>
          <Text style={type.caption}>{offer.availableQuantity} {offer.materialUnit} available · min order {offer.minOrderQuantity}</Text>
          <Text style={[type.caption, { marginTop: spacing.sm }]}>Estimated delivery: 1–2 days after confirmation</Text>
        </Card>

        <Card>
          <Text style={type.h3}>Quantity ({offer.materialUnit})</Text>
          <View style={styles.qtyRow}>
            <TouchableOpacity style={styles.qtyButton} onPress={() => changeQty(-1)}>
              <Text style={styles.qtyButtonText}>−</Text>
            </TouchableOpacity>
            <Text style={styles.qtyValue}>{quantity}</Text>
            <TouchableOpacity style={styles.qtyButton} onPress={() => changeQty(1)}>
              <Text style={styles.qtyButtonText}>+</Text>
            </TouchableOpacity>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.sm }}>
            <Text style={type.body}>Line total</Text>
            <Text style={type.price}>{formatINR(lineTotal)}</Text>
          </View>
        </Card>
      </ScrollView>

      <View style={styles.footer}>
        <SecondaryButton title="Add to cart" onPress={() => addToCart(false)} />
        <View style={{ height: spacing.sm }} />
        <PrimaryButton title="Buy now" onPress={() => addToCart(true)} />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  imagePlaceholder: {
    height: 160, borderRadius: radius.md, backgroundColor: colors.chipBg,
    alignItems: 'center', justifyContent: 'center',
  },
  qtyRow: { flexDirection: 'row', alignItems: 'center', marginTop: spacing.sm },
  qtyButton: {
    width: 40, height: 40, borderRadius: radius.sm, backgroundColor: colors.chipBg,
    alignItems: 'center', justifyContent: 'center',
  },
  qtyButtonText: { fontSize: 20, fontWeight: '700', color: colors.primaryDark },
  qtyValue: { fontSize: 18, fontWeight: '700', marginHorizontal: spacing.lg },
  footer: {
    position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: colors.surface,
    padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.border,
  },
});
