import React, { useEffect, useState } from 'react';
import { ScrollView, Text, TouchableOpacity, ActivityIndicator, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState } from '../../components/Primitives';
import TenderDisclaimer from '../../components/TenderDisclaimer';
import { type, spacing, colors } from '../../theme/theme';
import { VEHICLE_CATEGORIES, CAPACITY_BRACKETS, labelFor } from '../../data/truckOptions';
import OptionChips from '../../components/OptionChips';
import { searchTenderTrucks, TenderTruckResult } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'TenderTruckSearch'>;

const SAMPLE: TenderTruckResult[] = [
  { id: 'tt-1', vehicle_category: '12_wheeler', capacity_bracket: '20_ton', capacity_tons: 20, registration_number: 'MH20GH3456', rate_per_trip: 6000, rate_per_km: 65, driver_name: 'Anil Kumar', driver_phone: '+919812340010', vehicle_details: 'Tipper, 2020 model', is_available: true, supplier_name: 'Ganesh Brick & Cement Depot' },
];

export default function TenderTruckSearchScreen({ navigation }: Props) {
  const [category, setCategory] = useState<string | null>(null);
  const [results, setResults] = useState<TenderTruckResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(false);

  useEffect(() => { runSearch(); }, [category]);

  async function runSearch() {
    setLoading(true);
    try {
      const { results } = await searchTenderTrucks({ category: category ?? undefined, onlyAvailable: true });
      setResults(results); setIsLive(true);
    } catch {
      setResults(category ? SAMPLE.filter((t) => t.vehicle_category === category) : SAMPLE);
      setIsLive(false);
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.sm }]}>Tender trucks</Text>
        <TenderDisclaimer />

        <Card>
          <Text style={type.h3}>Vehicle category</Text>
          <View style={{ height: spacing.xs }} />
          <OptionChips options={VEHICLE_CATEGORIES} value={category} onChange={setCategory} allowClear />
        </Card>

        {!isLive && <Text style={[type.caption, { marginBottom: spacing.sm }]}>Showing sample data — backend not reachable</Text>}
        {loading ? <ActivityIndicator color={colors.primary} /> : results.length === 0 ? (
          <EmptyState message="No tender truck listings match this filter." />
        ) : results.map((t) => (
          <TouchableOpacity key={t.id} onPress={() => navigation.navigate('TenderTruckDetail', { truck: t })}>
            <Card>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={type.h3}>{labelFor(VEHICLE_CATEGORIES, t.vehicle_category)}</Text>
                <Chip label={t.is_available ? 'Available' : 'Busy'} tone={t.is_available ? 'success' : 'warning'} />
              </View>
              <Text style={type.caption}>{labelFor(CAPACITY_BRACKETS, t.capacity_bracket)} · {t.supplier_name}</Text>
              <Text style={[type.price, { marginTop: 4 }]}>
                {t.rate_per_trip ? `₹${t.rate_per_trip}/trip` : ''}{t.rate_per_trip && t.rate_per_km ? ' · ' : ''}{t.rate_per_km ? `₹${t.rate_per_km}/km` : ''}
              </Text>
            </Card>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
