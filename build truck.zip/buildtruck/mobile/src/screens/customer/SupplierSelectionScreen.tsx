// Compare suppliers who sell the chosen material — price, distance, rating,
// verification. Tries the real backend's location search
// (GET /suppliers/near) first, falling back to sample data if unreachable.
// The full selected offer (live or sample) is passed forward to
// MaterialDetail via navigation params, so nothing downstream needs to
// re-fetch or fall back to sample data on its own — one fetch, one source
// of truth per screen visit.

import React, { useEffect, useState } from 'react';
import { FlatList, TouchableOpacity, Text, View, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList, OfferParam } from '../../navigation/types';
import { ScreenContainer, Card, Chip, EmptyState, formatINR } from '../../components/Primitives';
import { offersForMaterial, supplierById } from '../../data/sampleData';
import { sampleAddresses } from '../../data/sampleAddresses';
import { type, spacing, colors } from '../../theme/theme';
import { findNearbySuppliers } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'SupplierSelection'>;

export default function SupplierSelectionScreen({ route, navigation }: Props) {
  const { materialId, materialName } = route.params;
  const [rows, setRows] = useState<OfferParam[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLiveData, setIsLiveData] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        // Demo delivery point — in the real flow this would be the
        // customer's currently-selected address; wired here to the first
        // saved address since Address selection happens later in this flow.
        const demoPoint = sampleAddresses[0];
        const { results } = await findNearbySuppliers(materialId, demoPoint.lat, demoPoint.lng);
        setRows(results.map((r) => ({
          offerId: r.supplierMaterialId, supplierId: r.supplierId, businessName: r.businessName,
          rating: r.rating, ratingCount: r.ratingCount, distanceKm: r.distanceKm, verified: r.verified,
          supplierLat: r.supplierLat, supplierLng: r.supplierLng, pricePerUnit: r.pricePerUnit,
          availableQuantity: r.availableQuantity, minOrderQuantity: r.minOrderQuantity,
          materialName: r.materialName, materialUnit: r.materialUnit, materialDescription: r.materialDescription ?? '',
        })));
        setIsLiveData(true);
      } catch {
        const offers = offersForMaterial(materialId)
          .map((o) => ({ offer: o, supplier: supplierById(o.supplierId)! }))
          .sort((a, b) => a.offer.pricePerUnit - b.offer.pricePerUnit);
        setRows(offers.map(({ offer, supplier }) => ({
          offerId: offer.id, supplierId: supplier.id, businessName: supplier.businessName,
          rating: supplier.rating, ratingCount: supplier.ratingCount, distanceKm: supplier.distanceKm,
          verified: supplier.verified, supplierLat: supplier.lat, supplierLng: supplier.lng,
          pricePerUnit: offer.pricePerUnit, availableQuantity: offer.availableQuantity, minOrderQuantity: offer.minOrderQuantity,
          materialName, materialUnit: 'unit', materialDescription: '',
        })));
      } finally {
        setLoading(false);
      }
    })();
  }, [materialId]);

  if (loading) {
    return <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.primary} size="large" /></ScreenContainer>;
  }

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.xs }]}>{materialName}</Text>
      <Text style={[type.caption, { marginBottom: spacing.md }]}>
        {rows.length} supplier{rows.length !== 1 ? 's' : ''} deliver this near you
        {!isLiveData ? ' (showing sample data — backend not reachable)' : ''}
      </Text>
      <FlatList
        data={rows}
        keyExtractor={(r) => r.offerId}
        ListEmptyComponent={<EmptyState message="No suppliers found for this material in your area." />}
        renderItem={({ item, index }) => (
          <TouchableOpacity onPress={() => navigation.navigate('MaterialDetail', { materialId, offer: item })}>
            <Card>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={type.h3}>{item.businessName}</Text>
                {index === 0 && <Chip label="Best price" tone="success" />}
              </View>
              <Text style={[type.caption, { marginTop: 2 }]}>
                ⭐ {item.rating} ({item.ratingCount}) · {item.distanceKm} km away
              </Text>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.sm }}>
                <Text style={type.price}>{formatINR(item.pricePerUnit)}/{item.materialUnit}</Text>
                {!item.verified && <Chip label="Unverified" tone="warning" />}
              </View>
              <Text style={[type.caption, { color: colors.textSecondary }]}>
                {item.availableQuantity} {item.materialUnit} available · min order {item.minOrderQuantity}
              </Text>
            </Card>
          </TouchableOpacity>
        )}
      />
    </ScreenContainer>
  );
}
