// UPI or Cash. Calls the real backend createOrder() — which recalculates
// price + commission server-side. If the backend is unreachable, this
// shows a real error rather than fabricating a successful order: a fake
// "order placed" screen with no real order behind it would be actively
// misleading, not a helpful demo.
//
// UPI: for MVP this calls paymentService's MockPaymentProvider unless
// PAYMENT_PROVIDER=razorpay is set on the backend (see backend/.env.example
// and backend/src/services/paymentService.ts's RazorpayProvider).

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, Chip } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { useCart } from '../../context/CartContext';
import { createOrder } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'PaymentSelection'>;
type Method = 'UPI' | 'CASH';

export default function PaymentSelectionScreen({ route, navigation }: Props) {
  const { address } = route.params;
  const { supplier, items, clear } = useCart();
  const [method, setMethod] = useState<Method>('UPI');
  const [placing, setPlacing] = useState(false);

  async function placeOrder() {
    setPlacing(true);
    try {
      const result = await createOrder({
        supplierId: supplier!.id,
        supplierMaterialItems: items.map((i) => ({
          supplierMaterialId: i.offer.id, unitPrice: i.offer.pricePerUnit, quantity: i.quantity,
        })),
        deliveryAddressId: address.id,
        originLat: supplier!.lat, originLng: supplier!.lng,
        destLat: address.lat, destLng: address.lng,
        paymentMethod: method,
      });
      const originLat = supplier!.lat, originLng = supplier!.lng, destLat = address.lat, destLng = address.lng;
      clear();
      navigation.reset({
        index: 0,
        routes: [{ name: 'Home' }, {
          name: 'OrderConfirmation',
          params: { orderNumber: result.orderNumber, orderId: result.orderId, totalAmount: result.price.totalAmount, paymentMethod: method, originLat, originLng, destLat, destLng },
        }],
      });
    } catch (err) {
      Alert.alert('Could not place order', (err as Error).message || 'The backend is not reachable right now — please try again in a moment.');
    } finally {
      setPlacing(false);
    }
  }

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>Payment method</Text>

      <TouchableOpacity onPress={() => setMethod('UPI')}>
        <Card style={{ borderColor: method === 'UPI' ? colors.primary : colors.border }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={type.h3}>📱 UPI</Text>
            {method === 'UPI' && <Chip label="Selected" />}
          </View>
          <Text style={type.caption}>Pay now via UPI. Commission is deducted automatically at settlement.</Text>
        </Card>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setMethod('CASH')}>
        <Card style={{ borderColor: method === 'CASH' ? colors.primary : colors.border }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={type.h3}>💵 Cash on delivery</Text>
            {method === 'CASH' && <Chip label="Selected" />}
          </View>
          <Text style={type.caption}>Pay the driver directly. The supplier owes platform commission on this order separately.</Text>
        </Card>
      </TouchableOpacity>

      <View style={{ flex: 1 }} />
      <PrimaryButton title="Place order" onPress={placeOrder} loading={placing} />
    </ScreenContainer>
  );
}
