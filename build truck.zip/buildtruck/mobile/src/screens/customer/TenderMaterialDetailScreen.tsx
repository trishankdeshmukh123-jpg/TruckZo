import React, { useState } from 'react';
import { ScrollView, Text, TextInput, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import TenderDisclaimer from '../../components/TenderDisclaimer';
import { type, spacing } from '../../theme/theme';
import { requestTenderMaterial } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'TenderMaterialDetail'>;

export default function TenderMaterialDetailScreen({ route }: Props) {
  const { material } = route.params;
  const [quantity, setQuantity] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  async function send() {
    setSending(true);
    try {
      await requestTenderMaterial(material.id, message || 'Requirement enquiry', quantity ? Number(quantity) : undefined);
      setSent(true);
    } catch (err) {
      Alert.alert('Could not send request', (err as Error).message || 'Backend not reachable — please try again.');
    } finally {
      setSending(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.sm }]}>{material.material_name}</Text>
        <TenderDisclaimer />

        <Card>
          <Text style={type.h3}>Listing</Text>
          <Text style={type.body}>{material.quantity} {material.unit} available at ₹{material.rate}/{material.unit}</Text>
          <Text style={type.caption}>Supply location: {material.supply_location}</Text>
          {!!material.service_area && <Text style={type.caption}>Service area: {material.service_area}</Text>}
        </Card>

        <Card>
          <Text style={type.h3}>Supplier</Text>
          <Text style={type.body}>{material.supplier_name}</Text>
          <Text style={type.caption}>{material.supplier_phone}</Text>
        </Card>

        <Card>
          <Text style={type.h3}>Send your requirement</Text>
          <Text style={type.caption}>Quantity needed</Text>
          <TextInput value={quantity} onChangeText={setQuantity} keyboardType="numeric" placeholder={`e.g. 2000 ${material.unit}`} style={{ fontSize: 15, paddingVertical: 8 }} />
          <Text style={[type.caption, { marginTop: spacing.sm }]}>Message</Text>
          <TextInput value={message} onChangeText={setMessage} multiline placeholder="Project name, delivery timeline, etc." style={{ fontSize: 15, paddingVertical: 8, minHeight: 70, textAlignVertical: 'top' }} />
          {sent ? (
            <Text style={{ color: '#2E7D4F', fontWeight: '600', marginTop: spacing.sm }}>✅ Requirement sent to the supplier.</Text>
          ) : (
            <PrimaryButton title="Send requirement" onPress={send} loading={sending} />
          )}
        </Card>
      </ScrollView>
    </ScreenContainer>
  );
}
