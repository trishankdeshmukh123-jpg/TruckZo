// Live order tracking: map, truck marker, ETA, real order status (polled
// from the backend), multi-truck trip progress, OTP confirmation, and the
// resulting Proof of Delivery once confirmed.
//
// ENVIRONMENT VARIABLE REQUIRED for real maps: MAPS_PROVIDER_API_KEY
// (Google Maps for Android via react-native-maps; iOS can use Apple Maps
// with no key). Truck position between origin/destination is interpolated
// from status progress since there's no live driver-app GPS feed yet (see
// backend/src/services/locationService.ts's notes on live_locations) —
// but the STATUS itself is real, polled from GET /orders/:id, not simulated.

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { View, Text, StyleSheet, Alert, TextInput } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, Chip } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { confirmDelivery, getOrderById, getOrderProgress, getPodsForOrder, OrderProgress, PodRecord } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'OrderTracking'>;

const FALLBACK_ORIGIN = { latitude: 19.076, longitude: 72.877 };
const FALLBACK_DEST = { latitude: 19.117, longitude: 72.869 };

const STATUS_SEQUENCE = ['PENDING', 'ACCEPTED', 'TRUCK_ASSIGNED', 'PICKUP_STARTED', 'OUT_FOR_DELIVERY', 'ARRIVING', 'DELIVERED', 'COMPLETED'];

const STATUS_LABEL: Record<string, string> = {
  PENDING: 'Waiting for supplier to accept',
  ACCEPTED: 'Order accepted by supplier',
  TRUCK_ASSIGNED: 'Truck assigned',
  PICKUP_STARTED: 'Material picked up',
  OUT_FOR_DELIVERY: 'Out for delivery',
  ARRIVING: 'Truck is arriving — OTP ready',
  DELIVERED: 'Delivered — confirm below',
  COMPLETED: 'Completed',
};

export default function OrderTrackingScreen({ route, navigation }: Props) {
  const { orderNumber, orderId, originLat, originLng, destLat, destLng } = route.params;
  const ORIGIN = originLat != null && originLng != null ? { latitude: originLat, longitude: originLng } : FALLBACK_ORIGIN;
  const DEST = destLat != null && destLng != null ? { latitude: destLat, longitude: destLng } : FALLBACK_DEST;

  const [status, setStatus] = useState<string>('PENDING');
  const [liveTracking, setLiveTracking] = useState(false);
  const [progress, setProgress] = useState<OrderProgress | null>(null);
  const [pods, setPods] = useState<PodRecord[]>([]);
  const [otp, setOtp] = useState('');
  const [confirming, setConfirming] = useState(false);
  const poller = useRef<ReturnType<typeof setInterval> | null>(null);

  const pollOnce = useCallback(async () => {
    try {
      const order = await getOrderById(orderId);
      setStatus(order.status);
      setLiveTracking(true);
      try {
        const prog = await getOrderProgress(orderId);
        if (prog.tripsTotal > 0) setProgress(prog);
      } catch { /* order isn't multi-truck, or progress endpoint unreachable — fine, ignore */ }
      if (order.status === 'DELIVERED' || order.status === 'COMPLETED') {
        try {
          const { results } = await getPodsForOrder(orderId);
          setPods(results);
        } catch { /* POD not yet available */ }
      }
    } catch {
      setLiveTracking(false);
    }
  }, [orderId]);

  useEffect(() => {
    pollOnce();
    poller.current = setInterval(pollOnce, 5000);
    return () => { if (poller.current) clearInterval(poller.current); };
  }, [pollOnce]);

  const statusIndex = Math.max(0, STATUS_SEQUENCE.indexOf(status));
  const visualProgress = statusIndex / (STATUS_SEQUENCE.length - 1);
  const truckPosition = {
    latitude: ORIGIN.latitude + (DEST.latitude - ORIGIN.latitude) * Math.min(visualProgress, 1),
    longitude: ORIGIN.longitude + (DEST.longitude - ORIGIN.longitude) * Math.min(visualProgress, 1),
  };
  const etaMinutes = Math.max(1, Math.round((1 - visualProgress) * 22));
  const delivered = status === 'DELIVERED' || status === 'COMPLETED';

  async function submitOtp() {
    if (otp.length !== 6) {
      Alert.alert('Enter the 6-digit OTP', 'Ask the driver for the delivery OTP.');
      return;
    }
    setConfirming(true);
    try {
      const ok = await confirmDelivery(orderId, otp);
      if (!ok.ok) { Alert.alert('Incorrect OTP', 'Please check the code and try again.'); return; }
      await pollOnce();
    } catch (err) {
      // Honest failure — an incorrect/expired OTP or an unreachable backend
      // both need the person to know delivery was NOT confirmed.
      Alert.alert('Could not confirm delivery', (err as Error).message || 'Backend not reachable — please try again.');
    } finally {
      setConfirming(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <MapView
        style={{ height: 260 }}
        initialRegion={{
          latitude: (ORIGIN.latitude + DEST.latitude) / 2,
          longitude: (ORIGIN.longitude + DEST.longitude) / 2,
          latitudeDelta: 0.09, longitudeDelta: 0.09,
        }}
      >
        <Marker coordinate={ORIGIN} title="Supplier" pinColor={colors.secondary} />
        <Marker coordinate={DEST} title="Delivery address" pinColor={colors.success} />
        <Marker coordinate={truckPosition} title="Truck">
          <View style={styles.truckMarker}><Text style={{ fontSize: 18 }}>🚛</Text></View>
        </Marker>
        <Polyline coordinates={[ORIGIN, DEST]} strokeColor={colors.border} strokeWidth={3} />
      </MapView>

      <View style={{ padding: spacing.md }}>
        <Text style={[type.h2, { marginBottom: 4 }]}>Order #{orderNumber}</Text>
        <Chip label={STATUS_LABEL[status] ?? status} tone={status === 'ARRIVING' ? 'warning' : 'default'} />
        {!liveTracking && (
          <Text style={[type.caption, { marginTop: 4 }]}>Backend not reachable — status shown may be out of date.</Text>
        )}

        <Card style={{ marginTop: spacing.md }}>
          <Text style={type.h3}>Estimated arrival</Text>
          <Text style={type.price}>{delivered ? 'Delivered' : `${etaMinutes} min`}</Text>
        </Card>

        {progress && progress.totalQuantity != null && (
          <Card>
            <Text style={type.h3}>Delivery progress</Text>
            <Text style={type.body}>{progress.deliveredQuantity} / {progress.totalQuantity} delivered</Text>
            <Text style={type.caption}>{progress.tripsCompleted} / {progress.tripsTotal} trips completed</Text>
          </Card>
        )}

        {status === 'ARRIVING' && (
          <Card>
            <Text style={type.h3}>Confirm delivery</Text>
            <Text style={[type.caption, { marginBottom: spacing.sm }]}>
              Enter the 6-digit OTP shown by the driver to mark this order delivered.
            </Text>
            <TextInput value={otp} onChangeText={setOtp} keyboardType="number-pad" maxLength={6} placeholder="••••••" style={styles.otpInput} />
            <View style={{ height: spacing.sm }} />
            <PrimaryButton title="Confirm delivery" onPress={submitOtp} loading={confirming} />
          </Card>
        )}

        {delivered && pods.length > 0 && (
          <Card>
            <Text style={type.h3}>✅ Proof of delivery</Text>
            {pods.map((p) => (
              <Text key={p.id} style={type.caption}>
                {p.delivered_quantity} units delivered at {new Date(p.delivered_at).toLocaleString()}
                {p.shortage_notes ? ` — ${p.shortage_notes}` : ''}
              </Text>
            ))}
          </Card>
        )}

        {status === 'COMPLETED' && (
          <Card>
            <Text style={type.h3}>Order complete</Text>
            <Text onPress={() => navigation.navigate('Invoice', { orderId })} style={{ color: colors.secondary, fontWeight: '600' }}>
              View invoice →
            </Text>
          </Card>
        )}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  truckMarker: {
    backgroundColor: colors.surface, padding: 4, borderRadius: 20, borderWidth: 1, borderColor: colors.border,
  },
  otpInput: {
    borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12,
    fontSize: 20, letterSpacing: 8, textAlign: 'center',
  },
});
