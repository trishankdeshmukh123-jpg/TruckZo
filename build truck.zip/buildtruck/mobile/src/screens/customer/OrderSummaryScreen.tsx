// Distance-based delivery charge calculation + full price breakdown, shown
// BEFORE payment method selection. Uses the address object passed forward
// from AddressScreen (live or sample — already resolved there) and the
// cart's live supplier location. Preview uses the same haversine +
// admin-settings formula as the backend; createOrder() on the backend
// recalculates the authoritative total server-side.

import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PriceRow, PrimaryButton, formatINR } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { useCart } from '../../context/CartContext';
import { loadPricingSettings, haversineKm, previewDeliveryCharge } from '../../utils/pricingPreview';

type Props = NativeStackScreenProps<CustomerStackParamList, 'OrderSummary'>;

export default function OrderSummaryScreen({ route, navigation }: Props) {
  const { address } = route.params;
  const { supplier, materialCost } = useCart();

  const [loading, setLoading] = useState(true);
  const [distanceKm, setDistanceKm] = useState(0);
  const [deliveryCharge, setDeliveryCharge] = useState(0);

  useEffect(() => {
    (async () => {
      const settings = await loadPricingSettings();
      const dist = haversineKm(
        { lat: supplier!.lat, lng: supplier!.lng },
        { lat: address.lat, lng: address.lng }
      );
      setDistanceKm(Math.round(dist * 10) / 10);
      setDeliveryCharge(previewDeliveryCharge(dist, settings));
      setLoading(false);
    })();
  }, []);

  const total = materialCost + deliveryCharge;

  if (loading) {
    return (
      <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.primary} size="large" />
        <Text style={[type.body, { marginTop: spacing.md }]}>Calculating delivery charge…</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <Text style={[type.h1, { marginBottom: spacing.md }]}>Order summary</Text>

      <Card>
        <Text style={type.h3}>Delivering to</Text>
        <Text style={type.body}>{address.line1}</Text>
        <Text style={type.caption}>{address.city}, {address.state} - {address.pincode}</Text>
      </Card>

      <Card>
        <Text style={[type.h3, { marginBottom: spacing.sm }]}>Price breakdown</Text>
        <PriceRow label="Material cost" value={formatINR(materialCost)} />
        <PriceRow label={`Delivery (${distanceKm} km)`} value={formatINR(deliveryCharge)} />
        <View style={{ height: 1, backgroundColor: colors.border, marginVertical: spacing.xs }} />
        <PriceRow label="Total" value={formatINR(total)} bold />
      </Card>

      <PrimaryButton
        title="Continue to payment"
        onPress={() => navigation.navigate('PaymentSelection', { address })}
      />
    </ScreenContainer>
  );
}
