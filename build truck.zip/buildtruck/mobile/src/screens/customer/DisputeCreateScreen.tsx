import React, { useState } from 'react';
import { ScrollView, Text, TextInput, View, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { createDispute } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'DisputeCreate'>;

const ISSUE_TYPES = [
  ['WRONG_MATERIAL', 'Wrong material'], ['SHORT_QUANTITY', 'Short quantity'],
  ['DAMAGED_MATERIAL', 'Damaged material'], ['QUALITY_ISSUE', 'Quality issue'],
  ['LATE_DELIVERY', 'Late delivery'], ['TRUCK_NO_SHOW', 'Truck no-show'],
  ['INCORRECT_CHARGES', 'Incorrect charges'], ['OTHER', 'Other'],
] as const;

export default function DisputeCreateScreen({ route, navigation }: Props) {
  const { orderId, orderNumber } = route.params;
  const [issueType, setIssueType] = useState<string>('OTHER');
  const [description, setDescription] = useState('');
  const [requestedResolution, setRequestedResolution] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!description) {
      Alert.alert('Missing description', 'Please describe the issue.');
      return;
    }
    setSaving(true);
    try {
      await createDispute({ orderId, issueType, description, requestedResolution: requestedResolution || undefined });
      Alert.alert('Reported', 'Our team will review this and get back to you.');
      navigation.goBack();
    } catch (err) {
      Alert.alert('Could not submit', (err as Error).message || 'Backend not reachable — please try again.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: spacing.xl }}>
        <Text style={[type.h1, { marginBottom: spacing.xs }]}>Report an issue</Text>
        <Text style={[type.caption, { marginBottom: spacing.md }]}>Order #{orderNumber}</Text>

        <Card>
          <Text style={type.h3}>What went wrong?</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginTop: spacing.xs }}>
            {ISSUE_TYPES.map(([value, label]) => (
              <Text
                key={value}
                onPress={() => setIssueType(value)}
                style={{
                  paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, fontSize: 13,
                  borderWidth: 1, borderColor: issueType === value ? colors.primary : colors.border,
                  backgroundColor: issueType === value ? colors.primary : colors.surface,
                  color: issueType === value ? '#fff' : colors.textPrimary,
                }}
              >
                {label}
              </Text>
            ))}
          </View>
        </Card>

        <Card>
          <Text style={type.caption}>Description</Text>
          <TextInput value={description} onChangeText={setDescription} multiline placeholder="Describe what happened" style={{ fontSize: 15, paddingVertical: 8, minHeight: 90, textAlignVertical: 'top' }} />
          <Text style={[type.caption, { marginTop: spacing.sm }]}>Requested resolution (optional)</Text>
          <TextInput value={requestedResolution} onChangeText={setRequestedResolution} placeholder="e.g. partial refund, replacement" style={{ fontSize: 15, paddingVertical: 8 }} />
        </Card>

        <PrimaryButton title="Submit report" onPress={submit} loading={saving} />
      </ScrollView>
    </ScreenContainer>
  );
}
