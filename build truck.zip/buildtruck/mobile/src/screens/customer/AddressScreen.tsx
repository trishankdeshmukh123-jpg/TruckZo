// Delivery address selection: live saved addresses (GET /addresses) with
// sample fallback, "use current location" via expo-location (device GPS —
// no external API key needed), or add a new address (POST /addresses).
// The full selected address object is passed forward via navigation params
// so OrderSummary/PaymentSelection never need a lookup-by-id.

import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CustomerStackParamList, AddressParam } from '../../navigation/types';
import { ScreenContainer, Card, PrimaryButton, Chip } from '../../components/Primitives';
import { type, spacing, colors } from '../../theme/theme';
import { sampleAddresses } from '../../data/sampleAddresses';
import { getAddresses, createAddress } from '../../api/client';

type Props = NativeStackScreenProps<CustomerStackParamList, 'Address'>;

export default function AddressScreen({ navigation }: Props) {
  const [addresses, setAddresses] = useState<AddressParam[]>(sampleAddresses);
  const [selectedId, setSelectedId] = useState<string>(sampleAddresses[0].id);
  const [loading, setLoading] = useState(true);
  const [usingGps, setUsingGps] = useState(false);
  const [isLive, setIsLive] = useState(false);

  // New-address form
  const [newLine1, setNewLine1] = useState('');
  const [newCity, setNewCity] = useState('');
  const [newState, setNewState] = useState('');
  const [newPincode, setNewPincode] = useState('');
  const [pendingGps, setPendingGps] = useState<{ lat: number; lng: number } | null>(null);
  const [savingAddress, setSavingAddress] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const { results } = await getAddresses();
        if (results.length) {
          const mapped = results.map((a) => ({ id: a.id, label: a.label, line1: a.line1, city: a.city, state: a.state, pincode: a.pincode, lat: a.lat, lng: a.lng }));
          setAddresses(mapped);
          setSelectedId(mapped[0].id);
          setIsLive(true);
        }
      } catch { /* keep sample fallback */ } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function useCurrentLocation() {
    setUsingGps(true);
    try {
      const Location = await import('expo-location');
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Location permission needed', 'Enable location access to use this, or pick a saved address.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({});
      setPendingGps({ lat: loc.coords.latitude, lng: loc.coords.longitude });
      Alert.alert('Location captured', 'Fill in a label below and save it as a delivery address.');
    } catch {
      Alert.alert('Could not get location', 'Falling back to your saved addresses.');
    } finally {
      setUsingGps(false);
    }
  }

  async function saveNewAddress() {
    if (!pendingGps || !newLine1 || !newCity || !newState || !newPincode) {
      Alert.alert('Missing details', 'Capture your GPS location above and fill in all address fields.');
      return;
    }
    setSavingAddress(true);
    try {
      const created = await createAddress({
        label: 'New address', line1: newLine1, line2: null, city: newCity,
        district: null, state: newState, pincode: newPincode, lat: pendingGps.lat, lng: pendingGps.lng,
      });
      const mapped: AddressParam = { id: created.id, label: created.label, line1: created.line1, city: created.city, state: created.state, pincode: created.pincode, lat: created.lat, lng: created.lng };
      setAddresses((prev) => [mapped, ...prev]);
      setSelectedId(mapped.id);
      setPendingGps(null); setNewLine1(''); setNewCity(''); setNewState(''); setNewPincode('');
    } catch {
      Alert.alert('Could not save', 'Backend not reachable — using this address for this order only.');
      const localAddress: AddressParam = {
        id: `local-${Date.now()}`, label: 'New address', line1: newLine1, city: newCity,
        state: newState, pincode: newPincode, lat: pendingGps.lat, lng: pendingGps.lng,
      };
      setAddresses((prev) => [localAddress, ...prev]);
      setSelectedId(localAddress.id);
    } finally {
      setSavingAddress(false);
    }
  }

  function proceed() {
    const address = addresses.find((a) => a.id === selectedId) ?? addresses[0];
    navigation.navigate('OrderSummary', { address });
  }

  if (loading) {
    return <ScreenContainer style={{ alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.primary} /></ScreenContainer>;
  }

  return (
    <ScreenContainer style={{ padding: 0 }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: 120 }}>
        <Text style={[type.h1, { marginBottom: spacing.md }]}>Delivery address</Text>
        {!isLive && <Text style={[type.caption, { marginBottom: spacing.sm }]}>Showing sample addresses — backend not reachable</Text>}

        <TouchableOpacity onPress={useCurrentLocation}>
          <Card style={{ borderColor: colors.secondary }}>
            <Text style={[type.h3, { color: colors.secondary }]}>
              📍 {usingGps ? 'Getting your location…' : 'Use current GPS location'}
            </Text>
          </Card>
        </TouchableOpacity>

        <Text style={[type.h3, { marginTop: spacing.md, marginBottom: spacing.sm }]}>Saved addresses</Text>
        {addresses.map((a) => (
          <TouchableOpacity key={a.id} onPress={() => setSelectedId(a.id)}>
            <Card style={{ borderColor: selectedId === a.id ? colors.primary : colors.border }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={type.h3}>{a.label}</Text>
                {selectedId === a.id && <Chip label="Selected" />}
              </View>
              <Text style={type.body}>{a.line1}</Text>
              <Text style={type.caption}>{a.city}, {a.state} - {a.pincode}</Text>
            </Card>
          </TouchableOpacity>
        ))}

        <Text style={[type.h3, { marginTop: spacing.md }]}>Add a new address</Text>
        <Card>
          {pendingGps ? (
            <Text style={[type.caption, { marginBottom: spacing.sm, color: colors.success }]}>
              GPS location captured ({pendingGps.lat.toFixed(4)}, {pendingGps.lng.toFixed(4)})
            </Text>
          ) : (
            <Text style={[type.caption, { marginBottom: spacing.sm }]}>
              Tap "Use current GPS location" above first — free-text geocoding needs a maps key
              (MAPS_PROVIDER_API_KEY) not yet configured.
            </Text>
          )}
          <TextInput placeholder="House/Plot no., street, area" value={newLine1} onChangeText={setNewLine1} style={{ paddingVertical: 6, fontSize: 15 }} />
          <TextInput placeholder="City" value={newCity} onChangeText={setNewCity} style={{ paddingVertical: 6, fontSize: 15 }} />
          <TextInput placeholder="State" value={newState} onChangeText={setNewState} style={{ paddingVertical: 6, fontSize: 15 }} />
          <TextInput placeholder="Pincode" value={newPincode} onChangeText={setNewPincode} keyboardType="number-pad" style={{ paddingVertical: 6, fontSize: 15 }} />
          <View style={{ height: spacing.sm }} />
          <PrimaryButton title="Save this address" onPress={saveNewAddress} loading={savingAddress} disabled={!pendingGps} />
        </Card>
      </ScrollView>
      <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: spacing.md, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border }}>
        <PrimaryButton title="Confirm address" onPress={proceed} />
      </View>
    </ScreenContainer>
  );
}
