// Shared visual language: clean/light background, construction-industrial
// accent colors, strong readable type. Used by every screen so the app
// feels like one product, not a set of prototypes.

export const colors = {
  background: '#FAFAF8',
  surface: '#FFFFFF',
  border: '#E9E5DE',
  textPrimary: '#1C1B19',
  textSecondary: '#6B6459',
  primary: '#F5A623',      // construction / safety-vest orange
  primaryDark: '#C97F0F',
  secondary: '#2B4C7E',    // steel blue — trucks, tracking, links
  success: '#2E7D4F',
  danger: '#C0392B',
  warning: '#B9770E',
  chipBg: '#FFF3DF',
};

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };

export const radius = { sm: 8, md: 12, lg: 20 };

export const type = {
  h1: { fontSize: 28, fontWeight: '700' as const, color: colors.textPrimary },
  h2: { fontSize: 20, fontWeight: '700' as const, color: colors.textPrimary },
  h3: { fontSize: 16, fontWeight: '600' as const, color: colors.textPrimary },
  body: { fontSize: 15, fontWeight: '400' as const, color: colors.textPrimary },
  caption: { fontSize: 13, fontWeight: '400' as const, color: colors.textSecondary },
  price: { fontSize: 18, fontWeight: '700' as const, color: colors.textPrimary },
};
