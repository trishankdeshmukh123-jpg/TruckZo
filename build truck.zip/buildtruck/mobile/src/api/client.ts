// Thin API client for the BuildTruck backend (see /backend in this repo).
// Every function tries the real endpoint first; if it's unreachable (no
// backend running yet, no network) it throws — callers decide whether to
// fall back to sample data (screens do this explicitly, never silently,
// so it's obvious in the UI when you're looking at demo data vs. live data).

import Constants from 'expo-constants';

const API_BASE_URL: string =
  (Constants.expoConfig?.extra?.apiBaseUrl as string) ?? 'http://localhost:4000';

let authToken: string | null = null;
export function setAuthToken(token: string | null) { authToken = token; }

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
      ...(options.headers ?? {}),
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `Request failed: ${res.status}`);
  }
  return res.json();
}

// ---- Orders ----
export interface CreateOrderPayload {
  supplierId: string;
  supplierMaterialItems: { supplierMaterialId: string; unitPrice: number; quantity: number }[];
  deliveryAddressId: string;
  originLat: number; originLng: number;
  destLat: number; destLng: number;
  paymentMethod: 'UPI' | 'CASH';
}

export interface CreateOrderResponse {
  orderId: string; orderNumber: string;
  price: {
    materialCost: number; deliveryDistanceKm: number; deliveryCharge: number;
    platformCharges: number; discountAmount: number; totalAmount: number;
  };
  commission: { commissionRate: number; commissionableAmount: number; commissionAmount: number };
}

export function createOrder(payload: CreateOrderPayload) {
  return request<CreateOrderResponse>('/orders', { method: 'POST', body: JSON.stringify(payload) });
}

export function updateOrderStatus(orderId: string, status: string, note?: string) {
  return request<{ ok: true }>(`/orders/${orderId}/status`, {
    method: 'POST', body: JSON.stringify({ status, note }),
  });
}

export function cancelOrder(orderId: string, reason: string) {
  return request<{ ok: true }>(`/orders/${orderId}/cancel`, {
    method: 'POST', body: JSON.stringify({ reason }),
  });
}

export function confirmDelivery(orderId: string, otp: string) {
  return request<{ ok: true }>(`/orders/${orderId}/confirm-delivery`, {
    method: 'POST', body: JSON.stringify({ otp }),
  });
}

export interface OrderHistoryRecord {
  id: string; order_number: string; status: string; total_amount: number; payment_method: string;
  supplier_name?: string; customer_name?: string; created_at: string;
}
export function getMyOrders() {
  return request<{ results: OrderHistoryRecord[] }>('/orders/mine');
}
export function getSupplierOrders(supplierId: string) {
  return request<{ results: OrderHistoryRecord[] }>(`/orders/supplier/${supplierId}`);
}
export function getOrderById(orderId: string) {
  return request<OrderHistoryRecord & { items: any[] }>(`/orders/${orderId}`);
}

// ---- Suppliers ----
export interface NearbySupplierOffer {
  supplierId: string; businessName: string; rating: number; ratingCount: number;
  distanceKm: number; verified: boolean; supplierLat: number; supplierLng: number;
  supplierMaterialId: string; pricePerUnit: number; availableQuantity: number; minOrderQuantity: number;
  materialName: string; materialUnit: string; materialDescription: string | null;
}

export async function findNearbySuppliers(materialId: string, lat: number, lng: number) {
  const params = new URLSearchParams({ materialId, lat: String(lat), lng: String(lng) });
  return request<{ results: NearbySupplierOffer[] }>(`/suppliers/near?${params.toString()}`);
}

// ---- Catalog (categories/materials) ----
export interface ApiCategory { id: string; name: string; slug: string; icon_url: string | null; }
export interface ApiMaterial { id: string; category_id: string; name: string; description: string | null; default_unit: string; }

export function getCategories() {
  return request<{ results: ApiCategory[] }>('/categories');
}
export function getMaterials(categoryId?: string) {
  const q = categoryId ? `?categoryId=${categoryId}` : '';
  return request<{ results: ApiMaterial[] }>(`/materials${q}`);
}

// ---- Addresses ----
export interface ApiAddress {
  id: string; label: string; line1: string; line2: string | null; city: string;
  district: string | null; state: string; pincode: string; lat: number; lng: number;
}
export function getAddresses() {
  return request<{ results: ApiAddress[] }>('/addresses');
}
export function createAddress(input: Omit<ApiAddress, 'id'>) {
  return request<ApiAddress>('/addresses', { method: 'POST', body: JSON.stringify(input) });
}

// ---- Standalone truck search/hire (marketplace, not tender) ----
export interface TruckSearchResult {
  id: string; registrationNumber: string; vehicleCategory: string; capacityBracket: string | null;
  capacityTons: number | null; ratePerTrip: number | null; ratePerKm: number | null;
  currentLat: number | null; currentLng: number | null; vehicleDetails: string | null; isAvailable: boolean;
  driverName: string | null; driverPhone: string | null; supplierName: string; rating: number; ratingCount: number;
  distanceKm: number | null;
}
export interface TruckSearchFilters {
  category?: string; capacity?: string; lat?: number; lng?: number;
  maxDistanceKm?: number; onlyAvailable?: boolean; maxRatePerTrip?: number; maxRatePerKm?: number;
}
export function searchTrucks(filters: TruckSearchFilters) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([k, v]) => { if (v !== undefined) params.set(k, String(v)); });
  return request<{ results: TruckSearchResult[] }>(`/trucks/search?${params.toString()}`);
}
export function requestTruckHire(truckId: string, message: string, quantity?: number, contactPhone?: string) {
  return request<{ id: string; status: string }>(`/trucks/${truckId}/requests`, {
    method: 'POST', body: JSON.stringify({ message, quantity, contactPhone }),
  });
}
export interface CreateTruckPayload {
  supplierId: string; registrationNumber: string; vehicleCategory: string; capacityBracket?: string;
  capacityTons?: number; ratePerTrip?: number; ratePerKm?: number; currentLat?: number; currentLng?: number;
  vehicleDetails?: string; driverName?: string; driverPhone?: string; isAvailable?: boolean;
}
export function createTruck(payload: CreateTruckPayload) {
  return request<{ id: string }>('/trucks', { method: 'POST', body: JSON.stringify(payload) });
}

export interface CreateTenderMaterialPayload {
  supplierId: string; categoryId?: string; materialName: string; quantity: number;
  unit: string; rate: number; supplyLocation: string; serviceArea?: string;
}
export function createTenderMaterial(payload: CreateTenderMaterialPayload) {
  return request<{ id: string; verification_status: string }>('/tender/materials', { method: 'POST', body: JSON.stringify(payload) });
}

export interface CreateTenderTruckPayload {
  supplierId: string; vehicleCategory: string; capacityBracket?: string; capacityTons?: number;
  registrationNumber: string; currentLat?: number; currentLng?: number; ratePerTrip?: number;
  ratePerKm?: number; driverName?: string; driverPhone?: string; vehicleDetails?: string;
}
export function createTenderTruck(payload: CreateTenderTruckPayload) {
  return request<{ id: string; verification_status: string }>('/tender/trucks', { method: 'POST', body: JSON.stringify(payload) });
}

// ---- Government Tender ----
export interface TenderMaterialResult {
  id: string; material_name: string; quantity: number; unit: string; rate: number;
  supply_location: string; service_area: string | null; is_available: boolean;
  supplier_name: string; supplier_phone: string;
}
export function searchTenderMaterials(filters: { categoryId?: string; location?: string; onlyAvailable?: boolean }) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([k, v]) => { if (v !== undefined) params.set(k, String(v)); });
  return request<{ results: TenderMaterialResult[] }>(`/tender/materials/search?${params.toString()}`);
}
export function requestTenderMaterial(id: string, message: string, quantity?: number, contactPhone?: string) {
  return request<{ id: string; status: string }>(`/tender/materials/${id}/requests`, {
    method: 'POST', body: JSON.stringify({ message, quantity, contactPhone }),
  });
}

export interface TenderTruckResult {
  id: string; vehicle_category: string; capacity_bracket: string | null; capacity_tons: number | null;
  registration_number: string; rate_per_trip: number | null; rate_per_km: number | null;
  driver_name: string | null; driver_phone: string | null; vehicle_details: string | null;
  is_available: boolean; supplier_name: string;
}
export function searchTenderTrucks(filters: { category?: string; capacity?: string; onlyAvailable?: boolean }) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([k, v]) => { if (v !== undefined) params.set(k, String(v)); });
  return request<{ results: TenderTruckResult[] }>(`/tender/trucks/search?${params.toString()}`);
}
export function requestTenderTruck(id: string, message: string, quantity?: number, contactPhone?: string) {
  return request<{ id: string; status: string }>(`/tender/trucks/${id}/requests`, {
    method: 'POST', body: JSON.stringify({ message, quantity, contactPhone }),
  });
}

// ---- Admin settings (read-only here; full admin dashboard is separate) ----
export function getPricingSettings() {
  return request<{ baseDeliveryCharge: number; perKmCharge: number; minDeliveryCharge: number; maxDeliveryDistanceKm: number }>(
    '/admin/settings/pricing'
  );
}

export { API_BASE_URL };

// =====================================================================
// RFQ / Quotation system
// =====================================================================
export interface RfqRecord {
  id: string; material_name: string; specification: string | null; quantity: number; unit: string;
  required_delivery_date: string | null; delivery_location: string; additional_requirements: string | null;
  target_price: number | null; expiry_at: string | null; status: string; quote_count?: number; created_at: string;
}
export interface CreateRfqPayload {
  materialName: string; specification?: string; quantity: number; unit: string;
  requiredDeliveryDate?: string; deliveryLocation: string; deliveryLat?: number; deliveryLng?: number;
  additionalRequirements?: string; targetPrice?: number; expiryAt?: string; projectId?: string; projectName?: string;
}
export function createRfq(payload: CreateRfqPayload) {
  return request<RfqRecord>('/rfq', { method: 'POST', body: JSON.stringify(payload) });
}
export function getMyRfqs() {
  return request<{ results: RfqRecord[] }>('/rfq/mine');
}
export function getOpenRfqs(material?: string) {
  const q = material ? `?material=${encodeURIComponent(material)}` : '';
  return request<{ results: RfqRecord[] }>(`/rfq/open${q}`);
}
export function getRfq(id: string) {
  return request<RfqRecord>(`/rfq/${id}`);
}
export interface RfqQuoteRecord {
  id: string; supplier_id: string; price_per_unit: number; available_quantity: number;
  delivery_time_days: number | null; transport_cost: number; tax_percent: number; notes: string | null;
  status: string; business_name: string; rating_avg: number; rating_count: number;
  verification_status: string; service_lat: number; service_lng: number;
}
export interface SubmitQuotePayload {
  supplierId: string; pricePerUnit: number; availableQuantity: number; deliveryTimeDays?: number;
  transportCost?: number; taxPercent?: number; quoteValidityUntil?: string; notes?: string;
}
export function submitRfqQuote(rfqId: string, payload: SubmitQuotePayload) {
  return request<{ id: string; status: string }>(`/rfq/${rfqId}/quotes`, { method: 'POST', body: JSON.stringify(payload) });
}
export function getRfqQuotes(rfqId: string) {
  return request<{ results: RfqQuoteRecord[] }>(`/rfq/${rfqId}/quotes`);
}
export function awardRfqQuote(rfqId: string, quoteId: string) {
  return request<{ ok: true }>(`/rfq/${rfqId}/quotes/${quoteId}/award`, { method: 'POST' });
}
export function shortlistRfqQuote(rfqId: string, quoteId: string) {
  return request<{ ok: true }>(`/rfq/${rfqId}/quotes/${quoteId}/shortlist`, { method: 'POST' });
}

// =====================================================================
// Multi-truck orders / trips / POD
// =====================================================================
export interface TripRecord {
  id: string; trip_number: number; truck_id: string | null; driver_name: string | null;
  driver_phone: string | null; load_quantity: number; status: string;
  pickup_time: string | null; delivery_time: string | null;
}
export interface OrderProgress {
  totalQuantity: number | null; deliveredQuantity: number; remainingQuantity: number | null;
  tripsTotal: number; tripsCompleted: number; trips: TripRecord[];
}
export function markOrderMultiTruck(orderId: string, totalQuantity: number) {
  return request<{ ok: true }>(`/orders/${orderId}/multi-truck`, { method: 'POST', body: JSON.stringify({ totalQuantity }) });
}
export function createOrderTrip(orderId: string, tripNumber: number, loadQuantity: number) {
  return request<TripRecord>(`/orders/${orderId}/trips`, { method: 'POST', body: JSON.stringify({ tripNumber, loadQuantity }) });
}
export function assignTrip(tripId: string, truckId: string, driverName?: string, driverPhone?: string) {
  return request<{ ok: true }>(`/trips/${tripId}/assign`, { method: 'POST', body: JSON.stringify({ truckId, driverName, driverPhone }) });
}
export function updateTripStatus(tripId: string, status: string) {
  return request<{ ok: true }>(`/trips/${tripId}/status`, { method: 'POST', body: JSON.stringify({ status }) });
}
export function getOrderProgress(orderId: string) {
  return request<OrderProgress>(`/orders/${orderId}/progress`);
}
export interface PodRecord {
  id: string; order_id: string; trip_id: string | null; delivered_quantity: number;
  shortage_notes: string | null; photo_urls: string[]; signature_url: string | null;
  customer_confirmed: boolean; otp_verified: boolean; delivered_at: string;
}
export function submitPod(orderId: string, input: { tripId?: string; deliveredQuantity: number; shortageNotes?: string; photoUrls?: string[]; customerConfirmed?: boolean; otpVerified?: boolean; }) {
  return request<PodRecord>(`/orders/${orderId}/pod`, { method: 'POST', body: JSON.stringify(input) });
}
export function getPodsForOrder(orderId: string) {
  return request<{ results: PodRecord[] }>(`/orders/${orderId}/pod`);
}

// =====================================================================
// Disputes
// =====================================================================
export interface DisputeRecord {
  id: string; order_id: string; issue_type: string; description: string; status: string;
  admin_notes: string | null; resolution: string | null; created_at: string;
}
export function createDispute(input: { orderId: string; issueType: string; description: string; evidenceUrls?: string[]; requestedResolution?: string }) {
  return request<DisputeRecord>('/disputes', { method: 'POST', body: JSON.stringify(input) });
}
export function getMyDisputes() {
  return request<{ results: DisputeRecord[] }>('/disputes/mine');
}
export function getDispute(id: string) {
  return request<DisputeRecord>(`/disputes/${id}`);
}

// =====================================================================
// Verification (documents)
// =====================================================================
export interface VerificationDocument {
  id: string; owner_type: string; owner_id: string; doc_type: string; file_url: string;
  status: string; expiry_date: string | null; created_at: string;
}
export function uploadVerificationDocument(ownerType: 'SUPPLIER' | 'TRUCK', ownerId: string, docType: string, fileUrl: string, expiryDate?: string) {
  return request<VerificationDocument>('/verification/documents', { method: 'POST', body: JSON.stringify({ ownerType, ownerId, docType, fileUrl, expiryDate }) });
}
export function getVerificationDocuments(ownerType: 'SUPPLIER' | 'TRUCK', ownerId: string) {
  return request<{ results: VerificationDocument[] }>(`/verification/documents/${ownerType}/${ownerId}`);
}

// =====================================================================
// Inventory
// =====================================================================
export interface InventoryRow {
  id: string; material_name: string; default_unit: string; available_quantity: number;
  reserved_quantity: number; sold_quantity: number; low_stock_threshold: number | null;
  expected_restock_date: string | null; is_low_stock: boolean;
}
export function getInventory(supplierId: string) {
  return request<{ results: InventoryRow[] }>(`/inventory/${supplierId}`);
}
export function updateInventorySettings(supplierMaterialId: string, lowStockThreshold?: number, expectedRestockDate?: string) {
  return request<{ ok: true }>(`/inventory/${supplierMaterialId}/settings`, { method: 'POST', body: JSON.stringify({ lowStockThreshold, expectedRestockDate }) });
}

// =====================================================================
// Business accounts + projects
// =====================================================================
export interface BusinessRecord { id: string; name: string; gstin: string | null; address: string | null; role: string; }
export function createBusiness(name: string, gstin?: string, address?: string) {
  return request<{ id: string }>('/business', { method: 'POST', body: JSON.stringify({ name, gstin, address }) });
}
export function getMyBusinesses() {
  return request<{ results: BusinessRecord[] }>('/business/mine');
}
export interface ProjectRecord {
  id: string; name: string; project_type: string | null; site_address: string | null;
  start_date: string | null; expected_completion_date: string | null;
}
export function createProject(businessId: string, input: { name: string; projectType?: string; siteAddress?: string; startDate?: string; expectedCompletionDate?: string }) {
  return request<{ id: string }>(`/business/${businessId}/projects`, { method: 'POST', body: JSON.stringify(input) });
}
export function getProjects(businessId: string) {
  return request<{ results: ProjectRecord[] }>(`/business/${businessId}/projects`);
}
export interface ProjectDashboard {
  totalOrders: number; activeOrders: number; completedOrders: number; totalSpend: number; openRfqs: number; totalRfqs: number;
}
export function getProjectDashboard(projectId: string) {
  return request<ProjectDashboard>(`/business/projects/${projectId}/dashboard`);
}

// =====================================================================
// Invoices
// =====================================================================
export interface InvoiceRecord {
  id: string; invoice_number: string; material_charges: number; delivery_charges: number;
  platform_charges: number; discount_amount: number; tax_amount: number; total_amount: number;
  gst_number: string | null; generated_at: string;
}
export function getInvoiceForOrder(orderId: string) {
  return request<InvoiceRecord>(`/invoices/order/${orderId}`);
}

// =====================================================================
// Notifications
// =====================================================================
export interface NotificationRecord {
  id: string; title: string; body: string; type: string; is_read: boolean; data: any; created_at: string;
}
export function getNotifications(unreadOnly = false) {
  return request<{ results: NotificationRecord[] }>(`/notifications${unreadOnly ? '?unreadOnly=true' : ''}`);
}
export function markNotificationRead(id: string) {
  return request<{ ok: true }>(`/notifications/${id}/read`, { method: 'POST' });
}
export function markAllNotificationsRead() {
  return request<{ ok: true }>('/notifications/read-all', { method: 'POST' });
}

// =====================================================================
// Supplier's own profile + material listings (real, not hardcoded ids)
// =====================================================================
export interface MySupplierProfile { id: string; business_name: string; verification_status: string; service_lat: number; service_lng: number; }
export function getMySupplierProfile() {
  return request<MySupplierProfile>('/suppliers/mine');
}
export interface CreateSupplierMaterialPayload {
  supplierId: string; materialId: string; pricePerUnit: number; unit: string; availableQuantity: number;
  minOrderQuantity?: number; specs?: Record<string, string>; lowStockThreshold?: number; expectedRestockDate?: string;
}
export function createSupplierMaterialListing(payload: CreateSupplierMaterialPayload) {
  return request<{ id: string }>('/suppliers/materials', { method: 'POST', body: JSON.stringify(payload) });
}
export function getSupplierOwnMaterials(supplierId: string) {
  return request<{ results: any[] }>(`/suppliers/${supplierId}/materials`);
}

// =====================================================================
// Category-configurable spec fields
// =====================================================================
export interface CategorySpecField { id: string; field_name: string; field_type: string; options: string[]; is_required: boolean; }
export function getCategorySpecFields(categoryId: string) {
  return request<{ results: CategorySpecField[] }>(`/categories/${categoryId}/spec-fields`);
}

