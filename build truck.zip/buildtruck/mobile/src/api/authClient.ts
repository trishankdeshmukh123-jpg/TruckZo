// Auth-specific API calls, kept separate from client.ts since they're used
// before a token exists (OTP request/verify don't send Authorization).

const API_BASE_URL: string = 'http://localhost:4000'; // see api/client.ts for the Constants-based version used elsewhere

export async function requestOtp(phone: string): Promise<void> {
  const res = await fetch(`${API_BASE_URL}/auth/otp/request`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ phone }),
  });
  if (!res.ok) throw new Error('Could not send OTP');
}

export interface VerifyOtpResult { token: string; userId: string; isNewUser: boolean; }

export async function verifyOtp(phone: string, otp: string, fullName?: string): Promise<VerifyOtpResult> {
  const res = await fetch(`${API_BASE_URL}/auth/otp/verify`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ phone, otp, fullName }),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? 'Invalid OTP');
  }
  return res.json();
}
