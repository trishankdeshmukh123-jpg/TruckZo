import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CustomerStackParamList } from './types';
import { colors } from '../theme/theme';

import HomeScreen from '../screens/customer/HomeScreen';
import CategoryListScreen from '../screens/customer/CategoryListScreen';
import MaterialListScreen from '../screens/customer/MaterialListScreen';
import SupplierSelectionScreen from '../screens/customer/SupplierSelectionScreen';
import MaterialDetailScreen from '../screens/customer/MaterialDetailScreen';
import CartScreen from '../screens/customer/CartScreen';
import AddressScreen from '../screens/customer/AddressScreen';
import OrderSummaryScreen from '../screens/customer/OrderSummaryScreen';
import PaymentSelectionScreen from '../screens/customer/PaymentSelectionScreen';
import OrderConfirmationScreen from '../screens/customer/OrderConfirmationScreen';
import OrderTrackingScreen from '../screens/customer/OrderTrackingScreen';
import OrderHistoryScreen from '../screens/customer/OrderHistoryScreen';
import SupportScreen from '../screens/customer/SupportScreen';
import TruckSearchScreen from '../screens/customer/TruckSearchScreen';
import TruckDetailScreen from '../screens/customer/TruckDetailScreen';
import TenderHomeScreen from '../screens/customer/TenderHomeScreen';
import TenderMaterialSearchScreen from '../screens/customer/TenderMaterialSearchScreen';
import TenderMaterialDetailScreen from '../screens/customer/TenderMaterialDetailScreen';
import TenderTruckSearchScreen from '../screens/customer/TenderTruckSearchScreen';
import TenderTruckDetailScreen from '../screens/customer/TenderTruckDetailScreen';
import RfqCreateScreen from '../screens/customer/rfq/RfqCreateScreen';
import RfqListScreen from '../screens/customer/rfq/RfqListScreen';
import RfqDetailScreen from '../screens/customer/rfq/RfqDetailScreen';
import NotificationsScreen from '../screens/customer/NotificationsScreen';
import DisputeCreateScreen from '../screens/customer/DisputeCreateScreen';
import DisputeListScreen from '../screens/customer/DisputeListScreen';
import DisputeDetailScreen from '../screens/customer/DisputeDetailScreen';
import InvoiceScreen from '../screens/customer/InvoiceScreen';
import BusinessHomeScreen from '../screens/customer/business/BusinessHomeScreen';
import ProjectListScreen from '../screens/customer/business/ProjectListScreen';
import ProjectDetailScreen from '../screens/customer/business/ProjectDetailScreen';

const Stack = createNativeStackNavigator<CustomerStackParamList>();

export default function CustomerNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.surface },
        headerTintColor: colors.textPrimary,
        headerShadowVisible: false,
      }}
    >
      <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Categories" component={CategoryListScreen} options={{ title: 'Categories' }} />
      <Stack.Screen name="MaterialList" component={MaterialListScreen} options={{ title: '' }} />
      <Stack.Screen name="SupplierSelection" component={SupplierSelectionScreen} options={{ title: 'Choose supplier' }} />
      <Stack.Screen name="MaterialDetail" component={MaterialDetailScreen} options={{ title: '' }} />
      <Stack.Screen name="Cart" component={CartScreen} options={{ title: 'Cart' }} />
      <Stack.Screen name="Address" component={AddressScreen} options={{ title: 'Delivery address' }} />
      <Stack.Screen name="OrderSummary" component={OrderSummaryScreen} options={{ title: 'Order summary' }} />
      <Stack.Screen name="PaymentSelection" component={PaymentSelectionScreen} options={{ title: 'Payment' }} />
      <Stack.Screen name="OrderConfirmation" component={OrderConfirmationScreen} options={{ title: '', headerBackVisible: false }} />
      <Stack.Screen name="OrderTracking" component={OrderTrackingScreen} options={{ title: 'Track order' }} />
      <Stack.Screen name="OrderHistory" component={OrderHistoryScreen} options={{ title: 'Order history' }} />
      <Stack.Screen name="Support" component={SupportScreen} options={{ title: 'Support' }} />
      <Stack.Screen name="TruckSearch" component={TruckSearchScreen} options={{ title: 'Find a truck' }} />
      <Stack.Screen name="TruckDetail" component={TruckDetailScreen} options={{ title: '' }} />
      <Stack.Screen name="TenderHome" component={TenderHomeScreen} options={{ title: 'Government Tenders' }} />
      <Stack.Screen name="TenderMaterialSearch" component={TenderMaterialSearchScreen} options={{ title: 'Tender materials' }} />
      <Stack.Screen name="TenderMaterialDetail" component={TenderMaterialDetailScreen} options={{ title: '' }} />
      <Stack.Screen name="TenderTruckSearch" component={TenderTruckSearchScreen} options={{ title: 'Tender trucks' }} />
      <Stack.Screen name="TenderTruckDetail" component={TenderTruckDetailScreen} options={{ title: '' }} />
      <Stack.Screen name="RfqCreate" component={RfqCreateScreen} options={{ title: 'Post a requirement' }} />
      <Stack.Screen name="RfqList" component={RfqListScreen} options={{ title: 'My requirements' }} />
      <Stack.Screen name="RfqDetail" component={RfqDetailScreen} options={{ title: '' }} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} options={{ title: 'Notifications' }} />
      <Stack.Screen name="DisputeCreate" component={DisputeCreateScreen} options={{ title: 'Report an issue' }} />
      <Stack.Screen name="DisputeList" component={DisputeListScreen} options={{ title: 'My issues' }} />
      <Stack.Screen name="DisputeDetail" component={DisputeDetailScreen} options={{ title: '' }} />
      <Stack.Screen name="Invoice" component={InvoiceScreen} options={{ title: 'Invoice' }} />
      <Stack.Screen name="BusinessHome" component={BusinessHomeScreen} options={{ title: 'Business accounts' }} />
      <Stack.Screen name="ProjectList" component={ProjectListScreen} options={{ title: '' }} />
      <Stack.Screen name="ProjectDetail" component={ProjectDetailScreen} options={{ title: '' }} />
    </Stack.Navigator>
  );
}
