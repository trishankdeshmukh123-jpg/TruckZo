// Central param-list so every screen's navigation props are type-checked.

export interface OfferParam {
  offerId: string; supplierId: string; businessName: string; rating: number; ratingCount: number;
  distanceKm: number; verified: boolean; supplierLat: number; supplierLng: number;
  pricePerUnit: number; availableQuantity: number; minOrderQuantity: number;
  materialName: string; materialUnit: string; materialDescription: string;
}

export interface AddressParam {
  id: string; label: string; line1: string; city: string; state: string; pincode: string;
  lat: number; lng: number;
}

export type CustomerStackParamList = {
  Home: undefined;
  Categories: undefined;
  MaterialList: { categoryId: string; categoryName: string };
  SupplierSelection: { materialId: string; materialName: string };
  MaterialDetail: { materialId: string; offer: OfferParam };
  Cart: undefined;
  Address: undefined;
  OrderSummary: { address: AddressParam };
  PaymentSelection: { address: AddressParam };
  OrderConfirmation: {
    orderNumber: string; orderId: string; totalAmount: number; paymentMethod: 'UPI' | 'CASH';
    originLat: number; originLng: number; destLat: number; destLng: number;
  };
  OrderTracking: {
    orderId: string; orderNumber: string;
    originLat?: number; originLng?: number; destLat?: number; destLng?: number;
  };
  OrderHistory: undefined;
  Support: undefined;
  TruckSearch: undefined;
  TruckDetail: { truck: import('../api/client').TruckSearchResult };
  TenderHome: undefined;
  TenderMaterialSearch: undefined;
  TenderMaterialDetail: { material: import('../api/client').TenderMaterialResult };
  TenderTruckSearch: undefined;
  TenderTruckDetail: { truck: import('../api/client').TenderTruckResult };

  // RFQ / bulk requirement
  RfqCreate: { projectId?: string; projectName?: string } | undefined;
  RfqList: undefined;
  RfqDetail: { rfqId: string };

  // Notifications
  Notifications: undefined;

  // Disputes
  DisputeCreate: { orderId: string; orderNumber: string };
  DisputeList: undefined;
  DisputeDetail: { disputeId: string };

  // Invoice
  Invoice: { orderId: string };

  // Business / projects
  BusinessHome: undefined;
  ProjectList: { businessId: string; businessName: string };
  ProjectDetail: { projectId: string; projectName: string };
};

export type SupplierStackParamList = {
  SupplierDashboard: undefined;
  SupplierOrders: undefined;
  SupplierOrderDetail: { orderId: string };
  SupplierMaterials: undefined;
  SupplierMaterialEdit: { materialId?: string };
  SupplierTrucks: undefined;
  SupplierTruckEdit: { truckId?: string };
  SupplierEarnings: undefined;
  SupplierProfile: undefined;
  SupplierTenderListings: undefined;
  SupplierTenderMaterialEdit: undefined;
  SupplierTenderTruckEdit: undefined;

  SupplierRfqList: undefined;
  SupplierRfqQuote: { rfqId: string };
  SupplierTrips: { orderId: string; orderNumber: string };
  SupplierPod: { orderId: string; orderNumber: string; tripId?: string };
  SupplierInventory: undefined;
  SupplierVerification: undefined;
  SupplierNotifications: undefined;
};
