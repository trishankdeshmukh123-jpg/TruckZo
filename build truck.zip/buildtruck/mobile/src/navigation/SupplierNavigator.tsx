import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SupplierStackParamList } from './types';
import { colors } from '../theme/theme';

import SupplierDashboardScreen from '../screens/supplier/SupplierDashboardScreen';
import SupplierOrdersScreen from '../screens/supplier/SupplierOrdersScreen';
import SupplierOrderDetailScreen from '../screens/supplier/SupplierOrderDetailScreen';
import SupplierMaterialsScreen from '../screens/supplier/SupplierMaterialsScreen';
import SupplierMaterialEditScreen from '../screens/supplier/SupplierMaterialEditScreen';
import SupplierTrucksScreen from '../screens/supplier/SupplierTrucksScreen';
import SupplierTruckEditScreen from '../screens/supplier/SupplierTruckEditScreen';
import SupplierEarningsScreen from '../screens/supplier/SupplierEarningsScreen';
import SupplierProfileScreen from '../screens/supplier/SupplierProfileScreen';
import SupplierTenderListingsScreen from '../screens/supplier/SupplierTenderListingsScreen';
import SupplierTenderMaterialEditScreen from '../screens/supplier/SupplierTenderMaterialEditScreen';
import SupplierTenderTruckEditScreen from '../screens/supplier/SupplierTenderTruckEditScreen';

import SupplierRfqListScreen from '../screens/supplier/SupplierRfqListScreen';
import SupplierRfqQuoteScreen from '../screens/supplier/SupplierRfqQuoteScreen';
import SupplierTripsScreen from '../screens/supplier/SupplierTripsScreen';
import SupplierPodScreen from '../screens/supplier/SupplierPodScreen';
import SupplierInventoryScreen from '../screens/supplier/SupplierInventoryScreen';
import SupplierVerificationScreen from '../screens/supplier/SupplierVerificationScreen';
import NotificationsScreen from '../screens/customer/NotificationsScreen';

const Stack = createNativeStackNavigator<SupplierStackParamList>();

export default function SupplierNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.surface },
        headerTintColor: colors.textPrimary,
        headerShadowVisible: false,
      }}
    >
      <Stack.Screen name="SupplierDashboard" component={SupplierDashboardScreen} options={{ headerShown: false }} />
      <Stack.Screen name="SupplierOrders" component={SupplierOrdersScreen} options={{ title: 'Orders' }} />
      <Stack.Screen name="SupplierOrderDetail" component={SupplierOrderDetailScreen} options={{ title: '' }} />
      <Stack.Screen name="SupplierMaterials" component={SupplierMaterialsScreen} options={{ title: 'Materials' }} />
      <Stack.Screen name="SupplierMaterialEdit" component={SupplierMaterialEditScreen} options={{ title: '' }} />
      <Stack.Screen name="SupplierTrucks" component={SupplierTrucksScreen} options={{ title: 'Trucks' }} />
      <Stack.Screen name="SupplierTruckEdit" component={SupplierTruckEditScreen} options={{ title: '' }} />
      <Stack.Screen name="SupplierEarnings" component={SupplierEarningsScreen} options={{ title: 'Earnings' }} />
      <Stack.Screen name="SupplierProfile" component={SupplierProfileScreen} options={{ title: 'Profile' }} />
      <Stack.Screen name="SupplierTenderListings" component={SupplierTenderListingsScreen} options={{ title: 'Government Tenders' }} />
      <Stack.Screen name="SupplierTenderMaterialEdit" component={SupplierTenderMaterialEditScreen} options={{ title: '' }} />
      <Stack.Screen name="SupplierTenderTruckEdit" component={SupplierTenderTruckEditScreen} options={{ title: '' }} />
      <Stack.Screen name="SupplierRfqList" component={SupplierRfqListScreen} options={{ title: 'RFQs' }} />
      <Stack.Screen name="SupplierRfqQuote" component={SupplierRfqQuoteScreen} options={{ title: 'Submit quote' }} />
      <Stack.Screen name="SupplierTrips" component={SupplierTripsScreen} options={{ title: 'Trips' }} />
      <Stack.Screen name="SupplierPod" component={SupplierPodScreen} options={{ title: 'Proof of delivery' }} />
      <Stack.Screen name="SupplierInventory" component={SupplierInventoryScreen} options={{ title: 'Inventory' }} />
      <Stack.Screen name="SupplierVerification" component={SupplierVerificationScreen} options={{ title: 'Verification' }} />
      <Stack.Screen name="SupplierNotifications" component={NotificationsScreen} options={{ title: 'Notifications' }} />
    </Stack.Navigator>
  );
}
