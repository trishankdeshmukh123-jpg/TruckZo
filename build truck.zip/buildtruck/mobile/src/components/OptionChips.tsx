// Reusable single-select chip row for fixed option sets (vehicle category,
// capacity bracket) used by both supplier truck forms and customer truck
// search filters.

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors, radius, spacing } from '../theme/theme';
import { Option } from '../data/truckOptions';

export default function OptionChips({
  options, value, onChange, allowClear,
}: { options: Option[]; value: string | null; onChange: (v: string | null) => void; allowClear?: boolean }) {
  return (
    <View style={styles.wrap}>
      {allowClear && (
        <TouchableOpacity onPress={() => onChange(null)} style={[styles.chip, !value && styles.chipSelected]}>
          <Text style={[styles.chipText, !value && styles.chipTextSelected]}>Any</Text>
        </TouchableOpacity>
      )}
      {options.map((o) => (
        <TouchableOpacity key={o.value} onPress={() => onChange(o.value)} style={[styles.chip, value === o.value && styles.chipSelected]}>
          <Text style={[styles.chipText, value === o.value && styles.chipTextSelected]}>{o.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  chip: {
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: radius.sm,
    borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, marginBottom: 6,
  },
  chipSelected: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontSize: 13, color: colors.textPrimary },
  chipTextSelected: { color: '#fff', fontWeight: '700' },
});
