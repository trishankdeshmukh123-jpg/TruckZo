// Small shared building blocks so every screen looks consistent without
// copy-pasting styles. Keep this file dependency-free (no navigation, no
// API) so it's safe to import anywhere.

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ViewStyle, ActivityIndicator } from 'react-native';
import { colors, radius, spacing, type } from '../theme/theme';

export function ScreenContainer({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.screen, style]}>{children}</View>;
}

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function PrimaryButton({
  title, onPress, disabled, loading,
}: { title: string; onPress: () => void; disabled?: boolean; loading?: boolean }) {
  return (
    <TouchableOpacity
      style={[styles.primaryButton, disabled && styles.buttonDisabled]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.85}
    >
      {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryButtonText}>{title}</Text>}
    </TouchableOpacity>
  );
}

export function SecondaryButton({ title, onPress }: { title: string; onPress: () => void }) {
  return (
    <TouchableOpacity style={styles.secondaryButton} onPress={onPress} activeOpacity={0.85}>
      <Text style={styles.secondaryButtonText}>{title}</Text>
    </TouchableOpacity>
  );
}

export function Chip({ label, tone = 'default' }: { label: string; tone?: 'default' | 'success' | 'warning' | 'danger' }) {
  const toneColor = { default: colors.secondary, success: colors.success, warning: colors.warning, danger: colors.danger }[tone];
  return (
    <View style={[styles.chip, { borderColor: toneColor }]}>
      <Text style={[styles.chipText, { color: toneColor }]}>{label}</Text>
    </View>
  );
}

export function PriceRow({ label, value, bold, muted }: { label: string; value: string; bold?: boolean; muted?: boolean }) {
  return (
    <View style={styles.priceRow}>
      <Text style={[type.body, muted && { color: colors.textSecondary }]}>{label}</Text>
      <Text style={[bold ? type.price : type.body, muted && { color: colors.textSecondary }]}>{value}</Text>
    </View>
  );
}

export function EmptyState({ message }: { message: string }) {
  return (
    <View style={styles.emptyState}>
      <Text style={[type.body, { color: colors.textSecondary, textAlign: 'center' }]}>{message}</Text>
    </View>
  );
}

export function formatINR(amount: number): string {
  return `₹${amount.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, padding: spacing.md },
  card: {
    backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.md,
    borderWidth: 1, borderColor: colors.border, marginBottom: spacing.md,
  },
  primaryButton: {
    backgroundColor: colors.primary, borderRadius: radius.md, paddingVertical: 16,
    alignItems: 'center', justifyContent: 'center',
  },
  buttonDisabled: { opacity: 0.5 },
  primaryButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  secondaryButton: {
    borderRadius: radius.md, paddingVertical: 14, alignItems: 'center',
    borderWidth: 1.5, borderColor: colors.secondary,
  },
  secondaryButtonText: { color: colors.secondary, fontSize: 15, fontWeight: '600' },
  chip: { borderWidth: 1, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4, alignSelf: 'flex-start' },
  chipText: { fontSize: 12, fontWeight: '600' },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  emptyState: { padding: spacing.xl, alignItems: 'center' },
});
