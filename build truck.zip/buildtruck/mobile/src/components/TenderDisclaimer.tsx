// Shown on every Government Tender screen per the task spec: BuildTruck is
// a coordination/listing platform only — never represent it as an official
// government portal or claim it awards contracts.

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, radius, spacing, type } from '../theme/theme';

export default function TenderDisclaimer() {
  return (
    <View style={styles.box}>
      <Text style={styles.text}>
        BuildTruck is an independent marketplace that helps suppliers and truck owners list
        materials/vehicles for government-project requirements, and helps project/tender users find
        and contact them. BuildTruck is not a government portal, does not process or award tenders,
        and does not represent any government body.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    backgroundColor: colors.chipBg, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.warning,
    padding: spacing.sm, marginBottom: spacing.md,
  },
  text: { ...type.caption, color: '#6B4E0F' },
});
