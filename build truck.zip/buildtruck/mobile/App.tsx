// Root of the app. Gates on auth first (Login -> OTP), then mounts the
// customer or supplier navigator based on AppMode — one codebase, two
// modes, per spec ("Use ONE app with a separate Supplier/Truck Owner Mode").

import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { AuthProvider, useAuth } from './src/context/AuthContext';
import { AppModeProvider, useAppMode } from './src/context/AppModeContext';
import { CartProvider } from './src/context/CartContext';
import CustomerNavigator from './src/navigation/CustomerNavigator';
import SupplierNavigator from './src/navigation/SupplierNavigator';
import LoginScreen from './src/screens/auth/LoginScreen';
import OtpScreen from './src/screens/auth/OtpScreen';

function AuthGate() {
  const { user } = useAuth();
  const [pendingPhone, setPendingPhone] = useState<string | null>(null);

  if (!user) {
    return pendingPhone ? (
      <OtpScreen phone={pendingPhone} onBack={() => setPendingPhone(null)} />
    ) : (
      <LoginScreen onOtpSent={setPendingPhone} />
    );
  }
  return <RootNavigator />;
}

function RootNavigator() {
  const { mode } = useAppMode();
  return mode === 'customer' ? <CustomerNavigator /> : <SupplierNavigator />;
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <AppModeProvider>
          <CartProvider>
            <NavigationContainer>
              <StatusBar style="dark" />
              <AuthGate />
            </NavigationContainer>
          </CartProvider>
        </AppModeProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
}
